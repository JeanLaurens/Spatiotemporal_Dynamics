clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('htb'));
addpath(genpath('modelS2H'));

brain_area = 'CN';

TIMEPATH = (['..' filesep '..' filesep 'Paper_Input' filesep 'Time_Correction' filesep]);
disp([TIMEPATH brain_area '_correct.csv']);
fid = fopen([TIMEPATH brain_area '_correct.csv'], 'r');
t = textscan(fid, '%s %s %f %d\n');
fclose(fid);
pool_dir = t{1};
pool_name = t{2};
pool_lag = t{3};
pool_machine = t{4};
u_machine = unique(pool_machine);

default_lag = nanmedian(pool_lag);
for i=1:length(u_machine),
    default_lag = [default_lag nanmedian(pool_lag(pool_machine == u_machine(i)))];
end


for i=1:length(pool_name),
   cur_path_name = pool_dir{i}(4:end);
   cur_file_name = [pool_name{i}(1:end-6) '.htb'];
   cur_chan = str2num(pool_name{i}(end-4));
   cur_machine = pool_machine(i);
   

   [~, data, ~, ~] = LoadTEMPOData(cur_path_name, cur_file_name);

   if ~isnan(pool_lag(i)),
       cur_lag = pool_lag(i);
   else
       if ~isnan(pool_machine(i)),
            cur_machine = pool_machine(i);
            cur_lag = default_lag(cur_machine+1);
        else
            cur_lag = default_lag(1);
       end
   end

    p = PSTH('sheng', cur_lag, data, cur_chan);
    if ~p.rej,
         save(['..' filesep '..' filesep 'Paper_Input' filesep 'psth_' brain_area '_c' filesep ...
               pool_name{i}], 'p');
    end
end