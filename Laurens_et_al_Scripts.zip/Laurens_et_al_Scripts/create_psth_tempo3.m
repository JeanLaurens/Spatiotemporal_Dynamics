clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('htb'));
addpath(genpath('modelS2H'));

DATA_NAME = ['..' filesep '..' filesep 'Data' filesep 'Sheng' filesep];
[~, txt, ~] = xlsread([DATA_NAME 'resps.xls']);
file_name = txt(:,1);
chan = txt(:,2);
brain_area = txt(:,3);

pool_lag = nan(length(file_name), 1);
pool_filename = cell(length(file_name), 1);

TIMEPATH = (['..' filesep '..' filesep 'Paper_Output' filesep 'Time_Correction' filesep]);
disp([TIMEPATH 'VN_correct.csv']);
fid = fopen([TIMEPATH 'VN_correct.csv'], 'r');
t = textscan(fid, '%s %f %d\n');
fclose(fid);
vn_pool_lag = t{2};
vn_pool_filename = t{1};

vn_default_lag = nanmedian(vn_pool_lag);

disp([TIMEPATH 'CN_correct.csv']);
fid = fopen([TIMEPATH 'CN_correct.csv'], 'r');
t = textscan(fid, '%s %f %d\n');
fclose(fid);
cn_pool_lag = t{2};
cn_pool_filename = t{1};

cn_default_lag = nanmedian(cn_pool_lag);


for i = 1, %:length(chan),
    pool_filename{i} = ' ';
    
    cur_chan = chan{i};
    cur_chan = str2num(cur_chan(2));
    
    cur_file_name = file_name{i};
    
    disp([num2str(i) ', ' cur_file_name(1:end-4) 'c' num2str(cur_chan) '.mat']);
    pool_filename{i} = [cur_file_name(1:end-4) 'c' num2str(cur_chan) '.mat'];
    [~, data, ~, ~] = LoadTEMPOData(DATA_NAME, cur_file_name);

    if strcmp(brain_area{i}, 'VN'),
        vn_idx = find(ismember(vn_pool_filename, cur_file_name));
        if isempty(vn_idx) || isnan(vn_pool_lag(vn_idx)),
            time_correct = vn_default_lag;
        else
            time_correct = vn_pool_lag(vn_idx);
        end
    else
        cn_idx = find(ismember(cn_pool_filename, cur_file_name));
        if isempty(cn_idx) || isnan(pool_lag(cn_idx)),
            time_correct = cn_default_lag;
        else
            time_correct = cn_pool_lag(cn_idx);
        end
    end

    p = PSTH('sheng', time_correct, data, cur_chan);
%     if ~p.rej,
%         save(['..' filesep '..' filesep 'Paper_Output' filesep 'psth_' brain_area{i} '_c' filesep ...
%             cur_file_name(1:end-4) 'c' num2str(cur_chan) '.mat'], 'p');
%     end
end