classdef poolSimModel
    properties
        true_type
        pool_type
        
        true_weights
        pool_weights
        
        true_v_tuning
        true_a_tuning
        true_j_tuning
        pool_v_tuning
        pool_a_tuning
        pool_j_tuning
        
        true_n
        pool_n
        
        true_DC
        pool_DC
        
        pool_mu_t
        true_mu_t
        
        time

        pool_A
        pool_R_0
        
        pool_match
        
        mismatches
    end
    
    methods
        function obj = poolSimModel(OUTPUT_PATH)          
            data_dir = dir([OUTPUT_PATH '*.mat']);
            
            obj.true_type = zeros(length(data_dir), 1);
            obj.pool_type = zeros(length(data_dir), 1);
            
            obj.true_weights = zeros(length(data_dir), 3);
            obj.pool_weights = zeros(length(data_dir), 3);
            
            obj.true_v_tuning = zeros(length(data_dir), 2);
            obj.true_a_tuning = zeros(length(data_dir), 2);
            obj.true_j_tuning = zeros(length(data_dir), 2);
            obj.pool_v_tuning = zeros(length(data_dir), 2);
            obj.pool_a_tuning = zeros(length(data_dir), 2);
            obj.pool_j_tuning = zeros(length(data_dir), 2);

            obj.true_n = zeros(length(data_dir), 3);
            obj.pool_n = zeros(length(data_dir), 3);
           
            obj.true_DC = zeros(length(data_dir), 3);
            obj.pool_DC = zeros(length(data_dir), 3);
            
            obj.pool_mu_t = zeros(length(data_dir), 1);
            obj.true_mu_t = zeros(length(data_dir), 1);
            
            obj.pool_A = zeros(length(data_dir), 1);
            obj.pool_R_0 = zeros(length(data_dir), 1);
            
            obj.pool_match = zeros(7,7);
            
            obj.mismatches = zeros(length(data_dir), 1);
            
            for i=1:length(data_dir),
                dat = load([OUTPUT_PATH filesep data_dir(i).name]);
                
                obj.true_type(i) = dat.p.model_type;
                
                switch dat.p.model_type,
                    case 1
                        obj.true_mu_t(i) = dat.p.true_param(3);
                        
                        obj.true_v_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                        obj.true_a_tuning(i,:) = NaN;
                        obj.true_j_tuning(i,:) = NaN;
                        
                        obj.true_weights(i,1) = 1;
                        
                        obj.true_n(i,1) = dat.p.true_param(4);
                        obj.true_n(i,2) = NaN;
                        obj.true_n(i,3) = NaN;
                        
                        obj.true_DC(i,1) = dat.p.true_param(7);
                        obj.true_DC(i,2) = NaN;
                        obj.true_DC(i,3) = NaN;
                        
                    case 2
                        obj.true_mu_t(i) = dat.p.true_param(3);
                        
                        obj.true_v_tuning(i,:) = NaN;
                        obj.true_a_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                        obj.true_j_tuning(i,:) = NaN;
                        
                        obj.true_weights(i,2) = 1;
                        
                        obj.true_n(i,1) = NaN;
                        obj.true_n(i,2) = dat.p.true_param(4);
                        obj.true_n(i,3) = NaN;
                        
                        obj.true_DC(i,1) = NaN;
                        obj.true_DC(i,2) = dat.p.true_param(7);
                        obj.true_DC(i,3) = NaN;
                        
                    case 3
                        obj.true_mu_t(i) = dat.p.true_param(3);
                        
                        obj.true_v_tuning(i,:) = NaN;
                        obj.true_a_tuning(i,:) = NaN;
                        obj.true_j_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                                              
                         obj.true_weights(i,3) = 1; 
                         
                         obj.true_n(i,1) = NaN;
                         obj.true_n(i,2) = NaN;
                         obj.true_n(i,3) = dat.p.true_param(4);
                         
                         obj.true_DC(i,1) = NaN;
                         obj.true_DC(i,2) = NaN;
                         obj.true_DC(i,3) = dat.p.true_param(7);
                   
                    case 4
                        obj.true_mu_t(i) = dat.p.true_param(3);
                        
                        obj.true_v_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                        obj.true_a_tuning(i,:) = [dat.p.true_param(9) ...
                                                  dat.p.true_param(10) ...
                                                  ]*180/pi;
                        obj.true_j_tuning(i,:) = NaN;
                        
                        obj.true_weights(i,1) = dat.p.true_param(12);
                        obj.true_weights(i,2) = 1-dat.p.true_param(12);
                        
                        obj.true_n(i,1) = dat.p.true_param(4);
                        obj.true_n(i,2) = dat.p.true_param(8);
                        obj.true_n(i,3) = NaN;
                        
                        obj.true_DC(i,1) = dat.p.true_param(7);
                        obj.true_DC(i,2) = dat.p.true_param(11);
                        obj.true_DC(i,3) = NaN;
                        
                    case 5
                        obj.true_mu_t(i) = dat.p.true_param(3);
                        
                        obj.true_v_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                        obj.true_a_tuning(i,:) = NaN;                      
                        obj.true_j_tuning(i,:) = [dat.p.true_param(9) ...
                                                  dat.p.true_param(10) ...
                                                  ]*180/pi;
                                              
                        obj.true_weights(i,1) = dat.p.true_param(12);
                        obj.true_weights(i,3) = 1-dat.p.true_param(12);                      

                        obj.true_n(i,1) = dat.p.true_param(4);
                        obj.true_n(i,2) = NaN;
                        obj.true_n(i,3) = dat.p.true_param(8);
                        
                        obj.true_DC(i,1) = dat.p.true_param(7);
                        obj.true_DC(i,2) = NaN;
                        obj.true_DC(i,3) = dat.p.true_param(11);
                        
                    case 6
                        obj.true_mu_t(i) = dat.p.true_param(3);
                        
                        obj.true_v_tuning(i,:) = NaN;
                        obj.true_a_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                        obj.true_j_tuning(i,:) = [dat.p.true_param(9) ...
                                                  dat.p.true_param(10) ...
                                                  ]*180/pi;
                                              
                        obj.true_weights(i,2) = dat.p.true_param(12);
                        obj.true_weights(i,3) = 1-dat.p.true_param(12);  
                        
                        obj.true_n(i,1) = NaN;
                        obj.true_n(i,2) = dat.p.true_param(4);
                        obj.true_n(i,3) = dat.p.true_param(8);
                        
                        obj.true_DC(i,1) = NaN;
                        obj.true_DC(i,2) = dat.p.true_param(7);
                        obj.true_DC(i,3) = dat.p.true_param(11);
                                              
                    case 7
%                         obj.true_v_tuning(i,:) = NaN;
%                         obj.true_a_tuning(i,:) = NaN;
%                         obj.true_j_tuning(i,:) = NaN;
% 
%                         obj.true_weights(i,1) = NaN;
%                         obj.true_weights(i,2) = NaN;
%                         obj.true_weights(i,3) = NaN;
%                         
%                         obj.true_n(i,1) = NaN;
%                         obj.true_n(i,2) = NaN;
%                         obj.true_n(i,3) = NaN;
%                         
%                         obj.true_DC(i,1) = NaN;
%                         obj.true_DC(i,2) = NaN;
%                         obj.true_DC(i,3) = NaN;
                        
                        obj.true_mu_t(i) = dat.p.true_param(3);

                        obj.true_v_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                        obj.true_a_tuning(i,:) = [dat.p.true_param(9) ...
                                                  dat.p.true_param(10) ...
                                                  ]*180/pi;
                        obj.true_j_tuning(i,:) = [dat.p.true_param(13) ...
                                                  dat.p.true_param(14) ...
                                                  ]*180/pi;
                                              
                        w_v = dat.p.true_param(16);
                        w_j = dat.p.true_param(17);
                        obj.true_weights(i,1) = (1 - w_j)*w_v;
                        obj.true_weights(i,2) = (1 - w_j)*(1 - w_v);
                        obj.true_weights(i,3) = w_j;
                        
                        obj.true_n(i,1) = dat.p.true_param(4);
                        obj.true_n(i,2) = dat.p.true_param(8);
                        obj.true_n(i,3) = dat.p.true_param(12);
                        
                        obj.true_DC(i,1) = dat.p.true_param(7);
                        obj.true_DC(i,2) = dat.p.true_param(11);
                        obj.true_DC(i,3) = dat.p.true_param(15);
                end
  
                sm = selModel2(dat.p, dat.fv, dat.fa, dat.fj, ...
                              dat.fva, dat.fvj, dat.faj, dat.fvaj);         
                          
                if i == 1,
                    obj.time = sm.time;
                end

                obj.pool_type(i) = sm.bic_type;
                
                obj.pool_weights(i,:) = sm.bic_w;
                
                obj.pool_mu_t(i) = sm.bic_mu_t;

                obj.pool_v_tuning(i,:) = [sm.bic_azi(1) sm.bic_ele(1)]*180/pi;
                obj.pool_a_tuning(i,:) = [sm.bic_azi(2) sm.bic_ele(2)]*180/pi;
                obj.pool_j_tuning(i,:) = [sm.bic_azi(3) sm.bic_ele(3)]*180/pi;
                
                obj.pool_n(i,1) = sm.bic_vn;
                obj.pool_n(i,2) = sm.bic_an;
                obj.pool_n(i,3) = sm.bic_jn;
                
                obj.pool_DC(i,1) = sm.bic_v_DC;
                obj.pool_DC(i,2) = sm.bic_a_DC;
                obj.pool_DC(i,3) = sm.bic_j_DC;
                
                obj.pool_A(i) = sm.bic_A;
                obj.pool_R_0(i) = sm.bic_R_0;
                
                obj.pool_match(obj.true_type(i), obj.pool_type(i)) = ...
                    obj.pool_match(obj.true_type(i), obj.pool_type(i))+1;
                
                if obj.true_type(i) ~= obj.pool_type(i),
                    obj.mismatches(i) = 1;
                end

%                 [tvx, tvy, tvz] = sph2cart(obj.true_v_tuning(i,1)*pi/180, ...
%                                            obj.true_v_tuning(i,2)*pi/180, 1);
%                 [tax, tay, taz] = sph2cart(obj.true_a_tuning(i,1)*pi/180, ...
%                                            obj.true_a_tuning(i,2)*pi/180, 1);  
%                 [tjx, tjy, tjz] = sph2cart(obj.true_j_tuning(i,1)*pi/180, ...
%                                            obj.true_j_tuning(i,2)*pi/180, 1);
% 
%                 [pvx, pvy, pvz] = sph2cart(obj.pool_v_tuning(i,1)*pi/180, ...
%                                            obj.pool_v_tuning(i,2)*pi/180, 1);
%                 [pax, pay, paz] = sph2cart(obj.pool_a_tuning(i,1)*pi/180, ...
%                                            obj.pool_a_tuning(i,2)*pi/180, 1);  
%                 [pjx, pjy, pjz] = sph2cart(obj.pool_j_tuning(i,1)*pi/180, ...
%                                            obj.pool_j_tuning(i,2)*pi/180, 1);
% 
%                 v_ang = acos(diag([tvx tvy tvz]*[pvx pvy pvz]'))*180/pi;
%                 j_ang = acos(diag([tjx tjy tjz]*[pjx pjy pjz]'))*180/pi;
%                 a_ang = acos(diag([tax tay taz]*[pax pay paz]'))*180/pi;
% 
%                 %dif_n = abs(obj.pool_n(i,1) - obj.true_n(i,1));
%                 
%                 dif_weights = obj.pool_weights(:,3) - obj.true_weights(:,3);
%                 if  dif_weights, %j_ang > 100, %dif_n > 1,
%                     sm.plotPSTH(i, ['r' num2str(obj.true_type(i))  ...
%                                     data_dir(i).name(5:end)], ...
%                        ['..' filesep '..' filesep ...
%                         'Paper_Figures' filesep 'SI_Figures' filesep]);
%                     
%                     tm = trueModel2(dat.p);
%                     tm.plotPSTH(i, ['t' num2str(obj.true_type(i)) ...
%                                     data_dir(i).name(5:end)], ...
%                        ['..' filesep '..' filesep ...
%                         'Paper_Figures' filesep 'SI_Figures' filesep]);
%                 end
            end
            
            obj.mismatches = obj.mismatches == 1;   
        end

        function plotMatches(obj)
            count_match = 0;
            count_mismatch = 0;
            for i=1:7,
                for j=1:7,
                    if i == j,
                        count_match = count_match + 1;
                    else
                        count_mismatch = count_mismatch + 1;
                    end
                end
            end
            total_cells = count_match + count_mismatch;
            disp([count_match/total_cells count_mismatch/total_cells]);
            
            disp(obj.pool_match);
            match = obj.pool_match/max(obj.pool_match(:));
            disp(match);
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            hold on;
            for i = 1:7,
                for j = 1:7,
                    if match(i,j) > 0,
                        plot([1 2], [i j], '-', ...
                             'linewidth', 20*match(i,j), ...
                             'color', (1-match(i,j))*[1 0 0]);
                    end
                end
            end
            hold off;
            ylim([0 8]);
            set(gca,'YTickLabel',{'', 'V', 'A', 'J', 'VA', 'VJ', 'AJ', 'VAJ', ''});
        end
        
        function plotTuningDiff(obj)
            [tvx, tvy, tvz] = sph2cart(obj.true_v_tuning(:,2)*pi/180, ...
                                       obj.true_v_tuning(:,1)*pi/180, 1);
            [tax, tay, taz] = sph2cart(obj.true_a_tuning(:,2)*pi/180, ...
                                       obj.true_a_tuning(:,1)*pi/180, 1);  
            [tjx, tjy, tjz] = sph2cart(obj.true_j_tuning(:,2)*pi/180, ...
                                       obj.true_j_tuning(:,1)*pi/180, 1);
                                   
            [pvx, pvy, pvz] = sph2cart(obj.pool_v_tuning(:,2)*pi/180, ...
                                       obj.pool_v_tuning(:,1)*pi/180, 1);
            [pax, pay, paz] = sph2cart(obj.pool_a_tuning(:,2)*pi/180, ...
                                       obj.pool_a_tuning(:,1)*pi/180, 1);  
            [pjx, pjy, pjz] = sph2cart(obj.pool_j_tuning(:,2)*pi/180, ...
                                       obj.pool_j_tuning(:,1)*pi/180, 1);
           
%             v_ang = acos(diag([tvx tvy tvz]*[pvx pvy pvz]'))*180/pi;
%             j_ang = acos(diag([tjx tjy tjz]*[pjx pjy pjz]'))*180/pi;
%             a_ang = acos(diag([tax tay taz]*[pax pay paz]'))*180/pi;
            
            v_ang = diag([tvx tvy tvz]*[pvx pvy pvz]');
            j_ang = diag([tjx tjy tjz]*[pjx pjy pjz]');
            a_ang = diag([tax tay taz]*[pax pay paz]');
            
%             v_ang = v_ang(obj.mismatches); 
%             j_ang = j_ang(obj.mismatches); 
%             a_ang = a_ang(obj.mismatches); 
          
            bins = 0:0.01*pi:pi;

            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(3,1,1);
            den = histc(v_ang, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'r');
            box off;
            ylabel('Percent');
            xlabel('Vel. Angle Error');
            
            subplot(3,1,2);
            den = histc(a_ang, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'b');
            box off;
            ylabel('Percent');
            xlabel('Acc. Angle Error');
            
            subplot(3,1,3);
            den = histc(j_ang, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'g');
            box off;
            ylabel('Percent');
            xlabel('Jer. Angle Error');
        end
        
        function plotWeightDiff(obj)
            bins = -1:0.01:1;
            dif_v_weights = obj.pool_weights(:,1) - obj.true_weights(:,1);
            dif_a_weights = obj.pool_weights(:,2) - obj.true_weights(:,2);
            dif_j_weights = obj.pool_weights(:,3) - obj.true_weights(:,3);
            
%             dif_v_weights = obj.pool_weights(obj.mismatches,1) - ...
%                             obj.true_weights(obj.mismatches,1);
%             dif_a_weights = obj.pool_weights(obj.mismatches,2) - ...
%                             obj.true_weights(obj.mismatches,2);
%             dif_j_weights = obj.pool_weights(obj.mismatches,3) - ...
%                             obj.true_weights(obj.mismatches,3);
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(3,1,1);
            den = histc(dif_v_weights, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'r');
            box off;
            ylabel('Percent');
            xlabel('Vel. Weights Error');
            subplot(3,1,2);
            den = histc(dif_a_weights, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'b');
            box off;
            ylabel('Percent');
            xlabel('Acc. Weights Error');
            subplot(3,1,3);
            den = histc(dif_j_weights, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'g');
            box off;
            ylabel('Percent');
            xlabel('Jer. Weights Error');
        end
        
        function plotNonlinearityDiff(obj)
            bins = -10:0.1:10;
            dif_v_n = obj.pool_n(:,1) - obj.true_n(:,1);
            dif_a_n = obj.pool_n(:,2) - obj.true_n(:,2);
            dif_j_n = obj.pool_n(:,3) - obj.true_n(:,3);
            
%             dif_v_n = obj.pool_n(obj.mismatches,1) - obj.true_n(obj.mismatches,1);
%             dif_a_n = obj.pool_n(obj.mismatches,2) - obj.true_n(obj.mismatches,2);
%             dif_j_n = obj.pool_n(obj.mismatches,3) - obj.true_n(obj.mismatches,3);
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(3,1,1);
            den = histc(dif_v_n, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'r');
            box off;
            ylabel('Percent');
            xlabel('Vel. Nonlinearity Error');
            subplot(3,1,2);
            den = histc(dif_a_n, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'b');
            box off;
            ylabel('Percent');
            xlabel('Acc. Nonlinearity Error');
            subplot(3,1,3);
            den = histc(dif_j_n, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'g');
            box off;
            ylabel('Percent');
            xlabel('Jer. Nonlinearity Error');
        end
        
        function plotDCDiff(obj)
            bins = -1:0.01:1;
            dif_v_DC = obj.pool_DC(:,1) - obj.true_DC(:,1);
            dif_a_DC = obj.pool_DC(:,2) - obj.true_DC(:,2);
            dif_j_DC = obj.pool_DC(:,3) - obj.true_DC(:,3);
            
%             dif_v_DC = obj.pool_DC(obj.mismatches,1) - ...
%                        obj.true_DC(obj.mismatches,1);
%             dif_a_DC = obj.pool_DC(obj.mismatches,2) - ...
%                        obj.true_DC(obj.mismatches,2);
%             dif_j_DC = obj.pool_DC(obj.mismatches,3) - ...
%                        obj.true_DC(obj.mismatches,3);
            
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(3,1,1);
            den = histc(dif_v_DC, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'r');
            box off;
            ylabel('Percent');
            xlabel('Vel. DC Error');
            subplot(3,1,2);
            den = histc(dif_a_DC, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'b');
            box off;
            ylabel('Percent');
            xlabel('Acc. DC Error');
            subplot(3,1,3);
            den = histc(dif_j_DC, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'g');
            box off;
            ylabel('Percent');
            xlabel('Jer. DC Error');
        end
        
        function plotTimeDiff(obj)
            bins = -1.5:0.01:1.5;
            dif_mu = obj.pool_mu_t - obj.true_mu_t;

            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(3,1,1);
            den = histc(dif_mu, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'r');
            box off;
            ylabel('Percent');
            xlabel('Vel. MU Error');
            subplot(3,1,2);
            den = histc(dif_mu, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'b');
            box off;
            ylabel('Percent');
            xlabel('Acc. MU Error');
            subplot(3,1,3);
            den = histc(dif_mu, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'g');
            box off;
            ylabel('Percent');
            xlabel('Jer. MU Error');
        end
        
        function plotWeightsvsParam(obj, path, plotname)
            true_v_weights = obj.true_weights(:,1);
            true_a_weights = obj.true_weights(:,2);
            true_j_weights = obj.true_weights(:,3);

            [tvx, tvy, tvz] = sph2cart(obj.true_v_tuning(:,1)*pi/180, ...
                                       obj.true_v_tuning(:,2)*pi/180, 1);
            [tax, tay, taz] = sph2cart(obj.true_a_tuning(:,1)*pi/180, ...
                                       obj.true_a_tuning(:,2)*pi/180, 1);  
            [tjx, tjy, tjz] = sph2cart(obj.true_j_tuning(:,1)*pi/180, ...
                                       obj.true_j_tuning(:,2)*pi/180, 1);
                                   
            [pvx, pvy, pvz] = sph2cart(obj.pool_v_tuning(:,1)*pi/180, ...
                                       obj.pool_v_tuning(:,2)*pi/180, 1);
            [pax, pay, paz] = sph2cart(obj.pool_a_tuning(:,1)*pi/180, ...
                                       obj.pool_a_tuning(:,2)*pi/180, 1);  
            [pjx, pjy, pjz] = sph2cart(obj.pool_j_tuning(:,1)*pi/180, ...
                                       obj.pool_j_tuning(:,2)*pi/180, 1);
           
            v_ang = acos(diag([tvx tvy tvz]*[pvx pvy pvz]'))*180/pi;
            j_ang = acos(diag([tjx tjy tjz]*[pjx pjy pjz]'))*180/pi;
            a_ang = acos(diag([tax tay taz]*[pax pay paz]'))*180/pi;

            dif_v_weights = obj.pool_weights(:,1) - obj.true_weights(:,1);
            dif_a_weights = obj.pool_weights(:,2) - obj.true_weights(:,2);
            dif_j_weights = obj.pool_weights(:,3) - obj.true_weights(:,3);
            
            dif_v_n = obj.pool_n(:,1) - obj.true_n(:,1);
            dif_a_n = obj.pool_n(:,2) - obj.true_n(:,2);
            dif_j_n = obj.pool_n(:,3) - obj.true_n(:,3);
            
            dif_v_DC = obj.pool_DC(:,1) - obj.true_DC(:,1);
            dif_a_DC = obj.pool_DC(:,2) - obj.true_DC(:,2);
            dif_j_DC = obj.pool_DC(:,3) - obj.true_DC(:,3);
            
            dif_mu = obj.pool_mu_t - obj.true_mu_t;
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(5,3,1);            
            plot(v_ang(obj.mismatches), ...
                 true_v_weights(obj.mismatches), '*'); 
            hold on;
            plot(v_ang(~obj.mismatches), ...
                 true_v_weights(~obj.mismatches), 'r*'); 
            hold off;
            box off;
            xlim([0 180]);
            ylabel('True Vel. Weights');
            xlabel('Dif. in Vel. Angle');
            
            subplot(5,3,2);            
            plot(a_ang(obj.mismatches), ...
                 true_a_weights(obj.mismatches), '*');
            hold on;
            plot(a_ang(~obj.mismatches), ...
                 true_a_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            xlim([0 180]);
            ylabel('True Acc. Weights');
            xlabel('Dif. in Acc. Angle');
            
            subplot(5,3,3);            
            plot(j_ang(obj.mismatches), ...
                 true_j_weights(obj.mismatches), '*');
            hold on;
            plot(j_ang(~obj.mismatches), ...
                 true_j_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            xlim([0 180]);
            ylabel('True Jer. Weights');
            xlabel('Dif. in Jer. Angle');
            
            subplot(5,3,4);            
            plot(dif_v_weights(obj.mismatches), ...
                 true_v_weights(obj.mismatches), '*'); 
            hold on;
            plot(dif_v_weights(~obj.mismatches), ...
                 true_v_weights(~obj.mismatches), 'r*'); 
            hold off;
            box off;
            xlim([-1 1]);
            ylabel('True Vel. Weights');
            xlabel('Dif. in Vel. Weights');
            
            subplot(5,3,5);            
            plot(dif_a_weights(obj.mismatches), ...
                 true_a_weights(obj.mismatches), '*');
            hold on;
            plot(dif_a_weights(~obj.mismatches), ...
                 true_a_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            xlim([-1 1]);
            ylabel('True Acc. Weights');
            xlabel('Dif. in Acc. Weights');
            
            subplot(5,3,6);            
            plot(dif_j_weights(obj.mismatches), ...
                 true_j_weights(obj.mismatches), '*');
            hold on;
            plot(dif_j_weights(~obj.mismatches), ...
                 true_j_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            xlim([-1 1]);
            ylabel('True Jer. Weights');
            xlabel('Dif. in Jer. Weights');
            
            subplot(5,3,7);            
            plot(dif_v_n(obj.mismatches), ...
                 true_v_weights(obj.mismatches), '*'); 
            hold on;
            plot(dif_v_n(~obj.mismatches), ...
                 true_v_weights(~obj.mismatches), 'r*'); 
            hold off;
            box off;
            xlim([-10 10]);
            ylabel('True Vel. Weights');
            xlabel('Dif. in Vel. Nonlinearity');
            
            subplot(5,3,8);            
            plot(dif_a_n(obj.mismatches), ...
                 true_a_weights(obj.mismatches), '*');
            hold on;
            plot(dif_a_n(~obj.mismatches), ...
                 true_a_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            xlim([-10 10]);
            ylabel('True Acc. Weights');
            xlabel('Dif. in Acc. Nonlinearity');
            
            subplot(5,3,9);            
            plot(dif_j_n(obj.mismatches), ...
                 true_j_weights(obj.mismatches), '*');
            hold on;
            plot(dif_j_n(~obj.mismatches), ...
                 true_j_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            xlim([-10 10]);
            ylabel('True Jer. Weights');
            xlabel('Dif. in Jer. Nonlinearity');
            
            subplot(5,3,10);            
            plot(dif_v_DC(obj.mismatches), ...
                 true_v_weights(obj.mismatches), '*'); 
            hold on;
            plot(dif_v_DC(~obj.mismatches), ...
                 true_v_weights(~obj.mismatches), 'r*'); 
            hold off;
            box off;
            xlim([-1 1]);
            ylabel('True Vel. Weights');
            xlabel('Dif. in Vel. DC');
            
            subplot(5,3,11);            
            plot(dif_a_DC(obj.mismatches), ...
                 true_a_weights(obj.mismatches), '*');
            hold on;
            plot(dif_a_DC(~obj.mismatches), ...
                 true_a_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            xlim([-1 1]);
            ylabel('True Acc. Weights');
            xlabel('Dif. in Acc. DC');
            
            subplot(5,3,12);            
            plot(dif_j_DC(obj.mismatches), ...
                 true_j_weights(obj.mismatches), '*');
            hold on;
            plot(dif_j_DC(~obj.mismatches), ...
                 true_j_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            xlim([-1 1]);
            ylabel('True Jer. Weights');
            xlabel('Dif. in Jer. DC');

            subplot(5,3,13);            
            plot(dif_mu(obj.mismatches), ...
                 true_v_weights(obj.mismatches), '*'); 
            hold on;
            plot(dif_mu(~obj.mismatches), ...
                 true_v_weights(~obj.mismatches), 'r*'); 
            hold off;
            box off;
            xlim([-1.5 1.5]);
            ylabel('True Vel. Weights');
            xlabel('Dif. in \mu_t');
            
            subplot(5,3,14);            
            plot(dif_mu(obj.mismatches), ...
                 true_a_weights(obj.mismatches), '*');
            hold on;
            plot(dif_mu(~obj.mismatches), ...
                 true_a_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            xlim([-1.5 1.5]);
            ylabel('True Acc. Weights');
            xlabel('Dif. in \mu_t');
            
            subplot(5,3,15);            
            plot(dif_mu(obj.mismatches), ...
                 true_j_weights(obj.mismatches), '*');
            hold on;
            plot(dif_mu(~obj.mismatches), ...
                 true_j_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            xlim([-1.5 1.5]);
            ylabel('True Jer. Weights');
            xlabel('Dif. in \mu_t');
            
            if nargin == 3,
                set(gcf,'PaperUnits', 'Centimeters');
                xSize = 17.6; ySize = 17.6;
                
                set(gcf,'PaperSize',[21 29.7]);
                set(gcf,'PaperPosition',[0 0 xSize ySize]);
                set(gcf,'Position',[0 0 xSize*50 ySize*50]);

                saveas(gcf, [path plotname '.pdf'], 'pdf');
                close(gcf);
            end
        end
        
        function plotTruevsReconParam(obj, path, plotname)
            true_mu_t = obj.true_mu_t;
            
            true_v_weights = obj.true_weights(:,1);
            true_a_weights = obj.true_weights(:,2);
            true_j_weights = obj.true_weights(:,3);
            
            true_v_n = obj.true_n(:,1);
            true_a_n = obj.true_n(:,2);
            true_j_n = obj.true_n(:,3);

            true_v_DC = obj.true_DC(:,1);
            true_a_DC = obj.true_DC(:,2);
            true_j_DC = obj.true_DC(:,3);
            
            recon_mu_t = obj.pool_mu_t;
            
            recon_v_weights = obj.pool_weights(:,1);
            recon_a_weights = obj.pool_weights(:,2);
            recon_j_weights = obj.pool_weights(:,3);
            
            recon_v_n = obj.pool_n(:,1);
            recon_a_n = obj.pool_n(:,2);
            recon_j_n = obj.pool_n(:,3);
            
            recon_v_DC = obj.pool_DC(:,1);
            recon_a_DC = obj.pool_DC(:,2);
            recon_j_DC = obj.pool_DC(:,3);
            
            [tvx, tvy, tvz] = sph2cart(obj.true_v_tuning(:,1)*pi/180, ...
                                       obj.true_v_tuning(:,2)*pi/180, 1);
            [tax, tay, taz] = sph2cart(obj.true_a_tuning(:,1)*pi/180, ...
                                       obj.true_a_tuning(:,2)*pi/180, 1);  
            [tjx, tjy, tjz] = sph2cart(obj.true_j_tuning(:,1)*pi/180, ...
                                       obj.true_j_tuning(:,2)*pi/180, 1);
                                   
            [pvx, pvy, pvz] = sph2cart(obj.pool_v_tuning(:,1)*pi/180, ...
                                       obj.pool_v_tuning(:,2)*pi/180, 1);
            [pax, pay, paz] = sph2cart(obj.pool_a_tuning(:,1)*pi/180, ...
                                       obj.pool_a_tuning(:,2)*pi/180, 1);  
            [pjx, pjy, pjz] = sph2cart(obj.pool_j_tuning(:,1)*pi/180, ...
                                       obj.pool_j_tuning(:,2)*pi/180, 1);
           
            v_ang = acos(diag([tvx tvy tvz]*[pvx pvy pvz]'))*180/pi;
            j_ang = acos(diag([tjx tjy tjz]*[pjx pjy pjz]'))*180/pi;
            a_ang = acos(diag([tax tay taz]*[pax pay paz]'))*180/pi;
            
            figure;
            type_3 = obj.true_type == 7;      
                 
            plot([0 1], [0 1], 'k-');
            hold on;
            plot([true_v_weights(type_3); ...
                  true_a_weights(type_3); ...
                  true_j_weights(type_3)], ...
                  [recon_v_weights(type_3); ... 
                  recon_a_weights(type_3); ...
                  recon_j_weights(type_3)], '*b');
            hold off;
            axis square;
            line([1 1]/3, ylim, 'color', 'k');
            line([1 1]*2/3, ylim, 'color', 'k');
            ylabel('Reco');
            xlabel('True');
            
            [~, idx] = min(obj.true_weights(type_3, :), [], 2);
            disp(obj.true_weights(type_3, idx));
            disp(obj.true_weights(type_3, :));
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');

            subplot(5,3,1);   
            plot([0 1], [0 1], '-k');
            hold on;
            plot(recon_a_weights(obj.mismatches), ...
                 true_a_weights(obj.mismatches), '*');
            plot(recon_a_weights(~obj.mismatches), ...
                 true_a_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            axis square;
            set(gca, 'XTick', [0 0.5 1]);
            set(gca, 'YTick', [0 0.5 1]);
            ylabel({'True', 'Weights'});
            xlabel({'Fitted', 'Weights'});
            title('Velocity');
            
            subplot(5,3,2);  
            plot([0 1], [0 1], '-k');
            hold on;
            plot(recon_j_weights(obj.mismatches), ...
                 true_j_weights(obj.mismatches), '*');
            plot(recon_j_weights(~obj.mismatches), ...
                 true_j_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            axis square;
            set(gca, 'XTick', [0 0.5 1]);
            set(gca, 'YTick', [0 0.5 1]);
            xlabel({'Fitted', 'Weights'});
            title('Acceleration');

            subplot(5,3,3);
            plot([0 1], [0 1], '-k');
            hold on;
            plot(recon_v_weights(obj.mismatches), ...
                 true_v_weights(obj.mismatches), '*'); 
            plot(recon_v_weights(~obj.mismatches), ...
                 true_v_weights(~obj.mismatches), 'r*'); 
            hold off;
            box off;
            axis square;
            set(gca, 'XTick', [0 0.5 1]);
            set(gca, 'YTick', [0 0.5 1]);
            xlabel({'Fitted', 'Weights'});
            title('Jerk');
            
            subplot(5,3,4); 
            plot([0 10], [0 10], '-k');
            hold on;
            plot(recon_v_n(obj.mismatches), ...
                 true_v_n(obj.mismatches), '*'); 
            plot(recon_v_n(~obj.mismatches), ...
                 true_v_n(~obj.mismatches), 'r*'); 
            hold off;
            box off;
            axis square;
            set(gca, 'XTick', [0 5 10]);
            set(gca, 'YTick', [0 5 10]);
            ylabel({'True', 'Nonlinearity'});
           xlabel({'Fitted', 'Nonlinearity'});
            
            
            subplot(5,3,5); 
            plot([0 10], [0 10], '-k');
            hold on;
            plot(recon_a_n(obj.mismatches), ...
                 true_a_n(obj.mismatches), '*');
            plot(recon_a_n(~obj.mismatches), ...
                 true_a_n(~obj.mismatches), 'r*');
            hold off;
            box off;
            axis square;
            set(gca, 'XTick', [0 5 10]);
            set(gca, 'YTick', [0 5 10]);
            xlabel({'Fitted', 'Nonlinearity'});
            
            subplot(5,3,6);
            plot([0 10], [0 10], '-k');
            hold on;
            plot(recon_j_n(obj.mismatches), ...
                 true_j_n(obj.mismatches), '*');
            plot(recon_j_n(~obj.mismatches), ...
                 true_j_n(~obj.mismatches), 'r*');
            hold off;
            box off;
            axis square;
            set(gca, 'XTick', [0 5 10]);
            set(gca, 'YTick', [0 5 10]);
            xlabel({'Fitted', 'Nonlinearity'});
            
            subplot(5,3,7);   
            plot([0 1], [0 1], '-k');
            hold on;
            plot(recon_v_DC(obj.mismatches), ...
                 true_v_DC(obj.mismatches), '*'); 
            plot(recon_v_DC(~obj.mismatches), ...
                 true_v_DC(~obj.mismatches), 'r*'); 
            hold off;
            box off;
            axis square;
            set(gca, 'XTick', [0 0.5 1]);
            set(gca, 'YTick', [0 0.5 1]);
            ylabel('True DC');
            xlabel('Fitted DC');
            
            subplot(5,3,8); 
            plot([0 1], [0 1], '-k');
            hold on;
            plot(recon_a_DC(obj.mismatches), ...
                 true_a_DC(obj.mismatches), '*');
            plot(recon_a_DC(~obj.mismatches), ...
                 true_a_DC(~obj.mismatches), 'r*');
            hold off;
            box off;
            set(gca, 'XTick', [0 0.5 1]);
            set(gca, 'YTick', [0 0.5 1]);
            xlabel('Fitted DC');
            
            subplot(5,3,9); 
            plot([0 1], [0 1], '-k');
            hold on;
            plot(recon_j_DC(obj.mismatches), ...
                 true_j_DC(obj.mismatches), '*');
            plot(recon_j_DC(~obj.mismatches), ...
                 true_j_DC(~obj.mismatches), 'r*');
            hold off;
            box off;
            axis square;
            set(gca, 'XTick', [0 0.5 1]);
            set(gca, 'YTick', [0 0.5 1]);
            xlabel('Fitted DC');
            
            subplot(5,3,10);    
            x = 1:10:180;
            y = histc(v_ang(obj.mismatches), x);
            y = y/sum(y)*100;
            plot(x, y, '-b');
            hold on;
            y = histc(v_ang(~obj.mismatches), x);
            y = y/sum(y)*100;
            plot(x, y, '-r');
            hold off;
            box off;
            set(gca, 'XTick', [0 90 180]);
            set(gca, 'YTick', [0 50 100]);
            xlim([0 180]);
            ylabel('Percentage');
            xlabel({'Difference', 'in Angle (\circ)'});
            
            subplot(5,3,11);            
            x = 1:10:180;
            y = histc(a_ang(obj.mismatches), x);
            y = y/sum(y)*100;
            plot(x, y, '-b');
            hold on;
            y = histc(a_ang(~obj.mismatches), x);
            y = y/sum(y)*100;
            plot(x, y, '-r');
            hold off;
            box off;
            set(gca, 'XTick', [0 90 180]);
            set(gca, 'YTick', [0 50 100]);
            xlim([0 180]);
            xlabel({'Difference', 'in Angle (\circ)'});
            
            subplot(5,3,12);            
            x = 1:10:180;
            y = histc(j_ang(obj.mismatches), x);
            y = y/sum(y)*100;
            plot(x, y, '-b');
            hold on;
            y = histc(j_ang(~obj.mismatches), x);
            y = y/sum(y)*100;
            plot(x, y, '-r');
            hold off;
            box off;
            set(gca, 'XTick', [0 90 180]);
            set(gca, 'YTick', [0 50 100]);
            xlim([0 180]);
            xlabel({'Difference', 'in Angle (\circ)'});  
            
            subplot(5,3,13);  
            plot([0 0.5], [0 0.5], '-k');
            hold on;
            plot(recon_mu_t(obj.mismatches)-1, ...
                 true_mu_t(obj.mismatches)-1, '*'); 
            plot(recon_mu_t(~obj.mismatches)-1, ...
                 true_mu_t(~obj.mismatches)-1, 'r*'); 
            hold off;
            box off;
            xlim([0 0.5]);
            ylim([0 0.5]);
            set(gca, 'XTick', [0 0.2 0.5]);
            set(gca, 'YTick', [0 0.2 0.5]);
            ylabel({'True', 'Delay (s)'});
            xlabel({'Fitted', 'Delay (s)'});

            sp = subplot(5,3,[14 15]);
            %spos = get(sp, 'Position');
            %set(sp, 'Position', [spos(1:2) spos(3)*0.75 spos(4)]);
            tot = repmat(sum(obj.pool_match, 2), 1,7);
            per = obj.pool_match./tot*100;
            per = per(end:-1:1,:);
            imagesc(per);
            axis image;
            set(gca, 'CLim', [0 100]);
            set(gca, 'XTick', 1:7);
            set(gca, 'XTickLabel', {'V', 'A', 'J', 'VA', 'VJ', 'AJ', 'VAJ'});
            rotateXLabels(gca(), 90);
            set(gca, 'YTick', 1:7);
            set(gca, 'YTickLabel', {'VAJ', 'AJ', 'VJ', 'VA', 'J', 'A', 'V'});
            %set(gca, 'YTickLabel', {'V', 'A', 'J', 'VA', 'VJ', 'AJ', 'VAJ'});
            %set(gca, 'FontSize', 8);
            xlabel('Fitted Model');
            ylabel('True Model');
            colorbar('YTick', [0, 25, 50, 75, 100]);
            set(findall(gcf,'type','text'),'fontSize',8);
            
            if nargin == 3,
                set(gcf,'PaperUnits', 'Centimeters');
                xSize = 8.5; ySize = 17;
                
                set(gcf,'PaperSize',[20 25]);
                set(gcf,'PaperPosition',[0 0 xSize ySize]);
                set(gcf,'Position',[0 0 xSize*50 ySize*50]);

                saveas(gcf, [path plotname '.pdf'], 'pdf');
                close(gcf);
            end
        end
    end
end