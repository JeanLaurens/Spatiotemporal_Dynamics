classdef fitAccJer
    properties
        reps
        psth

        u_azi
        u_ele
        time
            
        baseline
        
        A
        R_0
        mu_t
        
        a_ele_azi_profile
        a_space_profile
        a_A
        a_n
        a_a_0
        a_e_0
        a_DC

        j_ele_azi_profile
        j_space_profile
        j_A
        j_n
        j_a_0
        j_e_0
        j_DC
        
        w
        
        init_param
        
        accjer_param
        rand_param
        
        accjer_rss       
        rand_rss
        
        accjer_jac
        rand_jac
    end
    
    methods
        function obj = fitAccJer(p, reps)
            obj.reps = reps;
            obj.psth = p.psth;
            
            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            obj.baseline = p.baseline;
            
            stim_sig = sqrt(sqrt(2))/6;
            peak_i = find(obj.time >= 1, 1, 'first')-1;
            
            %Compute Temporal Profiles
            c = cell(2,1);
            lags = cell(2,1);
            idx = zeros(2,1);
            m = zeros(2,1);
            d_gauss_time = d_gauss([1 stim_sig], obj.time)';
            [cl, l] = xcorr(d_gauss_time, p.t_profile1, 20, 'coeff');
            neg_lags_idx = l < 0;
            lags{1} = l(neg_lags_idx);
            c{1} = cl(neg_lags_idx);
            [m(1), idx(1)] = max(abs(c{1}));
            
            d2_gauss_time = d2_gauss([1 stim_sig], obj.time)';
            [cl, l] = xcorr(d2_gauss_time, p.t_profile1, 20, 'coeff');
            lags{2} = l(neg_lags_idx);
            c{2} = cl(neg_lags_idx);
            [m(2), idx(2)] = max(abs(c{2}));
            
            profile1 = p.s_profile1;
            profile1(:,1) = profile1(1,1);
            profile1(:,end) = profile1(1,end);
            profile1(end,:) = profile1(1,:);
            
            profile2 = p.s_profile2;
            profile2(:,1) = profile2(1,1);
            profile2(:,end) = profile2(1,end);
            profile2(end,:) = profile2(1,:);

            [~,max_1] = max(m);
            switch max_1
                case 1
                    idx_i = idx(1);
                    delay_i = lags{1}(idx(1));
                    obj.mu_t = obj.time(peak_i - delay_i);
                    a_t_A = (max(p.t_profile1)-min(p.t_profile1))/...
                            (max(d_gauss_time)-min(d_gauss_time)); 
                    j_t_A = (max(p.t_profile2)-min(p.t_profile2))/...
                            (max(d2_gauss_time)-min(d2_gauss_time));
                    
                    s = 1;
                    if c{1}(idx_i) < 0,
                        s = -1;
                    end
                    obj.a_ele_azi_profile = s*profile1;
                    
                    cl = xcorr(d2_gauss_time, p.t_profile2, 'coeff');
                    c_t = cl(neg_lags_idx);
                    s = 1;
                    if c_t(idx_i) < 0,
                        s = -1;
                    end
                    obj.j_ele_azi_profile = s*profile2;
                    
                case 2
                    idx_i = idx(2);
                    delay_i = lags{2}(idx(2));
                    obj.mu_t = obj.time(peak_i - delay_i);
                    a_t_A = (max(p.t_profile2)-min(p.t_profile2))/...
                            (max(d_gauss_time)-min(d_gauss_time));
                    j_t_A = (max(p.t_profile1)-min(p.t_profile1))/...
                            (max(d2_gauss_time)-min(d2_gauss_time)); 
                    
                    cl = xcorr(d_gauss_time, p.t_profile2, 'coeff');
                    c_t = cl(neg_lags_idx);
                    s = 1;
                    if c_t(idx_i) < 0,
                        s = -1;
                    end
                    obj.a_ele_azi_profile = s*profile2;
                    
                    s = 1;
                    if c{2}(idx_i) < 0,
                        s = -1;
                    end                    
                    obj.j_ele_azi_profile = s*profile1;
            end

            %Compute Spatial Profiles
            obj.a_DC = (min(obj.a_ele_azi_profile(:))+max(obj.a_ele_azi_profile(:)))/2;
            a_s_A = (max(obj.a_ele_azi_profile(:))-min(obj.a_ele_azi_profile(:)))/2;         
            
            obj.a_space_profile = obj.a_ele_azi_profile-obj.a_DC;                                         
            obj.a_space_profile = obj.a_space_profile/a_s_A;  
            
            obj.j_DC = (min(obj.j_ele_azi_profile(:))+max(obj.j_ele_azi_profile(:)))/2;
            j_s_A = (max(obj.j_ele_azi_profile(:))-min(obj.j_ele_azi_profile(:)))/2;         
            
            obj.j_space_profile = obj.j_ele_azi_profile-obj.j_DC;                                         
            obj.j_space_profile = obj.j_space_profile/j_s_A;
            
            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);
            
            %Fit spatial profile
            s_data = [obj.u_ele; obj.u_azi];
            
            LB = [0.001 0 -pi/2];
            UB = [10 2*pi pi/2];
            
            [~, max_idx] = max(obj.a_space_profile(:));
            [max_idx_a, max_idx_e] = ind2sub(size(obj.a_space_profile), max_idx);
            param = [0.01 obj.u_azi(max_idx_a) obj.u_ele(max_idx_e)];
            recon_a = lsqcurvefit('cos_tuning', param, s_data, ...
                obj.a_space_profile(:), LB, UB, options);
            obj.a_n = recon_a(1);
            obj.a_a_0 = recon_a(2);
            obj.a_e_0 = recon_a(3);
            
            LB = [0.001 0 -pi/2];
            UB = [10 2*pi pi/2];
            
            [~, max_idx] = max(obj.j_space_profile(:));
            [max_idx_a, max_idx_e] = ind2sub(size(obj.j_space_profile), max_idx);
            param = [0.01 obj.u_azi(max_idx_a) obj.u_ele(max_idx_e)];
            recon_j = lsqcurvefit('cos_tuning', param, s_data, ...
                obj.j_space_profile(:), LB, UB, options);
            obj.j_n = recon_j(1);
            obj.j_a_0 = recon_j(2);
            obj.j_e_0 = recon_j(3);

           obj.a_A = a_t_A*a_s_A;
           obj.j_A = j_t_A*j_s_A;
           
           obj.a_DC = obj.a_DC/a_s_A;
           obj.j_DC = obj.j_DC/j_s_A;
           
           obj.A = obj.a_A+obj.j_A;
           obj.R_0 = obj.baseline;
           obj.w = obj.a_A/obj.A;

           %Initial fits
            param = [obj.A, ...     %1  A
                     obj.R_0, ...   %2  R_0
                     obj.mu_t, ...  %3  mu_t
                     obj.a_n, ...   %4  a_n     
                     obj.a_a_0, ... %5  a_a_0
                     obj.a_e_0, ... %6  a_e_0
                     obj.a_DC, ...  %7  a_DC
                     obj.j_n, ...   %8  j_n       
                     obj.j_a_0, ... %9  j_a_0
                     obj.j_e_0, ... %10 j_e_0
                     obj.j_DC, ...  %11 j_DC
                     obj.w];        %12 w
            
            obj.init_param = zeros(obj.reps+1, length(param));
            obj.init_param = param;
            
            y_data = packPSTH(obj.psth);
            
            LB = [0.25*obj.A, ...  %1  A
                  0, ...           %2  R_0
                  1, ...           %3  mu_t
                  0.001, ...       %4  a_n
                  0, ...           %5  a_a_0
                  -pi/2, ...       %6  a_e_0
                  0, ...           %7  a_DC
                  0.001, ...       %8  j_n
                  0, ...           %9  j_a_0
                  -pi/2, ...       %10 j_e_0
                  0, ...           %11 j_DC
                  0];              %12 w
              
            UB = [4*obj.A, ...     %1  A
                  300, ...         %2  R_0
                  1.5, ...         %3  mu_t
                  10, ...          %4  a_n
                  2*pi, ...        %5  a_a_0
                  pi/2, ...        %6  a_e_0
                  1, ...           %7  a_DC
                  10, ...          %8  j_n
                  2*pi, ...        %9  j_a_0
                  pi/2, ...        %10 j_e_0
                  1, ...           %11 j_DC
                  1];              %12 w
                       
            t_rand_rss = zeros(obj.reps+1,1);
            t_rand_param = zeros(obj.reps+1, length(param));
            t_rand_jac = zeros(obj.reps+1, length(param), length(param));
              
            [t_rand_param(1,:), t_rand_rss(1),~,~,~,~,tmp_jacobian] = ...
            lsqcurvefit('accjer_model', obj.init_param, st_data, y_data, LB, UB, options);
            t_rand_jac(1,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);  

            %Initial Conditions Random Range
            err_range =  0.1*(UB - LB);
            min_param = t_rand_param(1,:);
            UB_param = min_param+err_range;
            LB_param = min_param-err_range;
           
            parfor i=2:obj.reps+1,
                %Randomise Initial Conditions
                seed_param  = unifrnd(LB_param, UB_param);
                
                [t_rand_param(i,:), t_rand_rss(i),~,~,~,~,tmp_jacobian] = ...
                 lsqcurvefit('accjer_model', seed_param, st_data, y_data, LB, UB, options);
                 t_rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
            end
            
            obj.rand_param = t_rand_param;
            obj.rand_rss = t_rand_rss;
            obj.rand_jac = t_rand_jac;
            
            [~,min_idx] = min(obj.rand_rss);
            obj.accjer_param = obj.rand_param(min_idx,:);
            obj.accjer_rss = obj.rand_rss(min_idx);
            obj.accjer_jac = obj.rand_jac(min_idx,:,:);
        end
        
        function plotPSTH(obj, trial_name, page_num, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];           
            
            init_fit = accjer_model(obj.init_param(1,:), st_data);
            accjer_fit = accjer_model(obj.accjer_param, st_data);

            init_fit = unpackPSTH(init_fit, size(obj.psth));
            accjer_fit = unpackPSTH(accjer_fit, size(obj.psth));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(init_fit(i,j,:)), 'g');
                    plot(obj.time, squeeze(accjer_fit(i,j,:)), 'k');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page_num) ': ' trial_name];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                 'FontName', 'helvetica', 'FontSize', 12);
             
            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
        
        function printVal(obj)
            disp('Acceleration + Jerk');
            disp(['A    : ' num2str(obj.accjer_param(1))]);
            disp(['R_0  : ' num2str(obj.accjer_param(2))]);
            disp(['mu_t : ' num2str(obj.accjer_param(3))]);
            disp(['sig_t: ' num2str(obj.accjer_param(4))]);
            disp(['v_a_n: ' num2str(obj.accjer_param(5))]);
            disp(['v_a_0: ' num2str(obj.accjer_param(6))]);
            disp(['v_e_n: ' num2str(obj.accjer_param(7))]);
            disp(['v_e_0: ' num2str(obj.accjer_param(8))]);
            disp(['v_DC : ' num2str(obj.accjer_param(9))]);
            disp(['a_a_n: ' num2str(obj.accjer_param(10))]);
            disp(['a_a_0: ' num2str(obj.accjer_param(11))]);
            disp(['a_e_n: ' num2str(obj.accjer_param(12))]);
            disp(['a_e_0: ' num2str(obj.accjer_param(13))]);
            disp(['a_DC : ' num2str(obj.accjer_param(14))]);
            disp(['w    : ' num2str(obj.accjer_param(15))]);
        end
    end 
end
