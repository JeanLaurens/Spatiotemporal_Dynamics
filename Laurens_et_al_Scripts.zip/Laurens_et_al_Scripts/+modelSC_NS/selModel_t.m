classdef selModel_t
    properties
        psth
        u_azi
        u_ele
        
        time
        
        cv_star
        
        bic
        bic_pick
        bic_type
        bic_all
        
        bic_fit
        bic_model
        bic_param
        
        bic_mu_t
        
        bic_azi
        bic_ele

        bic_jac
        bic_rss
        bic_tss
        
        bic_w
        
        sp_vel
        sp_acc
        sp_jer
        
        sp_vel_param
        sp_acc_param
        sp_jer_param
        
        gauss_time
        d_gauss_time
        d2_gauss_time
        
        bic_A
        bic_R_0
        
        bic_vn
        bic_an
        bic_jn
        
        bic_v_DC
        bic_a_DC
        bic_j_DC
        
        true_type
    end
    
    methods
        function obj = selModel_t(p, ...
                                  fv, fa, fj, ...
                                  fva, fvj, faj, fvaj)
            
            obj.true_type = p.model_type;
                          
            obj.psth = p.psth;
            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;
            
            obj.cv_star = p.cv_star;
            
            n = length(packPSTH(p.psth));

            stim_sig = sqrt(sqrt(2))/6;
            
            d_gauss_t = d_gauss([1 stim_sig], obj.time)';
            a_h = (max(d_gauss_t) - min(d_gauss_t))/2;
            d2_gauss_t = d2_gauss([1 stim_sig], obj.time)';
            j_h = max(d2_gauss_t) - min(d2_gauss_t);
            
%             st_data = [obj.u_ele; obj.u_azi; obj.time'];           
%             dim = [length(obj.u_azi),length(obj.u_ele), length(obj.time)];

%             vel_fit = unpackPSTH(vel_model(fv.vel_param, st_data), dim);
%             acc_fit = unpackPSTH(acc_model(fa.acc_param, st_data), dim);
%             jer_fit = unpackPSTH(jer_model(fj.jer_param, st_data), dim);
%             
%             velacc_fit = unpackPSTH(velacc_model(fva.velacc_param, st_data), dim);
%             veljer_fit = unpackPSTH(veljer_model(fvj.veljer_param, st_data), dim);
%             accjer_fit = unpackPSTH(accjer_model(faj.accjer_param, st_data), dim);
%             
%             velaccjer_fit = unpackPSTH(velaccjer_model(fvaj.velaccjer_param, st_data), dim);
%             
%             vel_rss = norm(obj.psth(:) - vel_fit(:));
%             acc_rss = norm(obj.psth(:) - acc_fit(:));
%             jer_rss = norm(obj.psth(:) - jer_fit(:));
%             
%             velacc_rss = norm(obj.psth(:) - velacc_fit(:));
%             veljer_rss = norm(obj.psth(:) - veljer_fit(:));
%             accjer_rss = norm(obj.psth(:) - accjer_fit(:));
%             
%             velaccjer_rss = norm(obj.psth(:) - velaccjer_fit(:));
            
            v = n*log(fv.vel_rss/n) + 2*length(fv.vel_param)*log(n);
            a = n*log(fa.acc_rss/n) + 2*length(fa.acc_param)*log(n);
            j = n*log(fj.jer_rss/n) + 2*length(fj.jer_param)*log(n);
            
            va = n*log(fva.velacc_rss/n) + 2*length(fva.velacc_param)*log(n);
            vj = n*log(fvj.veljer_rss/n) + 2*length(fvj.veljer_param)*log(n);
            aj = n*log(faj.accjer_rss/n) + 2*length(faj.accjer_param)*log(n);
            
            vaj = n*log(fvaj.velaccjer_rss/n) + 2*length(fvaj.velaccjer_param)*log(n);

            obj.bic_all = [v a j va vj aj vaj];
            [obj.bic, obj.bic_type] = min(obj.bic_all);
            
            obj.bic_tss = sum((p.psth(:)-mean(p.psth(:))).^2);
            
            obj.bic_azi = nan(3, 1);
            obj.bic_ele = nan(3, 1);
            
            obj.bic_w = zeros(3, 1);
            
            s_data = [obj.u_ele; obj.u_azi];

%             obj.bic_type = obj.true_type;
            switch obj.bic_type,
                case 1
                    obj.bic_fit = fv;
                    obj.bic_model = @vel_model;
                    obj.bic_param = fv.vel_param;
                    obj.bic_azi(1) = obj.bic_param(5);
                    obj.bic_ele(1) = obj.bic_param(6);
    
                    obj.bic_jac = fv.vel_jac;
                    
                    obj.bic_rss = fv.rand_rss;
                    
                    obj.sp_vel_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_vel = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.gauss_time = gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d_gauss_time = NaN;
                    obj.d2_gauss_time = NaN;
                    
                    obj.bic_jac = fv.vel_jac;
                    
                    obj.bic_rss = fv.vel_rss;

                    obj.bic_w(1) = 1;
                    
                    obj.bic_A = obj.bic_param(1);
                    obj.bic_R_0 = obj.bic_param(2);
                    obj.bic_vn = obj.sp_vel_param(1);
                    obj.bic_an = NaN;
                    obj.bic_jn = NaN;
                    obj.bic_v_DC = obj.sp_vel_param(4);
                    obj.bic_a_DC = NaN;
                    obj.bic_j_DC = NaN;
                                
                case 2                    
                    obj.bic_fit = fa;
                    obj.bic_model = @acc_model;
                    obj.bic_param = fa.acc_param;
                    obj.bic_param(1) = obj.bic_param(1)/a_h;
                    obj.bic_azi(2) = obj.bic_param(5);
                    obj.bic_ele(2) = obj.bic_param(6);

                    obj.sp_acc_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_acc = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.gauss_time = NaN;
                    obj.d_gauss_time = d_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d2_gauss_time = NaN;
                    
                    obj.bic_jac = fa.acc_jac;
                    
                    obj.bic_rss = fa.acc_rss;

                    obj.bic_w(2) = 1;

                    obj.bic_A = obj.bic_param(1);
                    obj.bic_R_0 = obj.bic_param(2);
                    obj.bic_vn = NaN;
                    obj.bic_an = obj.sp_acc_param(1);
                    obj.bic_jn = NaN;
                    obj.bic_v_DC = NaN;
                    obj.bic_a_DC = obj.sp_acc_param(4);
                    obj.bic_j_DC = NaN;
      
                case 3
                    obj.bic_fit = fj;
                    obj.bic_model = @jer_model;
                    obj.bic_param = fj.jer_param;
                    obj.bic_param(1) = obj.bic_param(1)/j_h;
                    obj.bic_azi(3) = obj.bic_param(5);
                    obj.bic_ele(3) = obj.bic_param(6);

                    obj.sp_jer_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_jer = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.gauss_time = NaN;
                    obj.d_gauss_time = NaN;
                    obj.d2_gauss_time = d2_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    
                    obj.bic_jac = fj.jer_jac;
                    
                    obj.bic_rss = fj.jer_rss;

                    obj.bic_w(3) = 1;
                    
                    obj.bic_A = obj.bic_param(1);
                    obj.bic_R_0 = obj.bic_param(2);
                    obj.bic_vn = NaN;
                    obj.bic_an = NaN;
                    obj.bic_jn = obj.sp_jer_param(1);
                    obj.bic_v_DC = NaN;
                    obj.bic_a_DC = NaN;
                    obj.bic_j_DC = obj.sp_jer_param(4);
            
                case 4
                    obj.bic_fit = fva;
                    obj.bic_model = @velacc_model;
                    obj.bic_param = fva.velacc_param;
                    obj.bic_azi(1) = obj.bic_param(5);
                    obj.bic_ele(1) = obj.bic_param(6);
                    obj.bic_azi(2) = obj.bic_param(9);
                    obj.bic_ele(2) = obj.bic_param(10);
                
                    obj.bic_jac =  fva.velacc_jac;
                    
                    obj.bic_rss = fva.velacc_rss;

                    obj.sp_vel_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_vel = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_acc_param = [obj.bic_param(8:10) obj.bic_param(11)];
                    sp = cos_tuning(obj.bic_param(8:10), s_data) + obj.bic_param(11);
                    obj.sp_acc = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);                
                    obj.gauss_time = gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d_gauss_time = d_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d2_gauss_time = NaN;
                    
                    obj.bic_w(1) = obj.bic_param(12);
                    obj.bic_w(2) = 1 - obj.bic_param(12);
                    
                    obj.bic_w(2) = obj.bic_w(2)/a_h;
                    tot = obj.bic_w(1) + obj.bic_w(2);
                    
                    obj.bic_w(1) = obj.bic_w(1)/tot;
                    obj.bic_w(2) = obj.bic_w(2)/tot;
                    
                    obj.bic_param(12) = obj.bic_w(1);
                    obj.bic_param(1) = obj.bic_param(1)*tot;
                    
                    obj.bic_A = obj.bic_param(1);
                    obj.bic_R_0 = obj.bic_param(2);
                    obj.bic_vn = obj.sp_vel_param(1);
                    obj.bic_an = obj.sp_acc_param(1);
                    obj.bic_jn = NaN;
                    obj.bic_v_DC = obj.sp_vel_param(4);
                    obj.bic_a_DC = obj.sp_acc_param(4);
                    obj.bic_j_DC = NaN;
                
                case 5
                    obj.bic_fit = fvj;
                    obj.bic_model = @veljer_model;
                    obj.bic_param = fvj.veljer_param;
                    obj.bic_azi(1) = obj.bic_param(5);
                    obj.bic_ele(1) = obj.bic_param(6);
                    obj.bic_azi(3) = obj.bic_param(9);
                    obj.bic_ele(3) = obj.bic_param(10);

                    obj.bic_jac = fvj.veljer_jac;
                    
                    obj.bic_rss = fvj.veljer_rss;
                    
                    obj.sp_vel_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_vel = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_jer_param = [obj.bic_param(8:10) obj.bic_param(11)];
                    sp = cos_tuning(obj.bic_param(8:10), s_data) + obj.bic_param(11);
                    obj.sp_jer = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);                
                    obj.gauss_time = gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d_gauss_time = NaN;
                    obj.d2_gauss_time = d2_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    
                    obj.bic_w(1) = obj.bic_param(12);
                    obj.bic_w(3) = 1-obj.bic_param(12);
                    
                    obj.bic_w(3) = obj.bic_w(3)/j_h;
                    tot = obj.bic_w(1) + obj.bic_w(3);
                    
                    obj.bic_w(1) = obj.bic_w(1)/tot;
                    obj.bic_w(3) = obj.bic_w(3)/tot;
                    
                    obj.bic_param(12) = obj.bic_w(1);
                    obj.bic_param(1) = obj.bic_param(1)*tot;
                    
                    obj.bic_A = obj.bic_param(1);
                    obj.bic_R_0 = obj.bic_param(2);
                    obj.bic_vn = obj.sp_vel_param(1);
                    obj.bic_an = NaN;
                    obj.bic_jn = obj.sp_jer_param(1);
                    obj.bic_v_DC = obj.sp_vel_param(4);
                    obj.bic_a_DC = NaN;
                    obj.bic_j_DC = obj.sp_jer_param(4);
                    
                case 6
                    obj.bic_fit = faj;
                    obj.bic_model = @accjer_model;
                    obj.bic_param = faj.accjer_param;
                    obj.bic_azi(2) = obj.bic_param(5);
                    obj.bic_ele(2) = obj.bic_param(6);
                    obj.bic_azi(3) = obj.bic_param(9);
                    obj.bic_ele(3) = obj.bic_param(10);

                    obj.bic_jac = faj.accjer_jac;
                    
                    obj.bic_rss = faj.accjer_rss;
                    
                    obj.sp_acc_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_acc = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_jer_param = [obj.bic_param(8:10) obj.bic_param(11)];
                    sp = cos_tuning(obj.bic_param(8:10), s_data) + obj.bic_param(11);
                    obj.sp_jer = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.gauss_time = NaN;
                    obj.d_gauss_time = d_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d2_gauss_time = d2_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    
                    obj.bic_w(2) = obj.bic_param(12);
                    obj.bic_w(3) = 1-obj.bic_param(12);
                    
                    obj.bic_w(2) = obj.bic_w(2)/a_h;
                    obj.bic_w(3) = obj.bic_w(3)/j_h;
                    tot = obj.bic_w(2) + obj.bic_w(3);
                    
                    obj.bic_w(2) = obj.bic_w(2)/tot;
                    obj.bic_w(3) = obj.bic_w(3)/tot;
                    
                    obj.bic_param(12) = obj.bic_w(2);
                    obj.bic_param(1) = obj.bic_param(1)*tot;
                    
                    obj.bic_A = obj.bic_param(1);
                    obj.bic_R_0 = obj.bic_param(2);
                    obj.bic_vn = NaN;
                    obj.bic_an = obj.sp_acc_param(1);
                    obj.bic_jn = obj.sp_jer_param(1);
                    obj.bic_v_DC = NaN;
                    obj.bic_a_DC = obj.sp_acc_param(4);
                    obj.bic_j_DC = obj.sp_jer_param(4);
                    
                case 7
                    obj.bic_fit = fvaj;
                    obj.bic_model = @velaccjer_model;
                    obj.bic_param = fvaj.velaccjer_param;
                    obj.bic_azi(1) = obj.bic_param(5);
                    obj.bic_ele(1) = obj.bic_param(6);
                    obj.bic_azi(2) = obj.bic_param(9);
                    obj.bic_ele(2) = obj.bic_param(10);
                    obj.bic_azi(3) = obj.bic_param(13);
                    obj.bic_ele(3) = obj.bic_param(14);

                    obj.bic_jac = fvaj.velaccjer_jac;

                    obj.bic_rss = fvaj.velaccjer_rss;

                    obj.sp_vel_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_vel = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_acc_param = [obj.bic_param(8:10) obj.bic_param(11)];
                    sp = cos_tuning(obj.bic_param(8:10), s_data) + obj.bic_param(11);
                    obj.sp_acc = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_jer_param = [obj.bic_param(12:14) obj.bic_param(15)];
                    sp = cos_tuning(obj.bic_param(12:14), s_data) + obj.bic_param(15);
                    obj.sp_jer = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.gauss_time = gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d_gauss_time = d_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d2_gauss_time = d2_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    
                    w_v = obj.bic_param(16);
                    w_j = obj.bic_param(17);
                    obj.bic_w(1) = (1 - w_j)*w_v;
                    obj.bic_w(2) = (1 - w_j)*(1 - w_v);
                    obj.bic_w(3) = w_j;
                    
                    obj.bic_w(2) = obj.bic_w(2)/a_h;
                    obj.bic_w(3) = obj.bic_w(3)/j_h;
                    tot = obj.bic_w(1) + obj.bic_w(2) + obj.bic_w(3);
                    
                    obj.bic_w(1) = obj.bic_w(1)/tot;
                    obj.bic_w(2) = obj.bic_w(2)/tot;
                    obj.bic_w(3) = obj.bic_w(3)/tot;
                    
                    obj.bic_param(17) = obj.bic_w(3);
                    obj.bic_param(16) = obj.bic_w(1)/(1 - obj.bic_w(3));
                    obj.bic_param(1) = obj.bic_param(1)*tot;
                    
                    obj.bic_A = obj.bic_param(1);
                    obj.bic_R_0 = obj.bic_param(2);
                    obj.bic_vn = obj.sp_vel_param(1);
                    obj.bic_an = obj.sp_acc_param(1);
                    obj.bic_jn = obj.sp_jer_param(1);
                    obj.bic_v_DC = obj.sp_vel_param(4);
                    obj.bic_a_DC = obj.sp_acc_param(4);
                    obj.bic_j_DC = obj.sp_jer_param(4);
            end
        end
        
        function plotPSTH(obj, page, trial_name, path)
            labelsize = 6;
            st_data = [obj.u_ele; obj.u_azi; obj.time'];           
            dim = [length(obj.u_azi),length(obj.u_ele), length(obj.time)];

            model_fit = unpackPSTH(obj.bic_model(obj.bic_param, st_data), dim);  

            max_spikes = max([obj.psth(:); model_fit(:)]);
            min_spikes = min([obj.psth(:); model_fit(:)]);
            dif_spikes = (max_spikes-min_spikes)/2;
            
            model_err = zeros(26, length(obj.time));
            err_i = 0;
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    opos = get(gca, 'OuterPosition');
                    ipos = get(gca, 'Position');
                    set(gca, 'Position', [opos(1) ipos(2) opos(3) ipos(4)]);
                    area(obj.time, squeeze(obj.psth(i,j,:)), ...
                            'FaceColor', 'r', 'EdgeColor','r');
                    hold on;
%                     if all(~isnan(obj.gauss_time)),
%                         vel_comp = obj.bic_A*obj.bic_w(1)*obj.sp_vel(i,j)*obj.gauss_time + obj.bic_R_0;
%                         plot(obj.time, vel_comp, 'g.'); 
%                     end
%                     if all(~isnan(obj.d_gauss_time)),
%                         acc_comp = obj.bic_A*obj.bic_w(2)*obj.sp_acc(i,j)*obj.d_gauss_time + obj.bic_R_0;
%                         plot(obj.time, acc_comp, 'g.'); 
%                     end
%                     if all(~isnan(obj.d2_gauss_time)),
%                         jer_comp = obj.bic_A*obj.bic_w(3)*obj.sp_jer(i,j)*obj.d2_gauss_time + obj.bic_R_0;
%                         plot(obj.time, jer_comp, 'g.'); 
%                     end
                    plot(obj.time, squeeze(model_fit(i,j,:)), 'b','LineWidth', 2);
                    hold off;
                    axis tight;
                    box off;
                    if ~(i == 1 && j == 1),
                        set(gca, 'YTickLabel', {});
                        set(gca, 'XTickLabel', {});
                    else
                         xlabel('Time (s)');
                        ylabel('Firing Rate (spks/s)');
                    end
                    ylim([min_spikes max_spikes]);
                    xlim([-0.2 2.2]);
                    line([1 1], ylim, 'color', 'k', 'linestyle', '--');
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                    
                    err_i = err_i + 1;
                    model_err(err_i,:) = squeeze(obj.psth(i,j,:)-model_fit(i,j,:));
                    
                    set(gca,'FontSize', labelsize);
                end
            end

            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            r2 = 1 - obj.bic_rss/obj.bic_tss;
            tabstring = ['Trial ' num2str(page) ': \newline' trial_name ...
                         '\newline R2: ' num2str(r2, '%1.3f')];
            text(0, 1, tabstring, 'FontName', 'helvetica', 'FontSize', labelsize);
            
            offset = length(obj.u_ele)*(length(obj.u_azi)-1);
            subplot(length(obj.u_ele), length(obj.u_azi)-1, length(obj.u_azi)-1-3);
            ip = get(gca, 'Position');
            ip(2) = ip(2) + 0.03;
            ip(4) = ip(4) + 0.03;
            ip(3) = ip(3) - 0.03;
            set(gca, 'Position', ip);
            bar(obj.bic_w);
            box off;
            set(gca,'XTickLabel',{'V','A','J'});
            ylim([0 1]);
            ylabel('Weights');
            
            set(gca,'FontSize', labelsize);
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, length(obj.u_azi)-1-2);
            p = get(gca, 'Position');
            p(3) = p(3) - 0.03;
            set(gca, 'Position', [p(1) ip(2) p(3) ip(4)]);
            for i=1:size(model_err, 1),
                hold on;
                plot(obj.time, squeeze(model_err(i,:)), 'b');
                hold off;
            end
            axis tight;
            ylim([-dif_spikes dif_spikes]);
            xlim([-0.2 2.2]);
            box off;
            line([1 1], ylim, 'color', 'k', 'linestyle', '--');
            line(xlim, [0 0], 'color', 'k');
            line([0 0], ylim, 'color', 'k');
            line(2*[1 1], ylim, 'color', 'k');
            xlabel('Time (s)');
            ylabel('Error');
            set(gca,'FontSize', labelsize);
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, length(obj.u_azi)-1-[1 0]);
            p = get(gca, 'Position');
            set(gca, 'Position', [p(1) ip(2) p(3) ip(4)]);
            plot(obj.time, obj.bic_w(1)*obj.gauss_time, 'b');
            hold on;
            plot(obj.time, obj.bic_w(2)*obj.d_gauss_time, 'r');
            plot(obj.time, obj.bic_w(3)*obj.d2_gauss_time, 'g');
            hold off;
            axis tight;
            box off;
            xlim([-0.2 2.2]);
            line([1 1], ylim, 'color', 'k', 'linestyle', '--');
            line(xlim, [0 0], 'color', 'k');
            line([0 0], ylim, 'color', 'k');
            line(2*[1 1], ylim, 'color', 'k');
            xlabel('Time (s)');
            ylabel('Time Profile');
            
            set(gca,'FontSize', labelsize);
            
            sp = [];
            if ~isnan(obj.sp_vel),
                sp = [sp obj.bic_w(1)*obj.sp_vel];
            end

            if ~isnan(obj.sp_acc),
                sp = [sp obj.bic_w(2)*obj.sp_acc];
            end

            if ~isnan(obj.sp_jer)
                sp = [sp obj.bic_w(3)*obj.sp_jer];
            end
            
            max_sp = max(sp(:));
            min_sp = min(sp(:));
            
            [vx, vy, vz] = sph2cart(obj.bic_azi(1), obj.bic_ele(1), 1);
            [ax, ay, az] = sph2cart(obj.bic_azi(2), obj.bic_ele(2), 1);
            [jx, jy, jz] = sph2cart(obj.bic_azi(3), obj.bic_ele(3), 1);
            va_ang = acos(diag([vx vy vz]*[ax ay az]'))*180/pi;
            vj_ang = acos(diag([vx vy vz]*[jx jy jz]'))*180/pi;
            aj_ang = acos(diag([ax ay az]*[jx jy jz]'))*180/pi;
            
             subplot(length(obj.u_ele), length(obj.u_azi)-1, [3 4]);
            set(gca, 'CLim', [min_sp max_sp]);
            colorbar('westoutside');
            axis off;
            
            if ~isnan(obj.sp_vel),
                subplot(length(obj.u_ele), length(obj.u_azi)-1, offset-[5 4]);
                opos = get(gca, 'OuterPosition');
                ipos = get(gca, 'Position');
                set(gca, 'Position', [opos(1) ipos(2) opos(3) ipos(4)]);
                contourf(obj.u_azi*180/pi, obj.u_ele*180/pi, obj.bic_w(1)*obj.sp_vel');
                set(gca, 'CLim', [min_sp max_sp]);
                box off;
                title('Velocity Spatial Tuning');
                xlabel('Azimuth (\circ)');
                ylabel('Elevation (\circ)');
                
                set(gca,'FontSize', labelsize);
            end

            if ~isnan(obj.sp_acc),
                subplot(length(obj.u_ele), length(obj.u_azi)-1, offset-[3 2]);
                opos = get(gca, 'OuterPosition');
                ipos = get(gca, 'Position');
                set(gca, 'Position', [opos(1) ipos(2) opos(3) ipos(4)]);
                contourf(obj.u_azi*180/pi, obj.u_ele*180/pi, obj.bic_w(2)*obj.sp_acc');
                set(gca, 'CLim', [min_sp max_sp]);
                set(gca, 'YTickLabel', {});
                box off;
                title('Acceleration Spatial Tuning');
                xlabel('Azimuth (\circ)');

                set(gca,'FontSize', labelsize);
            end

            if ~isnan(obj.sp_jer)
                subplot(length(obj.u_ele), length(obj.u_azi)-1, offset-[1 0]);
                opos = get(gca, 'OuterPosition');
                ipos = get(gca, 'Position');
                set(gca, 'Position', [opos(1) ipos(2) opos(3) ipos(4)]);
                contourf(obj.u_azi*180/pi, obj.u_ele*180/pi, obj.bic_w(3)*obj.sp_jer');
                set(gca, 'CLim', [min_sp max_sp]);
                set(gca, 'YTickLabel', {});
                box off;
                title('Jerk Spatial Tuning');
                xlabel('Azimuth (\circ)');

                set(gca,'FontSize', labelsize);
            end

            set(findall(gcf,'type','text'),'fontSize',8);
            
            if nargin == 4,
                set(gcf,'PaperUnits', 'Centimeters');
                xSize = 20; ySize = 15;
                
                set(gcf,'PaperSize',[21 29.7]);
                set(gcf,'PaperPosition',[0 0 xSize ySize]);
                set(gcf,'Position',[0 0 xSize*50 ySize*50]);

                saveas(h, [path num2str(obj.true_type) '-' trial_name(1:end-4) '.pdf'], 'pdf'); 
                %saveas(h, [path num2str(r2, '%1.2f') '-' trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
        
        function plotPSTH2(obj, page, trial_name, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];           
            dim = [length(obj.u_azi),length(obj.u_ele), length(obj.time)];

            model_fit = unpackPSTH(obj.bic_model(obj.bic_param, st_data), dim);  
            t_covmat = inv(squeeze(obj.bic_jac));
            
            covmat_diag = sqrt(diag(t_covmat));
            bic_covmat = zeros(size(t_covmat));
            for i=1:size(t_covmat,1),
                for j=1:size(t_covmat,2),
                    bic_covmat(i,j) = t_covmat(i,j)/(covmat_diag(i)*covmat_diag(j));
                end
            end        
        
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r.');
                    plot(obj.time, squeeze(model_fit(i,j,:)), 'b'); 
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end

            offset = length(obj.u_ele)*(length(obj.u_azi)-1);
            subplot(length(obj.u_ele), length(obj.u_azi)-1, offset);
            text(obj.bic_ele(1)/pi*180, obj.bic_azi(1)/pi*180, 'V', 'Color', 'b');
            text(obj.bic_ele(2)/pi*180, obj.bic_azi(2)/pi*180, 'A', 'Color', 'b');
            text(obj.bic_ele(3)/pi*180, obj.bic_azi(3)/pi*180, 'J', 'Color', 'b');
            box off;
            ylim([0 360]);
            xlim([-90 90]);
            ylabel('Azimuth (deg)');
            xlabel('Elevation (deg)');

            subplot(length(obj.u_ele), length(obj.u_azi)-1, offset-1);
            plot(obj.bic_w, 1:3, 'b*');
            box off;
            set(gca,'YTick', 1:3);
            set(gca,'YTickLabel',{'V','A','J'});
            xlim([0 1]);
            xlabel('Weights');
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, offset-[3 2]);
            plot(1 - sort(obj.bic_rss)/obj.bic_tss, 'b');
            xlabel('Trial');
            ylabel('R2');
            axis tight;
            box off;
            ylim([0 1]);
%             subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
%                    length(obj.u_azi)-1);
%             imagesc(bic_covmat);         
%             %colorbar('location','southoutside');
%             caxis([-1 1]);
%             box off;
            
            if nargin == 3,
                text_size = 6;
            else
                text_size = 10;
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page) ' : ' trial_name, ...
                         ', R2: ' num2str(1 - obj.bic_rss/obj.bic_tss)];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size);

            if nargin == 4,
                set(gcf,'PaperUnits', 'Centimeters');
                xSize = 17.6; ySize = 8.8;
                xPaperSize = 21.59; yPaperSize = 27.94;
                
                set(gcf,'PaperSize',[xPaperSize yPaperSize]);
                set(gcf,'PaperPosition',[0 0 xSize ySize]);
                set(gcf,'Position',[0 0 xSize*50 ySize*50]);
                
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end 
        
        function plotDifPSTH(obj, faj, page, trial_name, path)
            if obj.bic_type ~= 7,
                return;
            end
            
            labelsize = 6;
            st_data = [obj.u_ele; obj.u_azi; obj.time'];           
            dim = [length(obj.u_azi),length(obj.u_ele), length(obj.time)];

            model_fit = unpackPSTH(obj.bic_model(obj.bic_param, st_data), dim); 
            
            accjer_fit = unpackPSTH(accjer_model(faj.accjer_param, st_data), dim); 

            dif_vaj_fit = obj.psth - model_fit;
            dif_aj_fit =  obj.psth - accjer_fit;
            dif_err = dif_vaj_fit - dif_aj_fit;
            
            max_spikes = max(dif_aj_fit(:));
            min_spikes = min(dif_aj_fit(:));
            
            stim_sig = sqrt(sqrt(2))/6;
            d_gauss_t = min(abs([max_spikes min_spikes]))*d_gauss([obj.bic_mu_t stim_sig], obj.time');

            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    opos = get(gca, 'OuterPosition');
                    ipos = get(gca, 'Position');
                    set(gca, 'Position', [opos(1) ipos(2) opos(3) ipos(4)]);
%                     plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
%                     hold on;
%                     plot(obj.time, squeeze(model_fit(i,j,:)), 'b');
%                     plot(obj.time, squeeze(accjer_fit(i,j,:)), 'g');
%                     hold off;
                    
                    area(obj.time, squeeze(dif_err(i,j,:)), 'FaceColor', 'y');
                    hold on;
                    plot(obj.time, d_gauss_t, 'g');
                    plot(obj.time, squeeze(dif_vaj_fit(i,j,:)), 'r');
                    plot(obj.time, squeeze(dif_aj_fit(i,j,:)), 'b');
                    hold off;
                    axis tight;
                    box off;
                    if ~(i == 1 && j == 1),
                        set(gca, 'YTickLabel', {});
                        set(gca, 'XTickLabel', {});
                    else
                         xlabel('Time (s)');
                        ylabel('Firing Rate (spks/s)');
                    end
                    ylim([min_spikes max_spikes]);
                    xlim([-0.2 2.2]);
                    line([1 1], ylim, 'color', 'k', 'linestyle', '--');
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                    
                  
                    set(gca,'FontSize', labelsize);
                end
            end
            
            offset = length(obj.u_ele)*(length(obj.u_azi)-1);
            
            sp = [];
            if ~isnan(obj.sp_vel),
                sp = [sp obj.bic_w(1)*obj.sp_vel];
            end

            if ~isnan(obj.sp_acc),
                sp = [sp obj.bic_w(2)*obj.sp_acc];
            end

            if ~isnan(obj.sp_jer)
                sp = [sp obj.bic_w(3)*obj.sp_jer];
            end
            
            max_sp = max(sp(:));
            min_sp = min(sp(:));
            
            if ~isnan(obj.sp_vel),
                subplot(length(obj.u_ele), length(obj.u_azi)-1, offset-[5 4]);
                contourf(obj.u_azi*180/pi, obj.u_ele*180/pi, obj.bic_w(1)*obj.sp_vel');
                set(gca, 'CLim', [min_sp max_sp]);
                colorbar('EastOutside');
                box off;
                
                title('Vel. Spatial Tuning');
                xlabel('Azimuth (Deg.)');
                ylabel('Elevation (Deg.)');
                
                set(gca,'FontSize', labelsize);
            end
            
            if nargin == 3,
                text_size = 6;
            else
                text_size = 10;
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page) ' : ' trial_name, ...
                         ', R2: ' num2str(1 - obj.bic_rss/obj.bic_tss)];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size);
            tabstring = ['VAJ RSS: ' num2str(obj.bic_rss), ...
                        ', AJ RSS: ' num2str(faj.accjer_rss)];
            text(0, 0.5, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size); 
           tabstring = ['VAJ BIC: ' num2str(obj.bic), ...
                        ', AJ BIC: ' num2str(obj.bic_all(6))];
            text(0, 0, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size);          
            
            if nargin == 5,
                set(gcf,'PaperUnits', 'Centimeters');
                xSize = 20; ySize = 15;
                
                set(gcf,'PaperSize',[21 29.7]);
                set(gcf,'PaperPosition',[0 0 xSize ySize]);
                set(gcf,'Position',[0 0 xSize*50 ySize*50]);

                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
    end
end