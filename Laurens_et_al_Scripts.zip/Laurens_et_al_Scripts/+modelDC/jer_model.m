function r = jer_model(param, coord)
    u_ele = coord(1:5);
    u_azi = coord(6:14);
    time = coord(15:end);
    
    %time profile
    d2_gauss_time = d2_gauss(param(3:4), time);
      
    %spatial profiles
    ele_azi = d_cos_tuning(param(5:12), [u_ele; u_azi]);
    ele_azi = reshape(ele_azi, length(u_azi), length(u_ele));
    
    %compute results
    r = zeros(size(ele_azi,1), size(ele_azi,2), length(d2_gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            r(i,j,:) = param(1)*ele_azi(i,j)*d2_gauss_time + param(2);
        end
    end

    r = packPSTH(r);
end