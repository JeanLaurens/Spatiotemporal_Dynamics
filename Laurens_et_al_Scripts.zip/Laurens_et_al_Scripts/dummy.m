clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('htb'));

data_name = ['..' filesep '..' filesep 'Data' filesep 'Xiongjie_Good' filesep];
data_dir = dir([data_name 'm*']);

for i=1, %length(data_dir),
    p = PSTH('xiongjie', 0, [data_name data_dir(i).name filesep]);
    p.plotFIR();
end
return;

clear;
PATH = (['..' filesep '..' filesep 'Data' filesep 'Simulations' filesep]);

% psm = poolSelModel(PATH);
% psm.plotModMatch();
% psm.plotWeights();
% psm.plotMatchWeights();
% return;

data_dir = dir([PATH '*.mat']);
i = 1;

%for i=1:length(data_dir),
    load(['..' filesep '..' filesep 'Data' filesep 'Simulations' filesep data_dir(i).name]);
    
%     cur_trial_name = data_dir(i).name;
%     cur_trial_name = cur_trial_name(1:end-4);
%     p = PSTH(['..' filesep '..' filesep 'Data' filesep 'Xiongjie_Good' filesep cur_trial_name filesep]);
%     disp(cur_trial_name);
%     disp(p.cv_star);
    fa = fitAcc(p, 1);
    
    sm = selModel(p, fp, fv, fa, fj, fva, faj, fpva, fpaj);
    sm.plotPSTH(data_dir(i).name);
    %sm.plotPosVelAccJerPSTH(data_dir(i).name); %, ['..' filesep '..' filesep 'Reports' filesep 'simulation_plots' filesep]);
    sm.plotCovMat(data_dir(i).name);
    %sm.plotTemp();
%end
