clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('htb'));
addpath(genpath('modelS2H'));

brain_area = 'OA';

TIMEPATH = (['..' filesep '..' filesep 'Paper_Input' filesep 'Time_Correction' filesep]);
disp([TIMEPATH brain_area '_correct.csv']);
fid = fopen([TIMEPATH brain_area '_correct.csv'], 'r');
t = textscan(fid, '%s %s %f %d\n');
fclose(fid);
pool_dir = t{1};
pool_name = t{2};
pool_lag = t{3};

default_lag = nanmedian(pool_lag);

for i = 1:length(pool_name),
    disp(['Cell: ' pool_name{i}]);

    if isnan(pool_lag(i)),
        p = PSTH('xiongjie', default_lag, pool_dir{i}(4:end));
    else 
        p = PSTH('xiongjie', pool_lag(i), pool_dir{i}(4:end));
    end

    save(['..' filesep '..' filesep 'Paper_Input' filesep 'psth_' brain_area '_c' filesep ...
          pool_name{i}], 'p');
end