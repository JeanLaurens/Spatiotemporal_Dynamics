clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('htb'));

sel_brainarea = 'VN';
[~, txt, ~] = xlsread([ '..' filesep '..' filesep 'Data' ...
                        filesep 'MOOG' filesep 'VN_CN.xls']);
path_name = txt(:, 1);
file_name = txt(:, 2);
chan = txt(:,3);
brainarea = txt(:,4);

% TIMEPATH = (['..' filesep '..' filesep 'Paper_Output' filesep 'Time_Correction' filesep]);
% disp([TIMEPATH brain_area '_correct.csv']);
% fid = fopen([TIMEPATH brain_area '_correct.csv'], 'r');
% t = textscan(fid, '%s %f %d\n');
% fclose(fid);
% pool_lag = t{2};
% pool_filename = t{1};
% pool_machine = t{3};
% 
% default_lag = [nanmedian(pool_lag) nanmedian(pool_lag(pool_machine == 1)) ...
%                nanmedian(pool_lag(pool_machine == 2))];

disp(brainarea);
return;        
           
for i = 1, %:length(chan),
    pool_filename{i} = ' ';
    
    if chan(i) >= 5,
        cur_chan = 3;
    else
        cur_chan = chan(i);
    end
    cur_path_name = strrep(path_name{i}, '\', filesep);
    cur_path_name = ['..' filesep '..' cur_path_name(3:end)];
    cur_file_name = file_name{i};
    cur_save_name =  ['..' filesep '..' filesep ...
                      'Data' filesep 'Simulations' cur_path_name(16:end)];

                  
    disp([num2str(i) ', ' cur_file_name(1:end-4) 'c' num2str(cur_chan) '.mat']); 
    pool_filename{i} = [cur_file_name(1:end-4) 'c' num2str(cur_chan) '.mat'];
    [~, data, ~, ~] = LoadTEMPOData(cur_path_name, cur_file_name);

   idx = find(ismember(pool_filename, cur_file_name));
   if isempty(idx) || isnan(pool_lag(idx)),
        time_correct = default_lag(pool_machine(i)+1);
    else
        time_correct = pool_lag(idx);
   end
    
    p = PSTH('sheng', time_correct, data, cur_chan); 
%     if ~p.rej,
%          save(['..' filesep '..' filesep 'Paper_Output' filesep 'psth_' brain_area '_c' filesep ...
%                cur_file_name(1:end-4) 'c' num2str(1) '.mat'], 'p');
%     end
%    
%    p.plot2DProfiles(cur_file_name, ['..' filesep '..' filesep ...
%                     'Paper_Figures' filesep]);             
end