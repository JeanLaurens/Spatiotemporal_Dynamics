classdef fitPosVelAccJer
    properties
        reps 
        psth
  
        u_azi
        u_ele
        time
        
        time_profile1
        time_profile2
        time_profile3
        
        baseline
        
        R_0
        mu_t
        
        p_ele_azi_profile
        p_space_profile
        p_coeff
        p_DC
        p_A
        
        v_ele_azi_profile
        v_space_profile
        v_coeff
        v_DC
        v_A
        
        a_ele_azi_profile
        a_space_profile
        a_coeff
        a_DC
        a_A
        
        j_ele_azi_profile
        j_space_profile
        j_coeff
        j_DC
        j_A

        init_param
        
        posvelaccjer_param
        rand_param
        
        posvelaccjer_rss       
        rand_rss
        
        posvelaccjer_jac
        rand_jac
    end
    
    methods
        function obj = fitPosVelAccJer(p, reps)
            obj.reps = reps;
            obj.psth = p.psth;

            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            obj.baseline = p.baseline;
            
            stim_sig = sqrt(sqrt(2))/6;
            obj.mu_t = 1;
            
            %Compute Spatial Profiles
            i_gauss_time = i_gauss([obj.mu_t stim_sig], obj.time)';
            gauss_time = gauss([obj.mu_t stim_sig], obj.time)';
            d_gauss_time = d_gauss([obj.mu_t stim_sig], obj.time)';
            d2_gauss_time = d2_gauss([obj.mu_t stim_sig], obj.time)';
            
            u1 = i_gauss_time;
            p1 = (u1'*gauss_time)/(u1'*u1);
            u2 = gauss_time - p1*u1;
            p21 = (u1'*d_gauss_time)/(u1'*u1);
            p22 = (u2'*d_gauss_time)/(u2'*u2);
            u3 = d_gauss_time - p21*u1 - p22*u2;
            p31 = (u1'*d2_gauss_time)/(u1'*u1);
            p32 = (u2'*d2_gauss_time)/(u2'*u2);
            p33 = (u3'*d2_gauss_time)/(u3'*u3);
            u4 = d2_gauss_time - p31*u1 - p32*u2 - p33*u3;
            
            t_psth = obj.psth - obj.baseline;
            obj.p_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            obj.v_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            obj.a_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            obj.j_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);

            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi),
                    t_profile = squeeze(t_psth(i,j,:));
                    coeff = (pinv([u1 u2 u3 u4])*squeeze(t_profile));
                    obj.p_ele_azi_profile(i,j) = coeff(1) - ...
                                                 coeff(2)*p1 + ...
                                                 coeff(3)*(-p21+p22*p1) + ...
                                                 coeff(4)*(-p31+p32*p1+p33*(p21-p22*p1));
                    
                    obj.v_ele_azi_profile(i,j) = coeff(2) - coeff(3)*p22 + ...
                                                 coeff(4)*(-p32+p33*p22);
                    
                    obj.a_ele_azi_profile(i,j) = coeff(3) - coeff(4)*p33;
                    
                    obj.j_ele_azi_profile(i,j) = coeff(4);
                end
            end
            
            %Normalise Profiles 
            obj.p_DC = mean(obj.p_ele_azi_profile(:));
            obj.p_space_profile = obj.p_ele_azi_profile - obj.p_DC;                                                
            
            obj.v_DC = mean(obj.v_ele_azi_profile(:));
            obj.v_space_profile = obj.v_ele_azi_profile - obj.v_DC;                                         
            
            obj.a_DC = mean(obj.a_ele_azi_profile(:));
            obj.a_space_profile = obj.a_ele_azi_profile - obj.a_DC;
            
            obj.j_DC = mean(obj.j_ele_azi_profile(:));
            obj.j_space_profile = obj.j_ele_azi_profile - obj.j_DC;                                         
           
            %Fit spatial profile
            d_azi = 2*pi/length(obj.u_azi);
            d_ele = pi/length(obj.u_ele);
            obj.p_coeff = sh_coeff(obj.p_space_profile, 2, ...
                                   obj.u_azi, obj.u_ele+pi/2, ...
                                   d_azi, d_ele);
                               
            obj.v_coeff = sh_coeff(obj.v_space_profile, 2, ...
                                   obj.u_azi, obj.u_ele+pi/2, ...
                                   d_azi, d_ele);          
            
            obj.a_coeff = sh_coeff(obj.a_space_profile, 2, ...
                                   obj.u_azi, obj.u_ele+pi/2, ...
                                   d_azi, d_ele);                  
                               
            obj.j_coeff = sh_coeff(obj.j_space_profile, 2, ...
                                   obj.u_azi, obj.u_ele+pi/2, ...
                                   d_azi, d_ele);
                               
            obj.R_0 = obj.baseline;
           
            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);

            param = [obj.R_0, ...      %1
                     obj.mu_t, ...     %2
                     obj.p_coeff', ... %3-10
                     obj.p_DC, ...     %11
                     obj.v_coeff', ... %12-19
                     obj.v_DC, ...     %20
                     obj.a_coeff', ... %21-28
                     obj.a_DC, ...     %29
                     obj.j_coeff', ... %30-37
                     obj.j_DC];        %38

            obj.init_param = param;
            
            y_data = packPSTH(obj.psth);

            LB = [0, ...               %1     R_0
                  1, ...               %2     mu_t
                  -1000*ones(1,8), ... %3-10  p_coeff
                  -1000, ...           %11    p_DC
                  -1000*ones(1,8), ... %12-19 v_coeff
                  -1000, ...           %20    v_DC
                  -1000*ones(1,8), ... %21-28 a_coeff
                  -1000, ...           %29    a_DC
                  -1000*ones(1,8), ... %30-37 j_coeff
                  -1000];              %38    j_DC
                 
              
            UB = [300, ...            %1     R_0
                  1.5, ...            %2     mu_t
                  1000*ones(1,8), ... %3-10  p_coeff
                  1000, ...           %11    p_DC
                  1000*ones(1,8), ... %12-19 v_coeff
                  1000, ...           %20    v_DC
                  1000*ones(1,8), ... %21-28 a_coeff
                  1000, ...           %29    a_DC
                  1000*ones(1,8), ... %30-37 j_coeff
                  1000];              %38    j_DC
            
            t_rand_rss = zeros(obj.reps+1,1);
            t_rand_param = zeros(obj.reps+1, length(param));
            t_rand_jac = zeros(obj.reps+1, length(param), length(param));

            [t_rand_param(1,:), t_rand_rss(1),~,~,~,~,tmp_jacobian] = ...
            lsqcurvefit('posvelaccjer_model', obj.init_param, st_data, y_data, LB, UB, options);
            obj.rand_jac(1,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
            
            %Initial Conditions Random Range
            err_range =  0.1*(UB - LB);
            min_param = t_rand_param(1,:);
            UB_param = min_param+err_range;
            LB_param = min_param-err_range;
            
            parfor i=2:obj.reps+1,
                %Randomise Initial Conditions
                seed_param  = unifrnd(LB_param, UB_param);
                
                [t_rand_param(i,:), t_rand_rss(i),~,~,~,~,tmp_jacobian] = ...
                 lsqcurvefit('posvelaccjer_model', seed_param, st_data, y_data, LB, UB, options);
                 t_rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
            end
           
            obj.rand_param = t_rand_param;
            obj.rand_rss = t_rand_rss;
            obj.rand_jac = t_rand_jac;
            
            [~,min_idx] = min(obj.rand_rss);
            obj.posvelaccjer_param = obj.rand_param(min_idx,:);
            obj.posvelaccjer_rss = obj.rand_rss(min_idx);
            obj.posvelaccjer_jac = obj.rand_jac(min_idx,:,:);
        end
        
        function plotPSTH(obj, trial_name, page_num, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];           
            
            init_fit = posvelaccjer_model(obj.init_param(1,:), st_data);
            posvelaccjer_fit = posvelaccjer_model(obj.posvelaccjer_param, st_data);

            init_fit = unpackPSTH(init_fit, size(obj.psth));
            posvelaccjer_fit = unpackPSTH(posvelaccjer_fit, size(obj.psth));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(init_fit(i,j,:)), 'g');
                    plot(obj.time, squeeze(posvelaccjer_fit(i,j,:)), 'k');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page_num) ': ' trial_name];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                 'FontName', 'helvetica', 'FontSize', 12);
             
            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
        
        function printVal(obj)
            disp('Position + Velocity + Acceleration');
            disp(['A      : ' num2str(obj.posvelaccjer_param(1))]);
            disp(['R_0    : ' num2str(obj.posvelaccjer_param(2))]);
            
            disp(['v_mu_t : ' num2str(obj.posvelaccjer_param(3))]);
            disp(['v_sig_t: ' num2str(obj.posvelaccjer_param(4))]); 
            disp(['v_n    : ' num2str(obj.posvelaccjer_param(5))]);
            disp(['v_a_0  : ' num2str(obj.posvelaccjer_param(6)*180/pi)]);
            disp(['v_e_0  : ' num2str(obj.posvelaccjer_param(7)*180/pi)]);
            disp(['v_DC   : ' num2str(obj.posvelaccjer_param(8))]);
            
            disp(['a_mu_t : ' num2str(obj.posvelaccjer_param(9))]);
            disp(['a_sig_t: ' num2str(obj.posvelaccjer_param(10))]); 
            disp(['a_n    : ' num2str(obj.posvelaccjer_param(11))]);
            disp(['a_a_0  : ' num2str(obj.posvelaccjer_param(12)*180/pi)]);
            disp(['a_e_0  : ' num2str(obj.posvelaccjer_param(13)*180/pi)]);
            disp(['a_DC   : ' num2str(obj.posvelaccjer_param(14))]);
            
            disp(['j_mu_t : ' num2str(obj.posvelaccjer_param(15))]);
            disp(['j_sig_t: ' num2str(obj.posvelaccjer_param(16))]); 
            disp(['j_n    : ' num2str(obj.posvelaccjer_param(17))]);
            disp(['j_a_0  : ' num2str(obj.posvelaccjer_param(18)*180/pi)]);
            disp(['j_e_0  : ' num2str(obj.posvelaccjer_param(19)*180/pi)]);
            disp(['j_DC   : ' num2str(obj.posvelaccjer_param(20))]);
            
            disp(['w_v    : ' num2str(obj.posvelaccjer_param(21))]);
            disp(['w_j    : ' num2str(obj.posvelaccjer_param(22))]);
        end
        
    end 
end