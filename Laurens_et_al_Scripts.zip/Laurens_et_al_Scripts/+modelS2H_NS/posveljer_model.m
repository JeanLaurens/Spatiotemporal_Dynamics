function r = posveljer_model(param, coord)
    u_ele = coord(1:5);
    u_azi = coord(6:14);
    time = coord(15:end);
    
    stim_sig = sqrt(sqrt(2))/6;
    
    %velocity model
    i_gauss_time = i_gauss([param(2) stim_sig], time);
    p_ele_azi = sh_recon(param(3:10), 2, u_azi, u_ele+pi/2) + param(11);
    
    %acceleration model
    gauss_time = gauss([param(2) stim_sig], time);
    v_ele_azi = sh_recon(param(12:19), 2, u_azi, u_ele+pi/2) + param(20);
    
    %jerk model
    d2_gauss_time = d2_gauss([param(2) stim_sig], time);
    j_ele_azi = sh_recon(param(21:28), 2, u_azi, u_ele+pi/2) + param(29);

    %compute results
    r = zeros(size(v_ele_azi,1), size(v_ele_azi,2), length(gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            r(i,j,:) = p_ele_azi(i,j)*i_gauss_time + ...
                       v_ele_azi(i,j)*gauss_time + ...
                       j_ele_azi(i,j)*d2_gauss_time + ...
                       param(1);
        end
    end

    r = packPSTH(r);
end