classdef poolSelModel2
    properties
        pool_bic_all
        pool_bic
        pool_bic_type
        filename
        
        pool_r2
        pool_weights
        
        pool_v_tuning
        pool_a_tuning
        pool_j_tuning
        
        pool_vn
        pool_an
        pool_jn
        
        pool_vDC
        pool_aDC
        pool_jDC
        
        pool_mu_t
        pool_sig_t
        
        time
        
        pool_cv
        
        pool_A
        pool_R_0
        
    end
    
    methods
        function obj = poolSelModel2(OUTPUT_PATH, PSTH_PATH)
            stim_sig = sqrt(sqrt(2))/6;
            
            data_dir = dir([OUTPUT_PATH '*.mat']);
            
            obj.pool_bic = zeros(length(data_dir), 1);
            obj.pool_bic_type = zeros(length(data_dir), 1);
            
            obj.pool_r2 = zeros(length(data_dir), 1);
            obj.pool_weights = zeros(length(data_dir), 3);
            
            obj.pool_v_tuning = zeros(length(data_dir), 2);
            obj.pool_a_tuning = zeros(length(data_dir), 2);
            obj.pool_j_tuning = zeros(length(data_dir), 2);
 
            obj.pool_vn = zeros(length(data_dir), 1);
            obj.pool_an = zeros(length(data_dir), 1);
            obj.pool_jn = zeros(length(data_dir), 1);
            
            obj.pool_vDC = zeros(length(data_dir), 1);
            obj.pool_aDC = zeros(length(data_dir), 1);
            obj.pool_jDC = zeros(length(data_dir), 1);
            
            obj.pool_cv = zeros(length(data_dir), 1);

            obj.pool_mu_t = zeros(length(data_dir), 1);
            obj.pool_sig_t = zeros(length(data_dir), 1);
            
            obj.pool_A = zeros(length(data_dir), 1);
            obj.pool_R_0 = zeros(length(data_dir), 1);
            
            
            for i=1:length(data_dir),
                dat = load([OUTPUT_PATH filesep data_dir(i).name]);
                psth_dat = load([PSTH_PATH filesep data_dir(i).name]);
                files{i} = data_dir(i).name(1:end-4);
                p = psth_dat.p;
  
                sm = selModel2(p, dat.fv, dat.fa, dat.fj, ...
                              dat.fva, dat.fvj, dat.faj, dat.fvaj);
               
                if i == 1,
                    obj.time = sm.time;
                end
                
                if ~isnan(sm.cv_star),
                    obj.pool_cv(i) = sm.cv_star;
                end
                
                obj.filename{i,1} = data_dir(i).name;
                obj.pool_bic_all(i,:) = sm.bic_all;
                obj.pool_bic(i) = sm.bic;
                obj.pool_bic_type(i) = sm.bic_type;
                obj.pool_r2(i) = 1-min(sm.bic_rss)/sm.bic_tss;
                obj.pool_weights(i,:) = sm.bic_w;
                
                obj.pool_mu_t(i) = sm.bic_mu_t;
                obj.pool_sig_t(i) = stim_sig;

                obj.pool_v_tuning(i,:) = [sm.bic_azi(1) sm.bic_ele(1)]*180/pi;
                obj.pool_a_tuning(i,:) = [sm.bic_azi(2) sm.bic_ele(2)]*180/pi;
                obj.pool_j_tuning(i,:) = [sm.bic_azi(3) sm.bic_ele(3)]*180/pi;
                
                obj.pool_vn(i) = sm.bic_vn;
                obj.pool_an(i) = sm.bic_an;
                obj.pool_jn(i) = sm.bic_jn;
                
                obj.pool_vDC(i) = sm.bic_v_DC;
                obj.pool_aDC(i) = sm.bic_a_DC;
                obj.pool_jDC(i) = sm.bic_j_DC;
                
                obj.pool_A(i) = sm.bic_A;
                obj.pool_R_0(i) = sm.bic_R_0;
            end
%             writeexceldt('d:\model1', files'   ,obj.pool_bic );
        end
        
        function plotTypes(obj)
            types = zeros(7,1);
         
            for i=1:length(obj.pool_bic_type),
                switch obj.pool_bic_type(i),
                    case 1
                        types(1) = types(1)+1;
                        
                    case 2
                        types(2) = types(2)+1;
                        
                    case 3
                        types(3) = types(3)+1;
                        
                    case 4
                        types(4) = types(4)+1;
                        
                    case 5
                        types(5) = types(5)+1;
                        
                    case 6
                        types(6) = types(6)+1; 
                        
                    case 7
                        types(7) = types(7)+1;    
                end
            end
            
            
            bar(types);
            box off;
            axis tight;
            xlabel('Types');
            ylabel('Count');
        end
        
        function plotBIC(obj, name)
            [c, bins] = hist(obj.pool_bic, 10);
            bar(bins, c);
            xlabel('BIC');
            ylabel('Count');
            box off;
            axis tight;
            title(name);
        end
        
        function plotR2(obj)
            bins = 0:0.05:1;
            c = histc(obj.pool_r2, bins);
            bar(bins, c);
            xlabel('R2');
            ylabel('Count');
            box off;
            axis tight;
        end
        
        function plotWeightsTurnplot(obj, name)
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            [x, y] = terncoords(obj.pool_weights(:,1), ...
                                obj.pool_weights(:,2), ...
                                obj.pool_weights(:,3));
            ternaxes(5);
            [~, i] = sort(obj.pool_cv);
            scatter(x(i), y(i), 100, log(obj.pool_cv(i)), 'filled');
            ternlabel('Vel', 'Acc', 'Jer');                       
            title(name);
            
            if ~(sum(obj.pool_cv) == 0),
                cb = colorbar;
                ytick = 0.02:.02:0.2;
                set(cb, 'YTick', log(ytick));
                set(cb, 'YTickLabel', ytick);
            end
            
            set(gca, 'fontSize', 12);
            set(findall(gcf,'type','text'),'fontSize',24);
        end
        
        function plotSpatialWeights(obj)
            bins = 0:0.05:1;
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            set(gca,'FontSize',20);
            subplot(2,3,1);
            c = histc(squeeze(obj.pool_weights(:,1)), bins);
            bar(bins, c);
            xlabel('Vel Weights');
            ylabel('Count');
            box off;
            axis tight;
            set(gca, 'fontSize', 12);
            
            subplot(2,3,2);
            c = histc(squeeze(obj.pool_weights(:,2)), bins);
            bar(bins, c);
            xlabel('Acc Weights');
            ylabel('Count');
            box off;
            axis tight;
            set(gca, 'fontSize', 12);
            
            subplot(2,3,3);
            c = histc(squeeze(obj.pool_weights(:,3)), bins);
            bar(bins, c);
            xlabel('Jer Weights');
            ylabel('Count');
            box off;
            axis tight;
            set(gca, 'fontSize', 12);

            set(findall(gcf,'type','text'),'fontSize',24);
        end
        
        function plotTimeParam(obj)
            stim_sig = sqrt(sqrt(2))/6;
            stim_mu = 1;
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(2,2,1);
            bins = 0.5:0.01:1.5;
            c = histc(obj.pool_mu_t, bins);
            bar(bins, c);
%             hold on;
%             plot(obj.pool_mu_t, 0, 'r*');
%             [~, i] = sort(obj.pool_cv);
%             scatter(obj.pool_mu_t(i), zeros(size(obj.pool_mu_t)), ...
%                     100, obj.pool_cv(i), 'filled');
%             hold off;
            xlabel('Time Lags(s)');
            ylabel('Count');
            box off;
            axis tight;
            q = quantile(obj.pool_mu_t, 3);
            line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
            line(q(2)*[1 1], ylim, 'Color', 'r');
            line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
            line((q(3)+1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
            line((q(1)-1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
            line(stim_mu*[1 1], ylim, 'Color', 'b');
            set(gca,'fontSize',12);
            
            subplot(2,2,2);
            bins = 0:0.01:1;
            c = histc(obj.pool_sig_t, bins);
            bar(bins, c);
%             hold on;
%             [~, i] = sort(obj.pool_cv);
%             scatter(obj.pool_sig_t(i), zeros(size(obj.pool_sig_t)), ...
%                     100, obj.pool_cv(i), 'filled');
%             hold off;
            xlabel('Time Spreads(s)');
            ylabel('Count');
            box off;
            axis tight;
            q = quantile(squeeze(obj.pool_sig_t), 3);
            line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
            line(q(2)*[1 1], ylim, 'Color', 'r');
            line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
            line(stim_sig*[1 1], ylim, 'Color', 'b');
            set(gca,'fontSize',12);
            %line(0.5*stim_sig*[1 1], ylim, 'Color', 'b');
            %line(1.5*stim_sig*[1 1], ylim, 'Color', 'b');
            
            subplot(2,2,3);
            hold on;
            for i=1:length(obj.pool_mu_t),
                plot(obj.time, gauss([obj.pool_mu_t(i) obj.pool_sig_t(i)], obj.time));
            end
            plot(obj.time, gauss([stim_mu stim_sig], obj.time), 'r', 'LineWidth', 2);
            hold off;
            box off;
            axis tight;
            xlabel('Time (s)');
            set(gca,'fontSize',12);
            
            subplot(2,2,4);
            hold on;
            for i=1:length(obj.pool_mu_t),
                plot(obj.time, gauss([stim_mu obj.pool_sig_t(i)], obj.time));
            end
            plot(obj.time, gauss([stim_mu stim_sig], obj.time), 'r', 'LineWidth', 2);
            hold off;
            box off;
            axis tight;
            xlabel('Time (s)');
            set(gca,'fontSize',12);
            
            set(findall(gcf,'type','text'),'fontSize',24);
        end
        
        function plotTuning2(obj)
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(2,3,1);
            scatter(obj.pool_v_tuning(:,1)/pi*180, ...
                    obj.pool_v_tuning(:,2)/pi*180, ...
                    100, log(obj.pool_cv), 'filled');
            axis equal;
            box off;
            if ~(sum(obj.pool_cv) == 0),
                cb = colorbar;
                ytick = 0.02:.02:0.2;
                set(cb, 'YTick', log(ytick));
                set(cb, 'YTickLabel', ytick);
            end
            xlim([0 360]);
            ylim([-90 90]);
            xlabel('Azimuith');
            ylabel('Elevation');
            title('Velocity');
            set(gca, 'fontSize', 12);
            
            subplot(2,3,2);
            scatter(obj.pool_a_tuning(:,1)/pi*180, ...
                    obj.pool_a_tuning(:,2)/pi*180, ...
                    100, log(obj.pool_cv), 'filled');
            axis equal;
            box off;
            if ~(sum(obj.pool_cv) == 0),
                cb = colorbar;
                ytick = 0.02:.02:0.2;
                set(cb, 'YTick', log(ytick));
                set(cb, 'YTickLabel', ytick);
            end
            xlim([0 360]);
            ylim([-90 90]);
            xlabel('Azimuith');
            ylabel('Elevation');
            title('Acceleration');
            set(gca, 'fontSize', 12);
            
            subplot(2,3,3);
            scatter(obj.pool_j_tuning(:,1)/pi*180, ...
                    obj.pool_j_tuning(:,2)/pi*180, ...
                    100, log(obj.pool_cv), 'filled');
            axis equal;
            box off;
            if ~(sum(obj.pool_cv) == 0),
                cb = colorbar;
                ytick = 0.02:.02:0.2;
                set(cb, 'YTick', log(ytick));
                set(cb, 'YTickLabel', ytick);
            end
            xlim([0 360]);
            ylim([-90 90]);
            xlabel('Azimuith');
            ylabel('Elevation');
            title('Jerk');
            set(gca, 'fontSize', 12);
            
            set(findall(gcf,'type','text'),'fontSize',24);
        end
        
        function plotWeights(obj, name)
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(1,3,1);
            plot(obj.pool_weights(:,1), obj.pool_weights(:,2), 'r*');
            hold on;
            plot([1 0], [0 1], 'k');
            hold off;
            axis equal;
            xlim([0 1]);
            ylim([0 1]);
            xlabel('Vel Weight');
            ylabel('Acc Weight');
            title(name);
            
            subplot(1,3,2);
            plot(obj.pool_weights(:,2), obj.pool_weights(:,3), 'r*');
            hold on;
            plot([1 0], [0 1], 'k');
            hold off;
            axis equal;
            xlim([0 1]);
            ylim([0 1]);
            xlabel('Acc Weight');
            ylabel('Jer Weight');
            
            subplot(1,3,3);
            plot(obj.pool_weights(:,1), obj.pool_weights(:,3), 'r*');
            hold on;
            plot([1 0], [0 1], 'k');
            hold off;
            axis equal;
            xlim([0 1]);
            ylim([0 1]);
            xlabel('Vel Weight');
            ylabel('Jer Weight');         
        end
        
        function plotTuning(obj)
%             scrsz = get(0,'ScreenSize');
%             figure('Position', scrsz, 'Renderer', 'painters');
%             subplot(2,3,1);
%             plot(obj.pool_v_tuning(:,1)/pi*180, ...
%                  obj.pool_v_tuning(:,2)/pi*180, 'r*');
%             axis equal;
%             box off;
%             xlim([0 360]);
%             ylim([-90 90]);
%             xlabel('Azimuith');
%             ylabel('Elevation');
%             title('Velocity');
%             
%             subplot(2,3,2);
%             plot(obj.pool_a_tuning(:,1)/pi*180, ...
%                  obj.pool_a_tuning(:,2)/pi*180, 'r*');
%             axis equal;
%             box off;
%             xlim([0 360]);
%             ylim([-90 90]);
%             xlabel('Azimuith');
%             ylabel('Elevation');
%             title('Acceleration');
%             
%             subplot(2,3,3);
%             plot(obj.pool_j_tuning(:,1)/pi*180, ...
%                  obj.pool_j_tuning(:,2)/pi*180, 'r*');
%             axis equal;
%             box off;
%             xlim([0 360]);
%             ylim([-90 90]);
%             xlabel('Azimuith');
%             ylabel('Elevation');
%             title('Jerk');
% 
%             subplot(2,3,4);
%             plot(obj.pool_v_tuning2(:,1)/pi*180, ...
%                  obj.pool_v_tuning2(:,2)/pi*180, 'r*');
%             axis equal;
%             box off;
%             xlim([0 180]);
%             ylim([0 360]);
%             line(xlim, [30 30], 'color', 'k');
%             line(xlim, [330 330], 'color', 'k');
%             xlabel('Azimuith');
%             ylabel('Elevation');
%             title('Velocity 2');
%             
%             subplot(2,3,5);
%             plot(obj.pool_a_tuning2(:,1)/pi*180, ...
%                  obj.pool_a_tuning2(:,2)/pi*180, 'r*');
%             axis equal;
%             box off;
%             xlim([0 180]);
%             ylim([0 360]);
%             line(xlim, [30 30], 'color', 'k');
%             line(xlim, [330 330], 'color', 'k');
%             xlabel('Azimuith');
%             ylabel('Elevation');
%             title('Acceleration 2');
%             
%             subplot(2,3,6);
%             plot(obj.pool_j_tuning2(:,1)/pi*180, ...
%                  obj.pool_j_tuning2(:,2)/pi*180, 'r*');
%             axis equal;
%             box off;
%             xlim([0 180]);
%             ylim([0 360]);
%             line(xlim, [30 30], 'color', 'k');
%             line(xlim, [330 330], 'color', 'k');
%             xlabel('Azimuith');
%             ylabel('Elevation');
%             title('Jerk 2');

            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(2,3,1);
            bins = 0:15:180;
            dif_ang_v = 180-abs(obj.pool_v_tuning2(:,2)/pi*180-180);
            hc = histc(dif_ang_v, bins);
            bar(bins, hc, 'histc');
            hold on;
            plot(dif_ang_v, 0, 'r*');
            hold off;
            xlim([0 180]);
            box off;
            line([30 30], ylim, 'color', 'k');
            line([45 45], ylim, 'color', 'k');
            line([60 60], ylim, 'color', 'k');
            xlabel('Elevation');
            title('Velocity');
            
            subplot(2,3,2);
            dif_ang_a = 180-abs(obj.pool_a_tuning2(:,2)/pi*180-180);
            hc = histc(dif_ang_a, bins);
            bar(bins, hc, 'histc');
            hold on;
            plot(dif_ang_a, 0, 'r*');
            hold off;
            xlim([0 180]);
            box off;
            line([30 30], ylim, 'color', 'k');
            line([45 45], ylim, 'color', 'k');
            line([60 60], ylim, 'color', 'k');
            xlabel('Elevation');
            title('Acceleration');
            
            subplot(2,3,3);
            dif_ang_j = 180-abs(obj.pool_j_tuning2(:,2)/pi*180-180);
            hc = histc(dif_ang_j, bins);
            bar(bins, hc, 'histc');
            hold on;
            plot(dif_ang_j, 0, 'r*');
            hold off;
            xlim([0 180]);
            box off;
            line([30 30], ylim, 'color', 'k');
            line([45 45], ylim, 'color', 'k');
            line([60 60], ylim, 'color', 'k');
            xlabel('Elevation');
            title('Jerk');
        end
    end
end