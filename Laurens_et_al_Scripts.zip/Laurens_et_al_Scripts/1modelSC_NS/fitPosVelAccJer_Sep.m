classdef fitPosVelAccJer_Sep
    properties
        reps 
        psth
  
        u_azi
        u_ele
        time
        
        baseline
        
        A
        R_0
        mu_t
        
        p_ele_azi_profile
        p_space_profile
        p_A
        p_n
        p_a_0
        p_e_0
        p_DC
        
        v_ele_azi_profile
        v_space_profile
        v_A
        v_n
        v_a_0
        v_e_0
        v_DC

        a_ele_azi_profile
        a_space_profile
        a_A
        a_n
        a_a_0
        a_e_0
        a_DC
        
        j_ele_azi_profile
        j_space_profile
        j_A
        j_n
        j_a_0
        j_e_0
        j_DC

        w_p
        w_a
        w_j
        
        init_param
        
        posvelaccjer_param
        rand_param
        
        posvelaccjer_rss       
        rand_rss
        
        posvelaccjer_jac
        rand_jac
    end
    
    methods
        function obj = fitPosVelAccJer_Sep(p, reps)
            obj.reps = reps;
            obj.psth = p.psth;

            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            obj.baseline = p.baseline;

            stim_sig = sqrt(sqrt(2))/6;
            obj.mu_t = 1;
            
            %Compute Spatial Profiles
            i_gauss_time = i_gauss([obj.mu_t stim_sig], obj.time)';
            gauss_time = gauss([obj.mu_t stim_sig], obj.time)';
            d_gauss_time = d_gauss([obj.mu_t stim_sig], obj.time)';
            d2_gauss_time = d2_gauss([obj.mu_t stim_sig], obj.time)';
            
            u1 = i_gauss_time;
            p1 = (u1'*gauss_time)/(u1'*u1);
            u2 = gauss_time - p1*u1;
            p21 = (u1'*d_gauss_time)/(u1'*u1);
            p22 = (u2'*d_gauss_time)/(u2'*u2);
            u3 = d_gauss_time - p21*u1 - p22*u2;
            p31 = (u1'*d2_gauss_time)/(u1'*u1);
            p32 = (u2'*d2_gauss_time)/(u2'*u2);
            p33 = (u3'*d2_gauss_time)/(u3'*u3);
            u4 = d2_gauss_time - p31*u1 - p32*u2 - p33*u3;
            
            t_psth = obj.psth - obj.baseline;
            obj.p_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            obj.v_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            obj.a_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            obj.j_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);

            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi),
                    t_profile = squeeze(t_psth(i,j,:));
                    coeff = (pinv([u1 u2 u3 u4])*squeeze(t_profile));
                    obj.p_ele_azi_profile(i,j) = coeff(1) - ...
                                                 coeff(2)*p1 + ...
                                                 coeff(3)*(-p21+p22*p1) + ...
                                                 coeff(4)*(-p31+p32*p1+p33*(p21-p22*p1));
                    
                    obj.v_ele_azi_profile(i,j) = coeff(2) - coeff(3)*p22 + ...
                                                 coeff(4)*(-p32+p33*p22);
                    
                    obj.a_ele_azi_profile(i,j) = coeff(3) - coeff(4)*p33;
                    
                    obj.j_ele_azi_profile(i,j) = coeff(4);
                end
            end
            
            %Normalise Profiles 
            obj.p_DC = (min(obj.p_ele_azi_profile(:))+max(obj.p_ele_azi_profile(:)))/2;
            obj.p_A = (max(obj.p_ele_azi_profile(:))-min(obj.p_ele_azi_profile(:)))/2;
            obj.p_space_profile = obj.p_ele_azi_profile - obj.p_DC;                                         
            obj.p_space_profile = obj.p_space_profile/obj.p_A;
            
            obj.v_DC = (min(obj.v_ele_azi_profile(:))+max(obj.v_ele_azi_profile(:)))/2;
            obj.v_A = (max(obj.v_ele_azi_profile(:))-min(obj.v_ele_azi_profile(:)))/2;
            obj.v_space_profile = obj.v_ele_azi_profile - obj.v_DC;                                         
            obj.v_space_profile = obj.v_space_profile/obj.v_A;           
            
            obj.a_DC = (min(obj.a_ele_azi_profile(:))+max(obj.a_ele_azi_profile(:)))/2;
            obj.a_A = (max(obj.a_ele_azi_profile(:))-min(obj.a_ele_azi_profile(:)))/2;
            obj.a_space_profile = obj.a_ele_azi_profile - obj.a_DC;                                         
            obj.a_space_profile = obj.a_space_profile/obj.a_A;

            obj.j_DC = (min(obj.j_ele_azi_profile(:))+max(obj.j_ele_azi_profile(:)))/2;
            obj.j_A = (max(obj.j_ele_azi_profile(:))-min(obj.j_ele_azi_profile(:)))/2;
            obj.j_space_profile = obj.j_ele_azi_profile - obj.j_DC;                                         
            obj.j_space_profile = obj.j_space_profile/obj.j_A;
            
            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);
            
            %Fit spatial profile
            s_data = [obj.u_ele; obj.u_azi];

            LB = [0.001 0 -pi/2];
            UB = [10 2*pi pi/2]; 
            
            [~, max_idx] = max(obj.p_space_profile(:));
            [max_idx_a, max_idx_e] = ind2sub(size(obj.p_space_profile), max_idx);
            param = [0.01 obj.u_azi(max_idx_a) obj.u_ele(max_idx_e)];
            recon_p = lsqcurvefit('cos_tuning', param, s_data, ...
                obj.p_space_profile(:), LB, UB, options);
            obj.p_n   = recon_p(1);
            obj.p_a_0 = recon_p(2);
            obj.p_e_0 = recon_p(3);
            
            [~, max_idx] = max(obj.v_space_profile(:));
            [max_idx_a, max_idx_e] = ind2sub(size(obj.v_space_profile), max_idx);
            param = [0.01 obj.u_azi(max_idx_a) obj.u_ele(max_idx_e)];
            recon_v = lsqcurvefit('cos_tuning', param, s_data, ...
                obj.v_space_profile(:), LB, UB, options);
            obj.v_n   = recon_v(1);
            obj.v_a_0 = recon_v(2);
            obj.v_e_0 = recon_v(3);
            
            [~, max_idx] = max(obj.a_space_profile(:));
            [max_idx_a, max_idx_e] = ind2sub(size(obj.a_space_profile), max_idx);
            param = [0.01 obj.u_azi(max_idx_a) obj.u_ele(max_idx_e)];
            recon_a = lsqcurvefit('cos_tuning', param, s_data, ...
                obj.a_space_profile(:), LB, UB, options);
            obj.a_n   = recon_a(1);
            obj.a_a_0 = recon_a(2);
            obj.a_e_0 = recon_a(3);
            
            [~, max_idx] = max(obj.j_space_profile(:));
            [max_idx_a, max_idx_e] = ind2sub(size(obj.a_space_profile), max_idx);
            param = [0.01 obj.u_azi(max_idx_a) obj.u_ele(max_idx_e)];
            recon_j = lsqcurvefit('cos_tuning', param, s_data, ...
                obj.a_space_profile(:), LB, UB, options);
            obj.j_n   = recon_j(1);
            obj.j_a_0 = recon_j(2);
            obj.j_e_0 = recon_j(3);
           
            obj.p_DC = obj.p_DC/obj.p_A;
            obj.v_DC = obj.v_DC/obj.v_A;
            obj.a_DC = obj.a_DC/obj.a_A;
            obj.j_DC = obj.j_DC/obj.j_A;
            
            obj.A = obj.p_A + obj.v_A + obj.a_A + obj.j_A;
            obj.R_0 = obj.baseline;
            
            obj.w_p = obj.p_A/(obj.p_A + obj.v_A);
            obj.w_a = obj.a_A/(obj.p_A + obj.v_A + obj.a_A);
            obj.w_j = obj.j_A/obj.A;
            
            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);

            param = [obj.A, ...     %1
                     obj.R_0, ...   %2
                     obj.mu_t, ...  %3
                     obj.p_n, ...   %4                  
                     obj.p_a_0, ... %5
                     obj.p_e_0, ... %6
                     obj.p_DC, ...  %7
                     obj.v_n, ...   %8                  
                     obj.v_a_0, ... %9
                     obj.v_e_0, ... %10
                     obj.v_DC, ...  %11
                     obj.a_n, ...   %12
                     obj.a_a_0, ... %13
                     obj.a_e_0, ... %14
                     obj.a_DC, ...  %15
                     obj.j_n, ...   %16
                     obj.j_a_0, ... %17
                     obj.j_e_0, ... %18
                     obj.j_DC, ...  %19
                     obj.w_p, ...   %20
                     obj.w_a, ...   &21
                     obj.w_j];      %22        
            
            obj.init_param = param;
            
            y_data = packPSTH(obj.psth);

            LB = [0.25*obj.A, ...  %1  A
                  0, ...           %2  R_0
                  1, ...           %3  mu_t
                  0.1, ...       %4  p_n
                  0, ...           %5  p_a_0
                  -pi/2, ...       %6  p_e_0
                  -2, ...           %7  p_DC
                  0.1, ...       %8  v_n
                  0, ...           %9  v_a_0
                  -pi/2, ...       %10 v_e_0
                  -2, ...           %11 v_DC
                  0.1, ...       %12 a_n
                  0, ...           %13 a_a_0
                  -pi/2, ...       %14 a_e_0
                  -2, ...           %15 a_DC
                  0.1, ...       %16 j_n
                  0, ...           %17 j_a_0
                  -pi/2, ...       %18 j_e_0
                  -2, ...           %19 j_DC
                  0, ...           %20 w_p
                  0, ...           %21 w_a
                  0];              %22 w_j
              
            UB = [4*obj.A, ...     %1  A
                  300, ...         %2  R_0
                  1.5, ...         %3  mu_t
                  0.9, ...          %4  p_n
                  2*pi, ...        %5  p_a_0
                  pi/2, ...        %6  p_e_0
                  2, ...           %7  p_DC
                  0.9, ...          %8  v_n
                  2*pi, ...        %9  v_a_0
                  pi/2, ...        %10 v_e_0
                  2, ...           %11 v_DC
                  0.9, ...          %12 a_n
                  2*pi, ...        %13 a_a_0
                  pi/2, ...        %14 a_e_0
                  2, ...           %15 a_DC
                  0.9, ...          %16 j_n
                  2*pi, ...        %17 j_a_0
                  pi/2, ...        %18 j_e_0
                  2, ...           %19 j_D
                  1, ...           %20 w_p
                  1, ...           %21 w_a
                  1];              %22 w_j
            
            t_rand_rss = zeros(obj.reps+1,1);
            t_rand_param = zeros(obj.reps+1, length(param));
            t_rand_jac = zeros(obj.reps+1, length(param), length(param));

            [t_rand_param(1,:), t_rand_rss(1),~,~,~,~,tmp_jacobian] = ...
            lsqcurvefit('posvelaccjer_model', obj.init_param, st_data, y_data, LB, UB, options);
            t_rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
           
            %Randomise Initial Conditions
            err_range =  0.1*(UB - LB);
            min_param = t_rand_param(1,:);
            UB_param = min_param+err_range;
            LB_param = min_param-err_range;
            
            parfor i=2:obj.reps+1,
                %Randomise Initial Conditions
                seed_param  = unifrnd(LB, UB);
                
                [t_rand_param(i,:), t_rand_rss(i),~,~,~,~,tmp_jacobian] = ...
                 lsqcurvefit('posvelaccjer_sep_model', seed_param, st_data, y_data, LB, UB, options);
                 t_rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
            end
           
            obj.rand_param = t_rand_param;
            obj.rand_rss = t_rand_rss;
            obj.rand_jac = t_rand_jac;
            
            [~,min_idx] = min(obj.rand_rss);
            obj.posvelaccjer_param = obj.rand_param(min_idx,:);
            obj.posvelaccjer_rss = obj.rand_rss(min_idx);
            obj.posvelaccjer_jac = obj.rand_jac(min_idx,:,:);
        end
        
        function plotPSTH(obj, trial_name, page_num, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];           
            
            init_fit = posvelaccjer_model(obj.init_param, st_data);
            posvelaccjer_fit = posvelaccjer_model(obj.posvelaccjer_param, st_data);

            init_fit = unpackPSTH(init_fit, size(obj.psth));
            posvelaccjer_fit = unpackPSTH(posvelaccjer_fit, size(obj.psth));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(init_fit(i,j,:)), 'g');
                    plot(obj.time, squeeze(posvelaccjer_fit(i,j,:)), 'k');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page_num) ': ' trial_name];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                 'FontName', 'helvetica', 'FontSize', 12);
             
            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
        
        function printVal(obj)
            disp('Position + Velocity + Acceleration');
            disp(['A      : ' num2str(obj.velaccjer_param(1))]);
            disp(['R_0    : ' num2str(obj.velaccjer_param(2))]);
            
            disp(['v_mu_t : ' num2str(obj.velaccjer_param(3))]);
            disp(['v_sig_t: ' num2str(obj.velaccjer_param(4))]); 
            disp(['v_n    : ' num2str(obj.velaccjer_param(5))]);
            disp(['v_a_0  : ' num2str(obj.velaccjer_param(6)*180/pi)]);
            disp(['v_e_0  : ' num2str(obj.velaccjer_param(7)*180/pi)]);
            disp(['v_DC   : ' num2str(obj.velaccjer_param(8))]);
            
            disp(['a_mu_t : ' num2str(obj.velaccjer_param(9))]);
            disp(['a_sig_t: ' num2str(obj.velaccjer_param(10))]); 
            disp(['a_n    : ' num2str(obj.velaccjer_param(11))]);
            disp(['a_a_0  : ' num2str(obj.velaccjer_param(12)*180/pi)]);
            disp(['a_e_0  : ' num2str(obj.velaccjer_param(13)*180/pi)]);
            disp(['a_DC   : ' num2str(obj.velaccjer_param(14))]);
            
            disp(['j_mu_t : ' num2str(obj.velaccjer_param(15))]);
            disp(['j_sig_t: ' num2str(obj.velaccjer_param(16))]); 
            disp(['j_n    : ' num2str(obj.velaccjer_param(17))]);
            disp(['j_a_0  : ' num2str(obj.velaccjer_param(18)*180/pi)]);
            disp(['j_e_0  : ' num2str(obj.velaccjer_param(19)*180/pi)]);
            disp(['j_DC   : ' num2str(obj.velaccjer_param(20))]);
            
            disp(['w_v    : ' num2str(obj.velaccjer_param(21))]);
            disp(['w_j    : ' num2str(obj.velaccjer_param(22))]);
        end
        
    end 
end