function r = velaccjer_VariableSigma_model_nr(param, coord,u_azi,time)
    if nargin == 2
        u_ele = coord(1:5);
        u_azi = coord(6:14);
        time = coord(15:end);
    else
        u_ele = coord ;
    end
    stim_sig = param(18);
    
    %velocity model
    gauss_time = gauss([param(3) stim_sig], time);
    v_ele_azi = cos_tuning_JL(param(4:7), u_ele, u_azi) ;
    v_ele_azi = reshape(v_ele_azi, length(u_azi), length(u_ele));

    %acceleration model
    d_gauss_time = d_gauss([param(3) stim_sig], time);
    a_ele_azi = cos_tuning_JL(param(8:11), u_ele, u_azi) ;
    a_ele_azi = reshape(a_ele_azi, length(u_azi), length(u_ele));
    
    %jerk model
    d2_gauss_time = d2_gauss([param(3) stim_sig], time);
    j_ele_azi = cos_tuning_JL(param(12:15), u_ele, u_azi) ;
    j_ele_azi = reshape(j_ele_azi, length(u_azi), length(u_ele));
    
%     disp([v_ele_azi])
%     disp([a_ele_azi])
%     disp([j_ele_azi])
%     if find(isnan(j_ele_azi)), disp(cos_tuning(param(12:14), u_ele, u_azi));end
    %compute results
    r = zeros(size(v_ele_azi,1), size(v_ele_azi,2), length(gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            %r(i,j,:)
            rr = param(1)*( ...
                         (1-param(17))*( ...
                           param(16)*v_ele_azi(i,j)*gauss_time + ...
                           (1-param(16))*a_ele_azi(i,j)*d_gauss_time) + ...
                         param(17)*j_ele_azi(i,j)*d2_gauss_time) + ...
                       param(2);
                   
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%              rr(find(rr<0))  = 0;
             r(i,j,:) = rr;
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                  
        end
    end

    if nargin == 2, r = packPSTH(r);end
end