classdef fitVelJer
    properties
        reps       
        psth
        
        u_azi
        u_ele
        time
 
        baseline
        
        A
        R_0
        mu_t
        
        v_ele_azi_profile
        v_space_profile
        v_A
        v_n
        v_a_0
        v_e_0
        v_DC

        j_ele_azi_profile
        j_space_profile
        j_A
        j_n
        j_a_0
        j_e_0
        j_DC

        w
        
        init_param
        
        veljer_param
        rand_param
        
        veljer_rss       
        rand_rss
        
        veljer_jac
        rand_jac
    end
    
    methods
        function obj = fitVelJer(p, reps)
            obj.reps = reps;
            obj.psth = p.psth;

            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;
            st_data = [obj.u_ele; obj.u_azi; obj.time'];

            obj.baseline = p.baseline;
            
            stim_sig = sqrt(sqrt(2))/6;
            peak_i = find(obj.time >= 1, 1, 'first')-1;
            
            %Compute Temporal Profiles
            c = cell(2,1);
            lags = cell(2,1);
            idx = zeros(2,1);
            m = zeros(2,1);
            gauss_time = gauss([1 stim_sig], obj.time)';
            [cl, l] = xcorr(gauss_time, p.t_profile1, 20, 'coeff');
            neg_lags_idx = l < 0;
            lags{1} = l(neg_lags_idx);
            c{1} = cl(neg_lags_idx);
            [m(1), idx(1)] = max(abs(c{1}));
            
            d2_gauss_time = d2_gauss([1 stim_sig], obj.time)';
            [cl, l] = xcorr(d2_gauss_time, p.t_profile1, 20, 'coeff');
            lags{2} = l(neg_lags_idx);
            c{2} = cl(neg_lags_idx);
            [m(2), idx(2)] = max(abs(c{2}));
            
            profile1 = p.s_profile1;
            profile1(:,1) = profile1(1,1);
            profile1(:,end) = profile1(1,end);
            profile1(end,:) = profile1(1,:);
            
            profile2 = p.s_profile2;
            profile2(:,1) = profile2(1,1);
            profile2(:,end) = profile2(1,end);
            profile2(end,:) = profile2(1,:);

            [~,max_1] = max(m);
            switch max_1
                case 1
                    idx_i = idx(1);
                    delay_i = lags{1}(idx(1));
                    obj.mu_t = obj.time(peak_i - delay_i);
                    v_t_A = (max(p.t_profile1)-min(p.t_profile1))/2; 
                    j_t_A = (max(p.t_profile2)-min(p.t_profile2))/2;
                    
                    s = 1;
                    if c{1}(idx_i) < 0,
                        s = -1;
                    end
                    obj.v_ele_azi_profile = s*profile1;
                    
                    cl = xcorr(d2_gauss_time, p.t_profile2, 'coeff');
                    c_t = cl(neg_lags_idx);
                    s = 1;
                    if c_t(idx_i) < 0,
                        s = -1;
                    end
                    obj.j_ele_azi_profile = s*profile2;
                    
                case 2
                    idx_i = idx(2);
                    delay_i = lags{2}(idx(2));
                    obj.mu_t = obj.time(peak_i - delay_i);
                    v_t_A = (max(p.t_profile2)-min(p.t_profile2))/2;
                    j_t_A = (max(p.t_profile1)-min(p.t_profile1))/2; 
                    
                    cl = xcorr(gauss_time, p.t_profile2, 'coeff');
                    c_t = cl(neg_lags_idx);
                    s = 1;
                    if c_t(idx_i) < 0,
                        s = -1;
                    end
                    obj.v_ele_azi_profile = s*profile2;
                    
                    s = 1;
                    if c{2}(idx_i) < 0,
                        s = -1;
                    end                    
                    obj.j_ele_azi_profile = s*profile1;
            end

            %Compute Spatial Profiles
            obj.v_DC = (min(obj.v_ele_azi_profile(:))+max(obj.v_ele_azi_profile(:)))/2;
            v_s_A = (max(obj.v_ele_azi_profile(:))-min(obj.v_ele_azi_profile(:)))/2;         
            
            obj.v_space_profile = obj.v_ele_azi_profile-obj.v_DC;                                         
            obj.v_space_profile = obj.v_space_profile/v_s_A;  
            
            obj.j_DC = (min(obj.j_ele_azi_profile(:))+max(obj.j_ele_azi_profile(:)))/2;
            j_s_A = (max(obj.j_ele_azi_profile(:))-min(obj.j_ele_azi_profile(:)))/2;         
            
            obj.j_space_profile = obj.j_ele_azi_profile-obj.j_DC;                                         
            obj.j_space_profile = obj.j_space_profile/j_s_A;

            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);
            
            %Fit spatial profile
            s_data = [obj.u_ele; obj.u_azi];

            LB = [0.001 0 -pi/2];
            UB = [10 2*pi pi/2]; 
            
            [~, max_idx] = max(obj.v_space_profile(:));
            [max_idx_a, max_idx_e] = ind2sub(size(obj.v_space_profile), max_idx);
            param = [0.01 obj.u_azi(max_idx_a) obj.u_ele(max_idx_e)];
            recon_v = lsqcurvefit('cos_tuning', param, ...
                                  s_data, obj.v_space_profile(:), LB, UB, options);
            obj.v_n = recon_v(1);
            obj.v_a_0 = recon_v(2);
            obj.v_e_0 = recon_v(3); 

           LB = [0.001 0 -pi/2];
           UB = [10 2*pi pi/2];
           
           [~, max_idx] = max(obj.j_space_profile(:));
           [max_idx_a, max_idx_e] = ind2sub(size(obj.j_space_profile), max_idx);
           param = [0.01 obj.u_azi(max_idx_a) obj.u_ele(max_idx_e)];   
           recon_j = lsqcurvefit('cos_tuning', param, s_data, ...
                                 obj.j_space_profile(:), LB, UB, options);
           obj.j_n = recon_j(1);
           obj.j_a_0 = recon_j(2);
           obj.j_e_0 = recon_j(3); 

           obj.v_A = v_t_A*v_s_A;
           obj.j_A = j_t_A*j_s_A;
           
           obj.v_DC = obj.v_DC/v_s_A;
           obj.j_DC = obj.j_DC/j_s_A;
            
           obj.A = obj.v_A + obj.j_A;
           obj.R_0 = obj.baseline;
           obj.w = obj.v_A/obj.A;
 
            %Initial fits
            param = [obj.A, ...     %1  A
                     obj.R_0, ...   %2  R_0
                     obj.mu_t, ...  %3  v_mu_t
                     obj.v_n, ...   %4  v_n     
                     obj.v_a_0, ... %5  v_a_0
                     obj.v_e_0, ... %6  v_e_0
                     obj.v_DC, ...  %7  v_DC
                     obj.j_n, ...   %8  j_n       
                     obj.j_a_0, ... %9  j_a_0
                     obj.j_e_0, ... %10 j_e_0
                     obj.j_DC, ...  %11 j_DC
                     obj.w];        %12 w
            
            obj.init_param = zeros(obj.reps+1, length(param));
            obj.init_param = param;
            
            y_data = packPSTH(obj.psth);
            
            LB = [0.25*obj.A, ...  %1  A
                  0, ...           %2  R_0
                  1, ...           %3  mu_t
                  0.1, ...       %4  v_n
                  0, ...           %5  v_a_0
                  -pi/2, ...       %6  v_e_0
                  -2, ...           %7  v_DC
                  0.1, ...       %8  j_n
                  0, ...           %9  j_a_0
                  -pi/2, ...       %10 j_e_0
                  -2, ...           %11 j_DC
                  0];              %12 w
              
            UB = [4*obj.A, ...     %1  A
                  300, ...         %2  R_0
                  1.5, ...         %3  mu_t
                  0.9, ...          %4  v_n
                  2*pi, ...        %5  v_a_0
                  pi/2, ...        %6  v_e_0
                  2, ...           %7  v_DC
                  0.9, ...          %8  j_n
                  2*pi, ...        %9  j_a_0
                  pi/2, ...        %10 j_e_0
                  2, ...           %11 j_DC
                  1];              %12 w
                       
            t_rand_rss = zeros(obj.reps+1,1);
            t_rand_param = zeros(obj.reps+1, length(param));
            t_rand_jac = zeros(obj.reps+1, length(param), length(param));
              
            [t_rand_param(1,:), t_rand_rss(1),~,~,~,~,tmp_jacobian] = ...
            lsqcurvefit('veljer_model', obj.init_param, st_data, y_data, LB, UB, options);
            t_rand_jac(1,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);  

            %Initial Conditions Random Range
            err_range =  0.1*(UB - LB);
            min_param = t_rand_param(1,:);
            UB_param = min_param+err_range;
            LB_param = min_param-err_range;
           
            parfor i=2:obj.reps+1,
                %Randomise Initial Conditions
                seed_param  = unifrnd(LB, UB);
                
                [t_rand_param(i,:), t_rand_rss(i),~,~,~,~,tmp_jacobian] = ...
                 lsqcurvefit('veljer_model', seed_param, st_data, y_data, LB, UB, options);
                 t_rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
            end
            
            obj.rand_param = t_rand_param;
            obj.rand_rss = t_rand_rss;
            obj.rand_jac = t_rand_jac;
            
            [~,min_idx] = min(obj.rand_rss);
            obj.veljer_param = obj.rand_param(min_idx,:);
            obj.veljer_rss = obj.rand_rss(min_idx);
            obj.veljer_jac = obj.rand_jac(min_idx,:,:);
        end
        
        function plotPSTH(obj, trial_name, page_num, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            init_fit = veljer_model(obj.init_param(1,:), st_data); 
            veljer_fit = veljer_model(obj.veljer_param, st_data);
            
            init_fit = unpackPSTH(init_fit, size(obj.psth));
            veljer_fit = unpackPSTH(veljer_fit, size(obj.psth));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(init_fit(i,j,:)), 'g');
                    plot(obj.time, squeeze(veljer_fit(i,j,:)), 'k');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page_num) ': ' trial_name];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                 'FontName', 'helvetica', 'FontSize', 12);
             
            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
        
        function plotReconPSTH(obj)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            gauss_time = gauss([obj.mu_t obj.sig_t], obj.time);
            d2_gauss_time = d2_gauss([obj.mu_t obj.sig_t], obj.time);
            
            param = [obj.v_n obj.v_a_0 obj.v_e_0 ...
                     obj.v_n2 obj.v_a2_0 obj.v_e2_0 ...
                     obj.v_s_A2 obj.v_DC+obj.v_DC2];
            v_sp = d_cos_tuning(param, st_data);
            v_sp = reshape(v_sp, length(obj.u_azi), length(obj.u_ele));

            param = [obj.j_n obj.j_a_0 obj.j_e_0 ...
                     obj.j_n2 obj.j_a2_0 obj.j_e2_0 ...
                     obj.j_s_A2 obj.j_DC+obj.j_DC2];
            j_sp = d_cos_tuning(param, st_data);
            j_sp = reshape(j_sp, length(obj.u_azi), length(obj.u_ele));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;      
                    plot(obj.time, gauss_time*obj.v_ele_azi_profile(i,j) + ...
                                   d2_gauss_time*obj.j_ele_azi_profile(i,j) + ...
                                   obj.baseline, 'b');
%                     plot(obj.time, gauss_time*obj.v_A * ...
%                                    (obj.v_space_profile(i,j)+obj.v_DC) + ...
%                                    d2_gauss_time*obj.j_A * ...
%                                    (obj.j_space_profile(i,j)+obj.j_DC ) + ...
%                                    obj.baseline, 'g');
                    plot(obj.time, gauss_time*obj.v_A*v_sp(i,j) + ...
                                   d2_gauss_time*obj.j_A*j_sp(i,j) + ...
                                   obj.baseline, 'g');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
        end
        
        function printVal(obj, trial_name)
            disp('Velocity + Jerk');
            disp(trial_name);
                             
            [x, y, z] = sph2cart(obj.veljer_param(9), ... 
                                 obj.veljer_param(10), 1);
            disp(['v_r     : ' num2str(180/pi*acos([1 0 0]*[x y z]'))]);
            disp(['A       : ' num2str(obj.veljer_param(1))]);
            disp(['R_0     : ' num2str(obj.veljer_param(2))]);
            disp(['v_mu_t  : ' num2str(obj.veljer_param(3))]);
            disp(['v_sig_t : ' num2str(obj.veljer_param(4))]);
            disp(['v_n     : ' num2str(obj.veljer_param(5))]);
            disp(['v_a_0   : ' num2str(obj.veljer_param(6)*180/pi)]);
            disp(['v_e_0   : ' num2str(obj.veljer_param(7)*180/pi)]);
            disp(['v_n2    : ' num2str(obj.veljer_param(8))]);
            disp(['v_a2_0  : ' num2str(obj.veljer_param(9)*180/pi)]);
            disp(['v_e2_0  : ' num2str(obj.veljer_param(10)*180/pi)]);
            disp(['v_DC    : ' num2str(obj.veljer_param(11))]);
            disp(['v_A2    : ' num2str(obj.veljer_param(12))]);
            [x, y, z] = sph2cart(obj.veljer_param(19), ... 
                                 obj.veljer_param(20), 1);
            disp(['j_r     : ' num2str(180/pi*acos([1 0 0]*[x y z]'))]);
            disp(['j_mu_t  : ' num2str(obj.veljer_param(13))]);
            disp(['j_sig_t : ' num2str(obj.veljer_param(14))]);
            disp(['j_n     : ' num2str(obj.veljer_param(15))]);
            disp(['j_a_0   : ' num2str(obj.veljer_param(16)*180/pi)]);
            disp(['j_e_0   : ' num2str(obj.veljer_param(17)*180/pi)]);
            disp(['j_n2    : ' num2str(obj.veljer_param(18))]);
            disp(['j_a2_0  : ' num2str(obj.veljer_param(19)*180/pi)]);
            disp(['j_e2_0  : ' num2str(obj.veljer_param(20)*180/pi)]);
            disp(['j_DC    : ' num2str(obj.veljer_param(21))]);
            disp(['j_A2    : ' num2str(obj.veljer_param(22))]);
            disp(['w       : ' num2str(obj.veljer_param(23))]);
        end
    end 
end
