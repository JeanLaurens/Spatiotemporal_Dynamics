function r = posvelacc_model(param, coord,u_azi,time)
    if nargin == 2
        u_ele = coord(1:5);
        u_azi = coord(6:14);
        time = coord(15:end);
    else
        u_ele = coord ;
    end
    
    stim_sig = sqrt(sqrt(2))/6;
    
    %position model
    i_gauss_time = i_gauss([param(3) stim_sig], time);
    p_ele_azi = cos_tuning_JL(param(4:7), [u_ele; u_azi]);
    p_ele_azi = reshape(p_ele_azi, length(u_azi), length(u_ele));

    %velocity model
    gauss_time = gauss([param(3) stim_sig], time);
    v_ele_azi = cos_tuning_JL(param(8:11), [u_ele; u_azi]);
    v_ele_azi = reshape(v_ele_azi, length(u_azi), length(u_ele));
    
    %jerk model
    d_gauss_time = d_gauss([param(3) stim_sig], time);
    a_ele_azi = cos_tuning_JL(param(12:15), [u_ele; u_azi]);
    a_ele_azi = reshape(a_ele_azi, length(u_azi), length(u_ele));
    
    %compute results
    r = zeros(size(v_ele_azi,1), size(v_ele_azi,2), length(gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            rr = param(1)*( ...
                         (1-param(17))*( ...
                           param(16)*p_ele_azi(i,j)*i_gauss_time + ...
                           (1-param(16))*v_ele_azi(i,j)*gauss_time) + ...
                         param(17)*a_ele_azi(i,j)*d_gauss_time) + ...
                       param(2);
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
             rr(find(rr<0))  = 0;
             r(i,j,:) = rr;
  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
        end
    end

    if(nargin == 2), r = packPSTH(r);end
end