clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));

PATH = (['..' filesep '..' filesep 'Output' filesep 'S1H_Output_Xiongjie' filesep]);
s1h_psm = modelS1H.poolSelModel(PATH);

PATH = (['..' filesep '..' filesep 'Output' filesep 'S1HN_Output_Xiongjie' filesep]);
s1hn_psm = modelS1HN.poolSelModel(PATH);

s1h_jer_acc = s1h_psm.pool_weights(:,3)./s1h_psm.pool_weights(:,2);
s1h_vel_acc = s1h_psm.pool_weights(:,1)./s1h_psm.pool_weights(:,2);

s1hn_jer_acc = s1hn_psm.pool_weights(:,3)./s1hn_psm.pool_weights(:,2);
s1hn_vel_acc = s1hn_psm.pool_weights(:,1)./s1hn_psm.pool_weights(:,2);

max_val = max([s1h_jer_acc; s1h_vel_acc; s1hn_jer_acc; s1hn_vel_acc]);
min_val = min([s1h_jer_acc; s1h_vel_acc; s1hn_jer_acc; s1hn_vel_acc]);

scrsz = get(0,'ScreenSize');
figure('Position', scrsz, 'Renderer', 'painters');
subplot(2,2,1);
plot(s1h_jer_acc, s1hn_jer_acc, '*');
hold on;
plot([min_val max_val], [min_val max_val], 'k-');
hold off;
xlim([min_val max_val]);
ylim([min_val max_val]);
title(['Wilcoxon signed-rank P-value: ' num2str(signrank(s1h_jer_acc, s1hn_jer_acc))]);
xlabel('S1H Jer/Acc Weights');
ylabel('S1HN Jer/Acc Weights');
box off;
set(gca, 'fontSize', 12);

subplot(2,2,2);
plot(s1h_vel_acc, s1hn_vel_acc, '*');
hold on;
plot([min_val max_val], [min_val max_val], 'k-');
hold off;
xlabel('S1H Vel/Acc Weights');
ylabel('S1HN Vel/Acc Weights');
box off;
xlim([min_val max_val]);
ylim([min_val max_val]);
title(['Wilcoxon signed-rank P-value: ' num2str(signrank(s1h_vel_acc, s1hn_vel_acc))]);
set(gca, 'fontSize', 12);

set(findall(gcf,'type','text'),'fontSize',24);