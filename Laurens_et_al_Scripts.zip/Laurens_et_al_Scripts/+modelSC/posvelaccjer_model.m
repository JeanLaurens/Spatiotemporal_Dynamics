function r = posvelaccjer_model(param, coord)
    u_ele = coord(1:5);
    u_azi = coord(6:14);
    time = coord(15:end);
    
    stim_sig = sqrt(sqrt(2))/6;
    
    %position model
    i_gauss_time = i_gauss([param(3) stim_sig], time);
    p_ele_azi = cos_tuning(param(4:6), [u_ele; u_azi]) + param(7);
    p_ele_azi = reshape(p_ele_azi, length(u_azi), length(u_ele));

    %velocity model
    gauss_time = gauss([param(3) stim_sig], time);
    v_ele_azi = cos_tuning(param(8:10), [u_ele; u_azi]) + param(11);
    v_ele_azi = reshape(v_ele_azi, length(u_azi), length(u_ele));
    
    %acceleration model
    d_gauss_time = d_gauss([param(3) stim_sig], time);
    a_ele_azi = cos_tuning(param(12:14), [u_ele; u_azi]) + param(15);
    a_ele_azi = reshape(a_ele_azi, length(u_azi), length(u_ele));
    
    %jerk model
    d2_gauss_time = d2_gauss([param(3) stim_sig], time);
    j_ele_azi = cos_tuning(param(16:18), [u_ele; u_azi]) + param(19);
    j_ele_azi = reshape(j_ele_azi, length(u_azi), length(u_ele));
    
    %compute results
    r = zeros(size(v_ele_azi,1), size(v_ele_azi,2), length(gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            r(i,j,:) = param(1)*( ...
                         (1-param(22))*( ...
                           (1-param(21))*( ...
                               param(20)*p_ele_azi(i,j)*i_gauss_time + ...
                               (1-param(20))*v_ele_azi(i,j)*gauss_time) + ...
                           param(21)*a_ele_azi(i,j)*d_gauss_time) + ...
                         param(22)*j_ele_azi(i,j)*d2_gauss_time) + ...
                       param(2);
        end
    end

    r = packPSTH(r);
end