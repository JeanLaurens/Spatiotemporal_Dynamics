classdef selModel
    properties
        psth
        u_azi
        u_ele
        
        time
        
        cv_star
        
        bic
        bic_pick
        bic_type
        
        bic_fit
        bic_model
        bic_param
        
        bic_mu_t

        bic_azi
        bic_ele

        bic_jac
        bic_rss
        bic_tss
        
        bic_w
        
        sp_pos
        sp_vel
        sp_acc
        sp_jer
        
        sp_pos_param
        sp_vel_param
        sp_acc_param
        sp_jer_param
        
        i_gauss_time
        gauss_time
        d_gauss_time
        d2_gauss_time
    end
    
    methods
        function obj = selModel(p, ...
                                fv, fa, fj, ...
                                fva, fvj, faj, fvaj, ...
                                fpva, fpvj, fpaj, fpvaj)
            
            obj.psth = p.psth;
            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;
            
            obj.cv_star = p.cv_star;
            
            n = length(packPSTH(p.psth));

            stim_sig = sqrt(sqrt(2))/6;
            
            v = n*log(fv.vel_rss/n) + 2*length(fv.vel_param)*log(n);
            a = n*log(fa.acc_rss/n) + 2*length(fa.acc_param)*log(n);
            j = n*log(fj.jer_rss/n) + 2*length(fj.jer_param)*log(n);
            
            va = n*log(fva.velacc_rss/n) + 2*length(fva.velacc_param)*log(n);
            vj = n*log(fvj.veljer_rss/n) + 2*length(fvj.veljer_param)*log(n);
            aj = n*log(faj.accjer_rss/n) + 2*length(faj.accjer_param)*log(n);

            vaj = n*log(fvaj.velaccjer_rss/n) + 2*length(fvaj.velaccjer_param)*log(n);
            pva = n*log(fpva.posvelacc_rss/n) + 2*length(fpva.posvelacc_param)*log(n);
            pvj = n*log(fpvj.posveljer_rss/n) + 2*length(fpvj.posveljer_param)*log(n);
            paj = n*log(fpaj.posaccjer_rss/n) + 2*length(fpaj.posaccjer_param)*log(n);

            pvaj = n*log(fpvaj.posvelaccjer_rss/n) + 2*length(fpvaj.posvelaccjer_param)*log(n);
            
            [obj.bic, obj.bic_type] = min([v a j va vj aj vaj pva pvj paj pvaj]);
            
            obj.bic_tss = sum((p.psth(:)-mean(p.psth(:))).^2);
            
            obj.bic_azi = nan(4, 1);
            obj.bic_ele = nan(4, 1);
            
            obj.bic_w = zeros(4, 1);
            
            s_data = [obj.u_ele; obj.u_azi];
            
            switch obj.bic_type,
                case 1
                    obj.bic_fit = fv;
                    obj.bic_model = @vel_model;
                    obj.bic_param = fv.vel_param;
                    obj.bic_azi(2) = obj.bic_param(5);
                    obj.bic_ele(2) = obj.bic_param(6);
    
                    obj.bic_jac = fv.vel_jac;
                    
                    obj.bic_rss = fv.rand_rss;
                    
                    obj.sp_vel_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_vel = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.i_gauss_time = NaN;
                    obj.gauss_time = gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d_gauss_time = NaN;
                    obj.d2_gauss_time = NaN;
                    
                    obj.bic_jac = fv.vel_jac;
                    
                    obj.bic_rss = fv.rand_rss;

                    obj.bic_w(2) = 1;
                                
                case 2
                    obj.bic_fit = fa;
                    obj.bic_model = @acc_model;
                    obj.bic_param = fa.acc_param;
                    obj.bic_azi(3) = obj.bic_param(5);
                    obj.bic_ele(3) = obj.bic_param(6);

                    obj.sp_acc_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_acc = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.i_gauss_time = NaN;
                    obj.gauss_time = NaN;
                    obj.d_gauss_time = d_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d2_gauss_time = NaN;
                    
                    obj.bic_jac = fa.acc_jac;
                    
                    obj.bic_rss = fa.rand_rss;

                    obj.bic_w(3) = 1;
      
                case 3
                    obj.bic_fit = fj;
                    obj.bic_model = @jer_model;
                    obj.bic_param = fj.jer_param;
                    obj.bic_azi(4) = obj.bic_param(5);
                    obj.bic_ele(4) = obj.bic_param(6);

                    obj.sp_jer_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_jer = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.i_gauss_time = NaN;
                    obj.gauss_time = NaN;
                    obj.d_gauss_time = NaN;
                    obj.d2_gauss_time = d2_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    
                    obj.bic_jac = fj.jer_jac;
                    
                    obj.bic_rss = fj.rand_rss;

                    obj.bic_w(4) = 1;
            
                case 4
                    obj.bic_fit = fva;
                    obj.bic_model = @velacc_model;
                    obj.bic_param = fva.velacc_param;
                    obj.bic_azi(2) = obj.bic_param(5);
                    obj.bic_ele(2) = obj.bic_param(6);
                    obj.bic_azi(3) = obj.bic_param(9);
                    obj.bic_ele(3) = obj.bic_param(10);
                
                    obj.bic_jac =  fva.velacc_jac;
                    
                    obj.bic_rss = fva.rand_rss;

                    obj.sp_vel_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_vel = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_acc_param = [obj.bic_param(8:10) obj.bic_param(11)];
                    sp = cos_tuning(obj.bic_param(8:10), s_data) + obj.bic_param(11);
                    obj.sp_acc = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.i_gauss_time = NaN;
                    obj.gauss_time = gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d_gauss_time = d_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d2_gauss_time = NaN;
                    
                    obj.bic_w(2) = obj.bic_param(12);
                    obj.bic_w(3) = 1-obj.bic_param(12);
                
                case 5
                    obj.bic_fit = fvj;
                    obj.bic_model = @veljer_model;
                    obj.bic_param = fvj.veljer_param;
                    obj.bic_azi(2) = obj.bic_param(5);
                    obj.bic_ele(2) = obj.bic_param(6);
                    obj.bic_azi(4) = obj.bic_param(9);
                    obj.bic_ele(4) = obj.bic_param(10);

                    obj.bic_jac = fvj.veljer_jac;
                    
                    obj.bic_rss = fvj.rand_rss;
                    
                    obj.sp_vel_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_vel = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_jer_param = [obj.bic_param(8:10) obj.bic_param(11)];
                    sp = cos_tuning(obj.bic_param(8:10), s_data) + obj.bic_param(11);
                    obj.sp_jer = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.i_gauss_time = NaN;
                    obj.gauss_time = gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d_gauss_time = NaN;
                    obj.d2_gauss_time = d2_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    
                    obj.bic_w(2) = obj.bic_param(12);
                    obj.bic_w(4) = 1-obj.bic_param(12);
                    
                case 6
                    obj.bic_fit = faj;
                    obj.bic_model = @accjer_model;
                    obj.bic_param = faj.accjer_param;
                    obj.bic_azi(3) = obj.bic_param(5);
                    obj.bic_ele(3) = obj.bic_param(6);
                    obj.bic_azi(4) = obj.bic_param(9);
                    obj.bic_ele(4) = obj.bic_param(10);

                    obj.bic_jac = faj.accjer_jac;
                    
                    obj.bic_rss = faj.rand_rss;
                    
                    obj.sp_acc_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_acc = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_jer_param = [obj.bic_param(8:10) obj.bic_param(11)];
                    sp = cos_tuning(obj.bic_param(8:10), s_data) + obj.bic_param(11);
                    obj.sp_jer = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.i_gauss_time = NaN;
                    obj.gauss_time = NaN;
                    obj.d_gauss_time = d_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d2_gauss_time = d2_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    
                    obj.bic_w(3) = obj.bic_param(12);
                    obj.bic_w(4) = 1-obj.bic_param(12);
            
                case 7
                    obj.bic_fit = fvaj;
                    obj.bic_model = @velaccjer_model;
                    obj.bic_param = fvaj.velaccjer_param;
                    obj.bic_azi(2) = obj.bic_param(5);
                    obj.bic_ele(2) = obj.bic_param(6);
                    obj.bic_azi(3) = obj.bic_param(9);
                    obj.bic_ele(3) = obj.bic_param(10);
                    obj.bic_azi(4) = obj.bic_param(13);
                    obj.bic_ele(4) = obj.bic_param(14);

                    obj.bic_jac = fvaj.velaccjer_jac;

                    obj.bic_rss = fvaj.rand_rss;

                    obj.sp_vel_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_vel = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_acc_param = [obj.bic_param(8:10) obj.bic_param(11)];
                    sp = cos_tuning(obj.bic_param(8:10), s_data) + obj.bic_param(11);
                    obj.sp_acc = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_jer_param = [obj.bic_param(12:14) obj.bic_param(15)];
                    sp = cos_tuning(obj.bic_param(12:14), s_data) + obj.bic_param(15);
                    obj.sp_jer = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.i_gauss_time = NaN;
                    obj.gauss_time = gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d_gauss_time = d_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d2_gauss_time = d2_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    
                    w_v = obj.bic_param(16);
                    w_j = obj.bic_param(17);
                    obj.bic_w(2) = (1 - w_j)*w_v;
                    obj.bic_w(3) = (1 - w_j)*(1 - w_v);
                    obj.bic_w(4) = w_j;
                    
                case 8
                    obj.bic_fit = fpva;
                    obj.bic_model = @posvelacc_model;
                    obj.bic_param = fpva.posvelacc_param;
                    obj.bic_azi(1) = obj.bic_param(5);
                    obj.bic_ele(1) = obj.bic_param(6);
                    obj.bic_azi(2) = obj.bic_param(9);
                    obj.bic_ele(2) = obj.bic_param(10);
                    obj.bic_azi(3) = obj.bic_param(13);
                    obj.bic_ele(3) = obj.bic_param(14);

                    obj.bic_jac = fpva.posvelacc_jac;

                    obj.bic_rss = fpva.rand_rss;

                    obj.sp_pos_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_pos = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_vel_param = [obj.bic_param(8:10) obj.bic_param(11)];
                    sp = cos_tuning(obj.bic_param(8:10), s_data) + obj.bic_param(11);
                    obj.sp_vel = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_acc_param = [obj.bic_param(12:14) obj.bic_param(15)];
                    sp = cos_tuning(obj.bic_param(12:14), s_data) + obj.bic_param(15);
                    obj.sp_acc = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.i_gauss_time = i_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.gauss_time = gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d_gauss_time = d_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d2_gauss_time = NaN;
                    
                    w_v = obj.bic_param(16);
                    w_j = obj.bic_param(17);
                    obj.bic_w(1) = (1 - w_j)*w_v;
                    obj.bic_w(2) = (1 - w_j)*(1 - w_v);
                    obj.bic_w(3) = w_j;
               
                case 9
                    obj.bic_fit = fpvj;
                    obj.bic_model = @posveljer_model;
                    obj.bic_param = fpvj.posveljer_param;
                    obj.bic_azi(1) = obj.bic_param(5);
                    obj.bic_ele(1) = obj.bic_param(6);
                    obj.bic_azi(2) = obj.bic_param(9);
                    obj.bic_ele(2) = obj.bic_param(10);
                    obj.bic_azi(4) = obj.bic_param(13);
                    obj.bic_ele(4) = obj.bic_param(14);

                    obj.bic_jac = fpvj.posveljer_jac;

                    obj.bic_rss = fpvj.rand_rss;

                    obj.sp_pos_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_pos = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_vel_param = [obj.bic_param(8:10) obj.bic_param(11)];
                    sp = cos_tuning(obj.bic_param(8:10), s_data) + obj.bic_param(11);
                    obj.sp_vel = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_jer_param = [obj.bic_param(12:14) obj.bic_param(15)];
                    sp = cos_tuning(obj.bic_param(12:14), s_data) + obj.bic_param(15);
                    obj.sp_jer = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.i_gauss_time = i_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.gauss_time = gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d_gauss_time = NaN;
                    obj.d2_gauss_time = d2_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    
                    w_v = obj.bic_param(16);
                    w_j = obj.bic_param(17);
                    obj.bic_w(1) = (1 - w_j)*w_v;
                    obj.bic_w(2) = (1 - w_j)*(1 - w_v);
                    obj.bic_w(4) = w_j;
                    
                case 10
                    obj.bic_fit = fpaj;
                    obj.bic_model = @posaccjer_model;
                    obj.bic_param = fpaj.posaccjer_param;
                    obj.bic_azi(1) = obj.bic_param(5);
                    obj.bic_ele(1) = obj.bic_param(6);
                    obj.bic_azi(3) = obj.bic_param(9);
                    obj.bic_ele(3) = obj.bic_param(10);
                    obj.bic_azi(4) = obj.bic_param(13);
                    obj.bic_ele(4) = obj.bic_param(14);

                    obj.bic_jac = fpaj.posaccjer_jac;

                    obj.bic_rss = fpaj.rand_rss;

                    obj.sp_pos_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_pos = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_acc_param = [obj.bic_param(8:10) obj.bic_param(11)];
                    sp = cos_tuning(obj.bic_param(8:10), s_data) + obj.bic_param(11);
                    obj.sp_acc = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_jer_param = [obj.bic_param(12:14) obj.bic_param(15)];
                    sp = cos_tuning(obj.bic_param(12:14), s_data) + obj.bic_param(15);
                    obj.sp_jer = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.i_gauss_time = i_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.gauss_time = NaN;
                    obj.d_gauss_time = d_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d2_gauss_time = d2_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    
                    w_v = obj.bic_param(16);
                    w_j = obj.bic_param(17);
                    obj.bic_w(1) = (1 - w_j)*w_v;
                    obj.bic_w(3) = (1 - w_j)*(1 - w_v);
                    obj.bic_w(4) = w_j;
                    
                case 11
                    obj.bic_fit = fpvaj;
                    obj.bic_model = @posvelaccjer_model;
                    obj.bic_param = fpvaj.posvelaccjer_param;
                    obj.bic_azi(1) = obj.bic_param(5);
                    obj.bic_ele(1) = obj.bic_param(6);
                    obj.bic_azi(2) = obj.bic_param(9);
                    obj.bic_ele(2) = obj.bic_param(10);
                    obj.bic_azi(3) = obj.bic_param(13);
                    obj.bic_ele(3) = obj.bic_param(14);                   
                    obj.bic_azi(4) = obj.bic_param(17);
                    obj.bic_ele(4) = obj.bic_param(18);
                    
                    obj.bic_jac = fpvaj.posvelaccjer_jac;

                    obj.bic_rss = fpvaj.rand_rss;

                    obj.sp_pos_param = [obj.bic_param(4:6) obj.bic_param(7)];
                    sp = cos_tuning(obj.bic_param(4:6), s_data) + obj.bic_param(7);
                    obj.sp_pos = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_vel_param = [obj.bic_param(8:10) obj.bic_param(11)];
                    sp = cos_tuning(obj.bic_param(8:10), s_data) + obj.bic_param(11);
                    obj.sp_vel = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_acc_param = [obj.bic_param(12:14) obj.bic_param(15)];
                    sp = cos_tuning(obj.bic_param(12:14), s_data) + obj.bic_param(15);
                    obj.sp_acc = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.sp_jer_param = [obj.bic_param(16:18) obj.bic_param(19)];
                    sp = cos_tuning(obj.bic_param(16:18), s_data) + obj.bic_param(19);
                    obj.sp_jer = reshape(sp, length(obj.u_azi), length(obj.u_ele));
                    
                    obj.bic_mu_t = obj.bic_param(3);
                    obj.i_gauss_time = i_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.gauss_time = gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d_gauss_time = d_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    obj.d2_gauss_time = d2_gauss([obj.bic_mu_t stim_sig], obj.time)';
                    
                    w_p = obj.bic_param(20);
                    w_a = obj.bic_param(21);
                    w_j = obj.bic_param(22);
                    obj.bic_w(1) = (1 - w_j)*(1 - w_a)*w_p;
                    obj.bic_w(2) = (1 - w_j)*(1 - w_a)*(1 - w_p);
                    obj.bic_w(3) = (1 - w_j)*w_a;
                    obj.bic_w(4) = w_j; 
            end
        end
        
        function plotPSTH(obj, page, trial_name, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];           
            dim = [length(obj.u_azi),length(obj.u_ele), length(obj.time)];

            model_fit = unpackPSTH(obj.bic_model(obj.bic_param, st_data), dim);  
            t_covmat = inv(squeeze(obj.bic_jac));
            
            covmat_diag = sqrt(diag(t_covmat));
            bic_covmat = zeros(size(t_covmat));
            for i=1:size(t_covmat,1),
                for j=1:size(t_covmat,2),
                    bic_covmat(i,j) = t_covmat(i,j)/(covmat_diag(i)*covmat_diag(j));
                end
            end        
        
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            dif_spikes = (max_spikes-min_spikes)/2;
            
            model_err = zeros(26, length(obj.time));
            err_i = 0;
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    area(obj.time, squeeze(obj.psth(i,j,:)), ...
                            'FaceColor', 'r', 'EdgeColor','r');
                    hold on;
                    %plot(obj.time, squeeze(obj.psth(i,j,:)), 'r.');
                    plot(obj.time, squeeze(model_fit(i,j,:)), 'b','LineWidth', 2); 
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([1 1], ylim, 'color', 'k', 'linestyle', '--');
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                    
                    err_i = err_i + 1;
                    model_err(err_i,:) = squeeze(obj.psth(i,j,:)-model_fit(i,j,:));
                end
            end

            offset = length(obj.u_ele)*(length(obj.u_azi)-1);
            subplot(length(obj.u_ele), length(obj.u_azi)-1, length(obj.u_azi)-1-3);
            bar(obj.bic_w);
            box off;
            set(gca,'XTickLabel',{'P','V','A','J'});
            ylim([0 1]);
            ylabel('Weights');
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, length(obj.u_azi)-1-2);
            for i=1:size(model_err, 1),
                hold on;
                plot(obj.time, squeeze(model_err(i,:)), 'b');
                hold off;
            end
            axis tight;
            ylim([-dif_spikes dif_spikes]);
            box off;
            line([1 1], ylim, 'color', 'k', 'linestyle', '--');
            line(xlim, [0 0], 'color', 'k');
            line([0 0], ylim, 'color', 'k');
            line(2*[1 1], ylim, 'color', 'k');
            xlabel('Time (s)');
            ylabel('Error');
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, length(obj.u_azi)-1-[1 0]);
            plot(obj.time, obj.bic_w(1)*obj.i_gauss_time, 'k');
            hold on;
            plot(obj.time, obj.bic_w(2)*obj.gauss_time, 'b');
            plot(obj.time, obj.bic_w(3)*obj.d_gauss_time, 'r');
            plot(obj.time, obj.bic_w(4)*obj.d2_gauss_time, 'g');
            hold off;
            axis tight;
            box off;
            line([1 1], ylim, 'color', 'k', 'linestyle', '--');
            line(xlim, [0 0], 'color', 'k');
            line([0 0], ylim, 'color', 'k');
            line(2*[1 1], ylim, 'color', 'k');
            title('Time Profiles');
            xlabel('Time (s)');
            ylabel('Coefficients');
            
            sp = [];
            if ~isnan(obj.sp_pos),
                sp = [sp obj.bic_w(1)*obj.sp_pos];
            end
            
            if ~isnan(obj.sp_vel),
                sp = [sp obj.bic_w(2)*obj.sp_vel];
            end

            if ~isnan(obj.sp_acc),
                sp = [sp obj.bic_w(3)*obj.sp_acc];
            end

            if ~isnan(obj.sp_jer)
                sp = [sp obj.bic_w(4)*obj.sp_jer];
            end
            
            max_sp = max(sp(:));
            min_sp = min(sp(:));

            if ~isnan(obj.sp_pos),
                subplot(length(obj.u_ele), length(obj.u_azi)-1, offset-4);
                contourf(obj.u_azi*180/pi, obj.u_ele*180/pi, obj.bic_w(1)*obj.sp_vel');
                set(gca, 'CLim', [min_sp max_sp]);
                colorbar('EastOutside');
                box off;         
                title('Position Spatial Tuning');
                xlabel('Azimuth (Deg.)');
                ylabel('Elevation (Deg.)');
            end
            
            if ~isnan(obj.sp_vel),
                subplot(length(obj.u_ele), length(obj.u_azi)-1, offset-3);
                contourf(obj.u_azi*180/pi, obj.u_ele*180/pi, obj.bic_w(1)*obj.sp_vel');
                set(gca, 'CLim', [min_sp max_sp]);
                colorbar('EastOutside');
                box off;
                title('Velocity Spatial Tuning');
                xlabel('Azimuth (Deg.)');
                ylabel('Elevation (Deg.)');
            end

            if ~isnan(obj.sp_acc),
                subplot(length(obj.u_ele), length(obj.u_azi)-1, offset-1);
                contourf(obj.u_azi*180/pi, obj.u_ele*180/pi, obj.bic_w(2)*obj.sp_acc');
                set(gca, 'CLim', [min_sp max_sp]);
                colorbar('EastOutside');
                box off;
                title('Acceleration Spatial Tuning');
                xlabel('Azimuth (Deg.)');
                ylabel('Elevation (Deg.)');
            end

            if ~isnan(obj.sp_jer)
                subplot(length(obj.u_ele), length(obj.u_azi)-1, offset);
                contourf(obj.u_azi*180/pi, obj.u_ele*180/pi, obj.bic_w(3)*obj.sp_jer');
                set(gca, 'CLim', [min_sp max_sp]);
                colorbar('EastOutside');
                box off;
                title('Jerk Spatial Tuning' );
                xlabel('Azimuth (Deg.)');
                ylabel('Elevation (Deg.)');
            end

            if nargin == 3,
                text_size = 6;
            else
                text_size = 10;
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            tabstring = ['Trial ' num2str(page) ': ' trial_name ...
                         ', R2: ' num2str(1 - min(obj.bic_rss)/obj.bic_tss, '%1.3f')];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size);

            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
        
        function plotPSTH2(obj, page, trial_name, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];           
            dim = [length(obj.u_azi),length(obj.u_ele), length(obj.time)];

            model_fit = unpackPSTH(obj.bic_model(obj.bic_param, st_data), dim);  
            t_covmat = inv(squeeze(obj.bic_jac));
            
            covmat_diag = sqrt(diag(t_covmat));
            bic_covmat = zeros(size(t_covmat));
            for i=1:size(t_covmat,1),
                for j=1:size(t_covmat,2),
                    bic_covmat(i,j) = t_covmat(i,j)/(covmat_diag(i)*covmat_diag(j));
                end
            end        
        
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r.');
                    plot(obj.time, squeeze(model_fit(i,j,:)), 'b'); 
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end

            offset = length(obj.u_ele)*(length(obj.u_azi)-1);
            subplot(length(obj.u_ele), length(obj.u_azi)-1, offset);
            text(obj.bic_ele(1)/pi*180, obj.bic_azi(1)/pi*180, 'V', 'Color', 'b');
            text(obj.bic_ele(2)/pi*180, obj.bic_azi(2)/pi*180, 'A', 'Color', 'b');
            text(obj.bic_ele(3)/pi*180, obj.bic_azi(3)/pi*180, 'J', 'Color', 'b');
            box off;
            ylim([0 360]);
            xlim([-90 90]);
            ylabel('Azimuth (deg)');
            xlabel('Elevation (deg)');

            subplot(length(obj.u_ele), length(obj.u_azi)-1, offset-1);
            plot(obj.bic_w, 1:3, 'b*');
            box off;
            set(gca,'YTick', 1:3);
            set(gca,'YTickLabel',{'V','A','J'});
            xlim([0 1]);
            xlabel('Weights');
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, offset-[3 2]);
            plot(1 - sort(obj.bic_rss)/obj.bic_tss, 'b');
            xlabel('Trial');
            ylabel('R2');
            axis tight;
            box off;
            ylim([0 1]);
%             subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
%                    length(obj.u_azi)-1);
%             imagesc(bic_covmat);         
%             %colorbar('location','southoutside');
%             caxis([-1 1]);
%             box off;
            
            if nargin == 3,
                text_size = 6;
            else
                text_size = 10;
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page) ' : ' trial_name, ...
                         ', R2: ' num2str(1 - min(obj.bic_rss)/obj.bic_tss)];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size);

            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
        
        function plotCovMat(obj, trial_name, path)             
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz);
            
            subplot(3,4,1);
            t_covmat = inv(squeeze(obj.fp.pos_jac));
            covmat_diag = sqrt(diag(t_covmat));
            pos_covmat = zeros(size(t_covmat));
            for i=1:size(pos_covmat,1),
                for j=1:size(pos_covmat,2),
                    pos_covmat(i,j) = t_covmat(i,j)/(covmat_diag(i)*covmat_diag(j));
                end
            end
            imagesc(pos_covmat);
            caxis([-1 1]);
            colorbar;
            axis image;
            box off;
            title('P');

            subplot(3,4,2);
            t_covmat = inv(squeeze(obj.fv.vel_jac));
            covmat_diag = sqrt(diag(t_covmat));
            vel_covmat = zeros(size(t_covmat));
            for i=1:size(vel_covmat,1),
                for j=1:size(vel_covmat,2),
                    vel_covmat(i,j) = t_covmat(i,j)/(covmat_diag(i)*covmat_diag(j));
                end
            end
            imagesc(squeeze(vel_covmat));   
            caxis([-1 1]);
            colorbar;
            axis image;
            box off;
            title('V');
            
            subplot(3,4,3);
            t_covmat = inv(squeeze(obj.fa.acc_jac));
            covmat_diag = sqrt(diag(t_covmat));
            acc_covmat = zeros(size(t_covmat));
            for i=1:size(acc_covmat,1),
                for j=1:size(acc_covmat,2),
                    acc_covmat(i,j) = t_covmat(i,j)/(covmat_diag(i)*covmat_diag(j));
                end
            end
            imagesc(acc_covmat);  
            caxis([-1 1]);
            colorbar;
            axis image;
            box off;
            title('A');
            
            subplot(3,4,4);
            t_covmat = inv(squeeze(obj.fj.jer_jac));
            covmat_diag = sqrt(diag(t_covmat));
            jer_covmat = zeros(size(t_covmat));
            for i=1:size(jer_covmat,1),
                for j=1:size(jer_covmat,2),
                    jer_covmat(i,j) = t_covmat(i,j)/(covmat_diag(i)*covmat_diag(j));
                end
            end
            imagesc(real(jer_covmat));
            caxis([-1 1]);
            colorbar;
            axis image;
            box off;
            title('J');            
            
            subplot(3,4,5);
            t_covmat = inv(squeeze(obj.fva.velacc_jac));
            covmat_diag = sqrt(diag(t_covmat));
            velacc_covmat = zeros(size(t_covmat));
            for i=1:size(velacc_covmat,1),
                for j=1:size(velacc_covmat,2),
                    velacc_covmat(i,j) = t_covmat(i,j)/(covmat_diag(i)*covmat_diag(j));
                end
            end
            imagesc(velacc_covmat);
            caxis([-1 1]);
            colorbar;
            axis image;
            box off;
            title('V + A');
            
            subplot(3,4,6);
            t_covmat = inv(squeeze(obj.faj.accjer_jac));
            covmat_diag = sqrt(diag(t_covmat));
            accjer_covmat = zeros(size(t_covmat));
            for i=1:size(accjer_covmat,1),
                for j=1:size(accjer_covmat,2),
                    accjer_covmat(i,j) = t_covmat(i,j)/(covmat_diag(i)*covmat_diag(j));
                end
            end
            imagesc(accjer_covmat);
            caxis([-1 1]);
            colorbar;
            axis image;
            box off;
            title('A + J');
            
            subplot(3,4,7);
            t_covmat = inv(squeeze(obj.fpva.posvelacc_jac));
            covmat_diag = sqrt(diag(t_covmat));
            posvelacc_covmat = zeros(size(t_covmat));
            for i=1:size(t_covmat,1),
                for j=1:size(t_covmat,2),
                    posvelacc_covmat(i,j) = t_covmat(i,j)/(covmat_diag(i)*covmat_diag(j));
                end
            end
            imagesc(posvelacc_covmat);
            caxis([-1 1]);
            colorbar;
            axis image;
            box off;
            title('P + V + A');
            
            subplot(3,4,8);
            t_covmat = inv(squeeze(obj.fpaj.posaccjer_jac));
            covmat_diag = sqrt(diag(t_covmat));
            posaccjer_covmat = zeros(size(t_covmat));
            for i=1:size(t_covmat,1),
                for j=1:size(t_covmat,2),
                    posaccjer_covmat(i,j) = t_covmat(i,j)/(covmat_diag(i)*covmat_diag(j));
                end
            end
            imagesc(posaccjer_covmat);         
            colorbar;
            caxis([-1 1]);
            axis image;
            box off;
            title('P + A + J');           
            
            bic_val = obj.BIC();
            s = 0.1*max(bic_val);
            [~, min_bic] = min(bic_val);
            subplot(3,4,10);
            barh([pos, v, a, j, va, aj, pva, paj]);
            hold on;
            plot(bic_val(min_bic)+s, min_bic, 'b*');
            plot( bic_val(obj.p.model_type+1)+s, obj.p.model_type+1, 'g+');
            hold off;
            axis tight;
            box off;
            set(gca,'YTickLabel',{'P','V','A','J', ...
                                  'V+A','A+J','P+V+A','P+A+J'});
            ylabel('Models');
            xlabel('BIC');
            title(trial_name);
            
            n_pos_rss = obj.fp.rand_rss - min(obj.fp.rand_rss);
            %n_pos_rss = n_pos_rss/max(n_pos_rss);
            n_vel_rss = obj.fv.rand_rss - min(obj.fv.rand_rss);
            %n_vel_rss = n_vel_rss/max(n_vel_rss);
            
            n_acc_rss = obj.fa.rand_rss - min(obj.fa.rand_rss);
            %n_acc_rss = n_acc_rss/max(n_acc_rss);
            n_jer_rss = obj.fj.rand_rss - min(obj.fj.rand_rss);
            %n_jer_rss = n_jer_rss/max(n_jer_rss);
                     
            n_velacc_rss = obj.fva.rand_rss - min(obj.fva.rand_rss);
            %n_velacc_rss = n_velacc_rss/max(n_velacc_rss);
            n_accjer_rss = obj.faj.rand_rss - min(obj.faj.rand_rss);
            %n_accjer_rss = n_accjer_rss/max(n_accjer_rss);

            n_posaccjer_rss = obj.fpaj.rand_rss - min(obj.fpaj.rand_rss);
            %n_posaccjer_rss = n_posaccjer_rss/max(n_posaccjer_rss);
            n_posvelacc_rss = obj.fpva.rand_rss - min(obj.fpva.rand_rss);
            %n_posvelacc_rss = n_posvelacc_rss/max(n_posvelacc_rss);

            subplot(3,4,11);
            plot(sort(n_pos_rss), 'k');
            hold on;
            plot(sort(n_vel_rss), 'g');           
            plot(sort(n_acc_rss), 'b');
            plot(sort(n_jer_rss), 'm');
            hold off;
            xlabel('Trial');
            ylabel('RSS Error');
            axis tight;
            box off;
            
            legend('P','V','A','J','Location','NorthOutside');
            
            subplot(3,4,12);
            plot(sort(n_velacc_rss), 'k');
            hold on;
            plot(sort(n_accjer_rss), 'g');           
            plot(sort(n_posaccjer_rss), 'b');
            plot(sort(n_posvelacc_rss), 'm');
            hold off;
            xlabel('Trial');
            ylabel('RSS Error');
            axis tight;
            box off;
            
            legend('V+A','A+J','P+A+J','P+V+A','Location','NorthOutside');
            
            disp(nargin);
            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
           
        function plotPosVelAccJerPSTH(obj)
            st_data = [obj.p.u_ele; obj.p.u_azi; obj.p.time'];           
            dim = [length(obj.p.u_azi),length(obj.p.u_ele), length(obj.p.time)];
            
            pos_fit = vel_model(obj.fp.pos_param, st_data);
            pos_fit = unpackPSTH(pos_fit, dim);
            
            vel_fit = vel_model(obj.fv.vel_param, st_data);
            vel_fit = unpackPSTH(vel_fit, dim);
            
            acc_fit = acc_model(obj.fa.acc_param, st_data);
            acc_fit = unpackPSTH(acc_fit, dim);
            
            jer_fit = jer_model(obj.fj.jer_param, st_data);
            jer_fit = unpackPSTH(jer_fit, dim);
            
            max_spikes = max(obj.p.psth(:));
            min_spikes = min(obj.p.psth(:));

            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz);
            for j=1:length(obj.p.u_ele),
                for i=1:length(obj.p.u_azi),
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.p.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.p.u_ele), length(obj.p.u_azi), ...
                           (length(obj.p.u_ele)-j)*length(obj.p.u_azi) + i);
                    plot(obj.p.time, squeeze(obj.p.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.p.time, squeeze(pos_fit(i,j,:)), 'k');
                    plot(obj.p.time, squeeze(vel_fit(i,j,:)), 'm');
                    plot(obj.p.time, squeeze(acc_fit(i,j,:)), 'b');
                    plot(obj.p.time, squeeze(jer_fit(i,j,:)), 'b');
                    hold off;
                    axis tight;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.p.u_ele(j)) ', ' num2str(obj.p.u_azi(i)) ']']);
                end
            end

            n_vel_rss = obj.fv.rand_rss - min(obj.fv.rand_rss);
            n_vel_rss = n_vel_rss/max(n_vel_rss);
            n_acc_rss = obj.fa.rand_rss - min(obj.fa.rand_rss);
            n_acc_rss = n_acc_rss/max(n_acc_rss);
            n_velacc_rss = obj.fva.rand_rss - min(obj.fva.rand_rss);
            n_velacc_rss = n_velacc_rss/max(n_velacc_rss);

            offset = length(obj.p.u_ele)*(length(obj.p.u_azi));
            subplot(length(obj.p.u_ele), length(obj.p.u_azi), [-1 0] + offset);
            plot(sort(n_velacc_rss), 'b');
            hold on;
            plot(sort(n_vel_rss), 'm');
            plot(sort(n_acc_rss), 'g');
            hold off;
            xlabel('Trial');
            ylabel('RSS Error');
            axis tight;
            box off;     
            
            if nargin == 3,
                text_size = 6;
            else
                text_size = 10;
            end
            
            offset = (length(obj.p.u_ele)-1)*(length(obj.p.u_azi));
            subplot(length(obj.p.u_ele), length(obj.p.u_azi), offset+[2 length(obj.p.u_azi)-2]);
            axis off;
            
            rss_text = sprintf('RSS &%.2e &%.2e &%.2e' , ...
                      [obj.fv.vel_rss, obj.fa.acc_rss, obj.fva.velacc_rss]); 
            [v, a, va] = obj.R2();
            r2_text = sprintf('$R^2$ &%3.2f &%3.2f &%3.2f' , ...
                      [v, a, va]);
            [v, a, va] = obj.AIC();
            aic_text = sprintf('AIC &%.2e &%.2e &%.2e' , ...
                      [v, a, va]);
            [v, a, va] = obj.BIC();
            bic_text = sprintf('BIC &%.2e &%.2e &%.2e' , ...
                      [v, a, va]);
          
            tabstring = ...
            ['\begin{tabular}{l r r r}', ...
             'Model &Vel only &Acc only & Vel + Acc\\', ...
             '\hline ', ...
             rss_text, '\\', r2_text, '\\', aic_text, '\\', bic_text, '\\', ...
             '\end{tabular}'];
         
            text(0, 0.5, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size);
        end
         
        function plotVAJCompPSTH(obj, trial_name)
            st_data = [obj.p.u_ele; obj.p.u_azi; obj.p.time'];           
            dim = [length(obj.p.u_azi),length(obj.p.u_ele), length(obj.p.time)];
            
            const = obj.fvaj.velaccjer_param(2);
            
            w_v = obj.fvaj.velaccjer_param(17);
            vel_fit = vel_model(obj.fvaj.velaccjer_param(1:8), st_data);
            vel_fit = w_v*(unpackPSTH(vel_fit, dim) - const);
            
            w_a = obj.fvaj.velaccjer_param(18);
            acc_fit = acc_model([obj.fvaj.velaccjer_param(1:4), ...
                                 obj.fvaj.velaccjer_param(9:12)], ...
                                st_data);
            acc_fit = w_a*(unpackPSTH(acc_fit, dim) - const);
            
            w_j = obj.fvaj.velaccjer_param(19);
            jer_fit = jer_model([obj.fvaj.velaccjer_param(1:4) ...
                                 obj.fvaj.velaccjer_param(13:16)], ...
                                st_data);
            jer_fit = w_j*(unpackPSTH(jer_fit, dim) - const);

            max_spikes = max([vel_fit(:); acc_fit(:); jer_fit(:)]);
            min_spikes = min([vel_fit(:); acc_fit(:); jer_fit(:)]);

            figure;
            for j=1:length(obj.p.u_ele),
                for i=1:length(obj.p.u_azi),
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.p.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.p.u_ele), length(obj.p.u_azi), ...
                           (length(obj.p.u_ele)-j)*length(obj.p.u_azi) + i); 
                    plot(obj.p.time, squeeze(vel_fit(i,j,:)), 'r');
                    hold on;
                    plot(obj.p.time, squeeze(acc_fit(i,j,:)), 'g');
                    plot(obj.p.time, squeeze(jer_fit(i,j,:)), 'b');
                    hold off;
                    axis tight;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.p.u_ele(j)) ', ' num2str(obj.p.u_azi(i)) ']']);
                end
            end
            
            subplot(length(obj.p.u_ele), length(obj.p.u_azi), [2 length(obj.p.u_azi)]);
            axis off;
            
            tabstring = ['Trial: ' trial_name];
            text_size = 16;
            text(0, 1, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size);
        end
        
        function plotVACompPSTH(obj, trial_name)
            st_data = [obj.p.u_ele; obj.p.u_azi; obj.p.time'];           
            dim = [length(obj.p.u_azi),length(obj.p.u_ele), length(obj.p.time)];
            
            const = obj.fva.velacc_param(2);
            
            w_v = obj.fva.velacc_param(13);
            vel_fit = vel_model(obj.fva.velacc_param(1:8), st_data);
            vel_fit = w_v*(unpackPSTH(vel_fit, dim) - const);
            
            w_a = 1-obj.fva.velacc_param(13);
            acc_fit = acc_model([obj.fva.velacc_param(1:4), ...
                                 obj.fva.velacc_param(9:12)], ...
                                st_data);
            acc_fit = w_a*(unpackPSTH(acc_fit, dim) - const);

            max_spikes = max([vel_fit(:); acc_fit(:)]);
            min_spikes = min([vel_fit(:); acc_fit(:)]);

            figure;
            for j=1:length(obj.p.u_ele),
                for i=1:length(obj.p.u_azi),
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.p.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.p.u_ele), length(obj.p.u_azi), ...
                           (length(obj.p.u_ele)-j)*length(obj.p.u_azi) + i); 
                    plot(obj.p.time, squeeze(vel_fit(i,j,:)), 'r');
                    hold on;
                    plot(obj.p.time, squeeze(acc_fit(i,j,:)), 'g');
                    hold off;
                    axis tight;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.p.u_ele(j)) ', ' num2str(obj.p.u_azi(i)) ']']);
                end
            end
            
            subplot(length(obj.p.u_ele), length(obj.p.u_azi), [2 length(obj.p.u_azi)]);
            axis off;
            
            tabstring = ['Trial: ' trial_name];
            text_size = 16;
            text(0, 1, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size);
        end
        
        function plotAJCompPSTH(obj, trial_name)
            st_data = [obj.p.u_ele; obj.p.u_azi; obj.p.time'];           
            dim = [length(obj.p.u_azi),length(obj.p.u_ele), length(obj.p.time)];
            
            const = obj.faj.accjer_param(2);
            
            w_a = obj.faj.accjer_param(13);
            vel_fit = vel_model(obj.faj.velacc_param(1:8), st_data);
            vel_fit = w_v*(unpackPSTH(vel_fit, dim) - const);
            
            w_a = 1-obj.fva.velacc_param(13);
            acc_fit = acc_model([obj.fva.velacc_param(1:4), ...
                                 obj.fva.velacc_param(9:12)], ...
                                st_data);
            acc_fit = w_a*(unpackPSTH(acc_fit, dim) - const);

            max_spikes = max([vel_fit(:); acc_fit(:)]);
            min_spikes = min([vel_fit(:); acc_fit(:)]);

            figure;
            for j=1:length(obj.p.u_ele),
                for i=1:length(obj.p.u_azi),
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.p.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.p.u_ele), length(obj.p.u_azi), ...
                           (length(obj.p.u_ele)-j)*length(obj.p.u_azi) + i); 
                    plot(obj.p.time, squeeze(vel_fit(i,j,:)), 'r');
                    hold on;
                    plot(obj.p.time, squeeze(acc_fit(i,j,:)), 'g');
                    hold off;
                    axis tight;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.p.u_ele(j)) ', ' num2str(obj.p.u_azi(i)) ']']);
                end
            end
            
            subplot(length(obj.p.u_ele), length(obj.p.u_azi), [2 length(obj.p.u_azi)]);
            axis off;
            
            tabstring = ['Trial: ' trial_name];
            text_size = 8;
            text(0, 1, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size);
        end
        
        function plotExtremaErr(obj, trial_name)
            time_profile = d_gauss(obj.fva.velacc_param(3:4), obj.p.time);
            [~, t_max] = max(time_profile);
            [~, t_min] = min(time_profile);
            st_data = [obj.p.u_ele; obj.p.u_azi; obj.p.time'];           
            dim = [length(obj.p.u_azi),length(obj.p.u_ele), length(obj.p.time)];
            
            velacc_fit = velacc_model(obj.fva.velacc_param, st_data);
            velacc_fit = unpackPSTH(velacc_fit, dim);
            
            peak_err = obj.p.psth(:,:,t_max) - velacc_fit(:,:,t_max);
            trough_err = obj.p.psth(:,:,t_min) - velacc_fit(:,:,t_min);

            st_data = [obj.p.u_ele; obj.p.u_azi; obj.p.time'];
            velacc_fit = velacc_model(obj.fva.velacc_param, st_data);
            packedPSTH = packPSTH(obj.p.psth);
            
            res = packedPSTH - velacc_fit;
            
            figure;
            [n ,bins] = hist(res, 20);
            bar(bins, n);
            title(trial_name);
            hold on;
            n = hist([peak_err(:) trough_err(:)], bins);
            bar(bins, n, 'r');
            hold off;
        end
        
        function plotModelAccComp(obj, trial_name)
            st_data = [obj.p.u_ele; obj.p.u_azi; obj.p.time'];           
            dim = [length(obj.p.u_azi),length(obj.p.u_ele), length(obj.p.time)];
            
            param = [obj.fva.velacc_param(1:4) obj.fva.velacc_param(9:12)];
            va_param = obj.fva.velacc_param;
            va_param(13) = 0;
            velacc_fit = velacc_model(va_param, st_data);
            velacc_fit = reshape(velacc_fit, dim);
            
            max_spikes = max(obj.p.psth(:));
            min_spikes = min(obj.p.psth(:));

            figure;
            for j=1:length(obj.p.u_ele),
                for i=1:length(obj.p.u_azi),
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.p.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.p.u_ele), length(obj.p.u_azi), ...
                           (length(obj.p.u_ele)-j)*length(obj.p.u_azi) + i);
                    plot(obj.p.time, squeeze(obj.p.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.p.time, squeeze(obj.fa.acc_fit(i,j,:)), 'g');
                    plot(obj.p.time, squeeze(velacc_fit(i,j,:)), 'b');
                    hold off;
                    axis tight;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.p.u_ele(j)) ', ' num2str(obj.p.u_azi(i)) ']']);
                end
            end
            
            [x,y,z] = sph2cart(param(6), param(8), 1);
            [param(8), param(6), ~] = cart2sph(-x, -y, -z);
            if param(8) < 0,
                param(8) = 2*pi+param(8);
            end
            param([6,8]) = param([6,8])*180/pi;
            
            acc_param = obj.fa.acc_param;
            [x,y,z] = sph2cart(acc_param(6), acc_param(8), 1);
            [acc_param(8), acc_param(6), ~] = cart2sph(-x, -y, -z);
            if acc_param(8) < 0,
                acc_param(8) = 2*pi+acc_param(8);
            end
            acc_param([6,8]) = acc_param([6,8])*180/pi;
            
            subplot(length(obj.p.u_ele), length(obj.p.u_azi), [2 length(obj.p.u_azi)]);
            axis off;
            
            text_size = 18;
            tabstring = ['Trial: ' trial_name];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size);
            acc_text = sprintf(['Acc only &%3.2f &%3.2f &%3.2f ', ...
                                '&%3.2f &%3.2f &%3.2f &%3.2f &%3.2f'], acc_param);
            velacc_text = sprintf(['Vel + Acc &%3.2f &%3.2f &%3.2f ', ...
                                '&%3.2f &%3.2f &%3.2f &%3.2f &%3.2f'], param);
            tabstring = ...
            ['\begin{tabular}{l r r r r r r r r r r r r r}', ...
             'Parameters &$A$ &$R_0$ &$\mu_t$ &$\sigma_t$ ', ...
             '&$m_a$ &$\phi_a$ &$n_a$ &$\theta_a$\\', ...
             ' \hline ', ...
             acc_text, '\\', velacc_text, '\\', ...
             '\end{tabular}'];   

            text(0, 0.5, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size);
            
            offset = (length(obj.p.u_ele)-1)*(length(obj.p.u_azi));
            subplot(length(obj.p.u_ele), length(obj.p.u_azi), offset+[2 length(obj.p.u_azi)-2]);
            axis off;
            
            velacc_rss = sum((obj.p.psth(:) - velacc_fit(:)).^2);
            
            tss = sum((obj.p.psth(:)-mean(obj.p.psth(:))).^2);
            r2 = 1 - velacc_rss/tss;
            
            n = numel(obj.p.psth);
            aic = n*log(velacc_rss/n) + 2*length(param);
            
            rss_text = sprintf('RSS &%3.2f &%3.2f &%3.2f' , ...
                      [obj.fa.acc_rss, velacc_rss]);    
            r2_text = sprintf('$R^2$ &%3.2f &%3.2f &%3.2f' , ...
                      [obj.fa.R2(), r2]);
            aic_text = sprintf('AIC &%3.2f &%3.2f &%3.2f' , ...
                      [obj.fa.AIC(), aic]);
            tabstring = ...
            ['\begin{tabular}{l r r r}', ...
             'Model &Acc only & Vel + Acc\\', ...
             '\hline ', ...
             rss_text, '\\', r2_text, '\\', aic_text, '\\', ...
             '\end{tabular}'];
         
            text(0, 0.5, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', text_size);
        end

        function qqplots(obj)
            st_data = [obj.p.u_ele; obj.p.u_azi; obj.p.time'];
            vel_fit = vel_model(obj.fv.vel_param, st_data);        
            acc_fit = acc_model(obj.fa.acc_param, st_data);
            velacc_fit = velacc_model(obj.fva.velacc_param, st_data);
            
            vel_err = obj.p.psth(:) - vel_fit;
            acc_err = obj.p.psth(:) - acc_fit;
            velacc_err = obj.p.psth(:) - velacc_fit;
            
            figure('renderer','painters');
            subplot(2,2,1);
            qqplot(vel_err);
            title('QQ-Plot of Velocity Only Model');
            axis tight;
            subplot(2,2,2);
            qqplot(acc_err);
            title('QQ-Plot of Acceleration Only Model');
            subplot(2,2,3);
            qqplot(velacc_err);
            title('QQ-Plot of Velocity + Acceleration Model');
            subplot(2,2,4);
            axis off;
            
            [F_val, p_val] = obj.vel_F_test();
            vel_text = sprintf('Velocity &%3.2f &%3.2f' , ...
                      [F_val, p_val]);  
            [F_val, p_val] = obj.vel_F_test();
            acc_text = sprintf('Acceleration &%3.2f &%3.2f' , ...
                      [F_val, p_val]);
            tabstring = ...
            ['\begin{tabular}{l r r}', ...
             'Model &F test &$p$ value\\', ...
             '\hline ', ...
             vel_text, '\\', acc_text, '\\', ...
             '\end{tabular}'];
         
            text(0, 0.5, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', 12); 
        end
        
        function r = BIC(obj)
            n = length(packPSTH(obj.p.psth));

            v = n*log(obj.fv.vel_rss/n) + 2*length(obj.fv.vel_param)*log(n);
            a = n*log(obj.fa.acc_rss/n) + 2*length(obj.fa.acc_param)*log(n);
            j = n*log(obj.fj.jer_rss/n) + 2*length(obj.fj.jer_param)*log(n);
            
            va = n*log(obj.fva.velacc_rss/n) + 2*length(obj.fva.velacc_param)*log(n);
            vj = n*log(obj.fvj.veljer_rss/n) + 2*length(obj.fvj.veljer_param)*log(n);
            aj = n*log(obj.faj.accjer_rss/n) + 2*length(obj.faj.accjer_param)*log(n);

            vaj = n*log(obj.fvaj.velaccjer_rss/n) + 2*length(obj.fvaj.velaccjer_param)*log(n);

%             po = n*log(obj.fp.pos_rss/n) + 2*length(obj.fp.pos_param)*log(n);
%             pva = n*log(obj.fpva.posvelacc_rss/n) + 2*length(obj.fpva.posvelacc_param)*log(n);
%             pvj = n*log(obj.fpvj.posveljer_rss/n) + 2*length(obj.fpvj.posveljer_param)*log(n);
%             paj = n*log(obj.fpaj.posaccjer_rss/n) + 2*length(obj.fpaj.posaccjer_param)*log(n);
            
            r = [v a j va vj aj vaj]; % po pva pvj paj];
        end
        
        function r = AIC(obj)
            n = length(packPSTH(obj.p.psth));
            
            pos = n*log(obj.fp.pos_rss/n) + 2*(length(obj.fp.pos_param)+1);
            v = n*log(obj.fv.vel_rss/n) + 2*(length(obj.fv.vel_param)+1);
            a = n*log(obj.fa.acc_rss/n) + 2*(length(obj.fa.acc_param)+1);
            j = n*log(obj.fj.jer_rss/n) + 2*(length(obj.fj.jer_param)+1);
            
            va = n*log(obj.fva.velacc_rss/n) + 2*(length(obj.fva.velacc_param)+1);
            aj = n*log(obj.faj.accjer_rss/n) + 2*(length(obj.faj.accjer_param)+1);
            
            pva = n*log(obj.fpva.posvelacc_rss/n) + 2*(length(obj.fpva.posvelacc_param)+1);
            paj = n*log(obj.fpaj.posaccjer_rss/n) + 2*(length(obj.fpaj.posaccjer_param)+1);
            
            r = [pos v a j va aj pva paj];
        end
        
        function r = R2(obj)
            psth = packPSTH(obj.p.psth);
            tss = sum((psth(:)-mean(psth(:))).^2);
            
            v = 1 - obj.fv.vel_rss/tss;
            a = 1 - obj.fa.acc_rss/tss;
            j = 1 - obj.fj.jer_rss/tss;
            
            va = 1 - obj.fva.velacc_rss/tss;
            vj = 1 - obj.fvj.veljer_rss/tss; 
            aj = 1 - obj.faj.accjer_rss/tss;
            
            vaj = 1 - obj.fvaj.velaccjer_rss/tss;

            
%             po = 1 - obj.fp.pos_rss/tss;
%             pva = 1 - obj.fpva.posvelacc_rss/tss;
%             pvj = 1 - obj.fpvj.posveljer_rss/tss;
%             paj = 1 - obj.fpaj.posaccjer_rss/tss;
            
            r = [v a j va vj aj vaj]; % po pva pvj paj];
        end
    end
end
