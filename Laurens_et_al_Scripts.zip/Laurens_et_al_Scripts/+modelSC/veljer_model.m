function r = veljer_model(param, coord)
    u_ele = coord(1:5);
    u_azi = coord(6:14);
    time = coord(15:end);

    %velocity model
    gauss_time = gauss([param(3) param(4)], time);
    v_ele_azi = cos_tuning(param(5:7), [u_ele; u_azi]) + param(8);
    v_ele_azi = reshape(v_ele_azi, length(u_azi), length(u_ele));

    %jerk model
    d2_gauss_time = d2_gauss([param(3) param(4)], time);
    j_ele_azi = cos_tuning(param(9:11), [u_ele; u_azi]) + param(12);
    j_ele_azi = reshape(j_ele_azi, length(u_azi), length(u_ele));
    
    %compute results
    r = zeros(size(v_ele_azi,1), size(v_ele_azi,2), length(gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            r(i,j,:) = param(1)* ...
                       (param(13)*v_ele_azi(i,j)*gauss_time + ...
                       (1-param(13))*j_ele_azi(i,j)*d2_gauss_time) + ...
                       param(2);
        end
    end

    r = packPSTH(r);
end