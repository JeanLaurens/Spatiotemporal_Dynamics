function r = posvelacc_model(param, coord)
    u_ele = coord(1:5);
    u_azi = coord(6:14);
    time = coord(15:end);
    
    stim_sig = sqrt(sqrt(2))/6;
    
    %velocity model
    i_gauss_time = i_gauss([param(3) stim_sig], time);
    p_ele_azi = cos_tuning(param(5:7), [u_ele; u_azi]) + param(8);
    p_ele_azi = reshape(p_ele_azi, length(u_azi), length(u_ele));

    %acceleration model
    gauss_time = gauss([param(3) stim_sig], time);
    v_ele_azi = cos_tuning(param(9:11), [u_ele; u_azi]) + param(12);
    v_ele_azi = reshape(v_ele_azi, length(u_azi), length(u_ele));
    
    %jerk model
    d_gauss_time = d_gauss_n(param(3:4), time);
    a_ele_azi = cos_tuning(param(13:15), [u_ele; u_azi]) + param(16);
    a_ele_azi = reshape(a_ele_azi, length(u_azi), length(u_ele));
    
    %compute results
    r = zeros(size(v_ele_azi,1), size(v_ele_azi,2), length(gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            r(i,j,:) = param(1)*( ...
                         (1-param(18))*( ...
                           param(17)*p_ele_azi(i,j)*i_gauss_time + ...
                           (1-param(17))*v_ele_azi(i,j)*gauss_time) + ...
                         param(18)*a_ele_azi(i,j)*d_gauss_time) + ...
                       param(2);
        end
    end

    r = packPSTH(r);
end