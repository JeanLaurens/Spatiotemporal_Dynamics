clear;





addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\Toolbox']));
addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\htb']));
addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\misc']));
%addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\modelS2H']));
addpath('Z:\Users\sheng\MATLAB_R\MATLAB\vestibular_analysis\1modelSC_NS\')
addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\psth']));
addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\selection']));
ProtocolDefs;
brain_area = 'PPN';
brain_area = 'MSTd';
% brain_area = 'VIP';
% brain_area = 'PIVC';
brain_area = 'VPS';
% brain_area = 'FEF';



TIMEPATH = (['D:\work\Fitting\']);
[batchfilePath, fileName, spikechan] = textread(['D:\work\Fitting\'  'batch_VPS_Translation.m'], '%s%s%s%*[^\n]');
% [batchfilePath, fileName, spikechan] = textread(['D:\work\'  'FEFp.m'], '%s%s%s%*[^\n]');

addpath('D:\PPN');
for i= 1 : length(fileName)
 
   cur_path_name = strtrim(char(batchfilePath(i)) );
   cur_file_name = strtrim(char(fileName(i)) );
   [~, data, ~, ~] = LoadTEMPOData3(cur_path_name, cur_file_name);
   temp_stim_type = data.moog_params(STIM_TYPE,:,MOOG);
   index = find(temp_stim_type == 1);
   clear data1;
   data1 = data;
   data1.eye_data =  data.eye_data(:, :,  index);
   data1.spike_data =  data.spike_data(:, :,  index);
   data1.event_data =  data.event_data(:, :,  index);
   data1.moog_params =  data.moog_params(:, index, :);
   if ~exist(['D:\work_3d\PSTH' filesep 'psth_' brain_area ]) 
       mkdir(['D:\work_3d\PSTH' filesep 'psth_' brain_area ])
   end
   try,
   p = PSTH('sheng', 1.106, data1, str2num(strtrim(char(spikechan(i)))) );
    if ~p.rej,
%          save(['D:\missing\'  cur_file_name(1:end-4)  '_1' ], 'p');
          save(['D:\work_3d\PSTH' filesep 'psth_' brain_area filesep cur_file_name(1:end-4)  'C'  strtrim(char(spikechan(i)))], 'p');
    end
    
   catch,
   end
    
%    index = find(temp_stim_type == 2);
%    clear data2;
%    data2 = data;
%    data2.eye_data =  data.eye_data(:, :,  index);
%    data2.spike_data =  data.spike_data(:, :,  index);
%    data2.event_data =  data.event_data(:, :,  index);
%    data2.moog_params =  data.moog_params(:, index, :);
%     p = PSTH('sheng', 1.115, data2, 1);
%     if ~p.rej,
%          save(['D:\vestibular_3d\temp\'  cur_file_name(1:end-4)  '_2' ], 'p');
%     end

end