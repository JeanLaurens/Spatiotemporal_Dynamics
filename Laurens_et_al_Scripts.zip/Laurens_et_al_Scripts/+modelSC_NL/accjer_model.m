function r = accjer_model(param, coord)
    u_ele = coord(1:5);
    u_azi = coord(6:14);
    time = coord(15:end);
    
    %acceleration model
    d_gauss_time = d_gauss_n(param(3:4), time);
    a_ele_azi = cos_tuning(param(5:7), [u_ele; u_azi]) + param(8);
    a_ele_azi = reshape(a_ele_azi, length(u_azi), length(u_ele));

    %jerk model
    d2_gauss_time = d2_gauss_n(param(3:4), time);
    j_ele_azi = cos_tuning(param(9:11), [u_ele; u_azi]) + param(12);
    j_ele_azi = reshape(j_ele_azi, length(u_azi), length(u_ele));
    
    %compute results
    r = zeros(size(a_ele_azi,1), size(a_ele_azi,2), length(d_gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            r(i,j,:) = param(1)* ...
                       (param(13)*a_ele_azi(i,j)*d_gauss_time + ...
                       (1-param(13))*j_ele_azi(i,j)*d2_gauss_time) + ...
                       param(2);
        end
    end

    r = packPSTH(r);
end