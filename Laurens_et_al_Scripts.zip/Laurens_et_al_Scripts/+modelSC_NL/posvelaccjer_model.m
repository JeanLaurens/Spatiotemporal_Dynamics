function r = posvelaccjer_model(param, coord)
    u_ele = coord(1:5);
    u_azi = coord(6:14);
    time = coord(15:end);
    
    %position model
    i_gauss_time = i_gauss_n(param(3:4), time);
    p_ele_azi = cos_tuning(param(5:7), [u_ele; u_azi]) + param(8);
    p_ele_azi = reshape(p_ele_azi, length(u_azi), length(u_ele));

    %velocity model
    gauss_time = gauss_n(param(3:4), time);
    v_ele_azi = cos_tuning(param(9:11), [u_ele; u_azi]) + param(12);
    v_ele_azi = reshape(v_ele_azi, length(u_azi), length(u_ele));
    
    %acceleration model
    d_gauss_time = d_gauss_n(param(3:4), time);
    a_ele_azi = cos_tuning(param(13:15), [u_ele; u_azi]) + param(16);
    a_ele_azi = reshape(a_ele_azi, length(u_azi), length(u_ele));
    
    %jerk model
    d2_gauss_time = d2_gauss_n(param(3:4), time);
    j_ele_azi = cos_tuning(param(17:19), [u_ele; u_azi]) + param(20);
    j_ele_azi = reshape(j_ele_azi, length(u_azi), length(u_ele));
    
    %compute results
    r = zeros(size(v_ele_azi,1), size(v_ele_azi,2), length(gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            r(i,j,:) = param(1)*( ...
                         (1-param(23))*( ...
                           (1-param(22))*( ...
                               param(21)*p_ele_azi(i,j)*i_gauss_time + ...
                               (1-param(21))*v_ele_azi(i,j)*gauss_time) + ...
                           param(22)*a_ele_azi(i,j)*d_gauss_time) + ...
                         param(23)*j_ele_azi(i,j)*d2_gauss_time) + ...
                       param(2);
        end
    end

    r = packPSTH(r);
end