PATH = (['..' filesep '..' filesep 'Data' filesep 'Xiongjie' filesep 'm18c503r1' filesep]);

DIR = dir([PATH '*.htb']);
FILE = DIR(1).name;

[~, data, ~, ~] = LoadTEMPOData2(PATH,FILE);

PATH = ['..' filesep '..' filesep 'Data' filesep 'Seng' filesep];

DIR = dir([PATH '*.htb']);
FILE = DIR(3).name;

[~, data, ~, ~] = LoadTEMPOData(PATH,FILE);

%following function checks offset times and outputs starting and ending analysis (in spike bins)
num_trials = size(data.event_data, 3);
StartCode = 4;
StopCode = 5;
StartOffsetTime = 0;
StopOffsetTime = 0;
UseSyncPulses = 0;

[StartOffsetBin, StopOffsetBin, ...
 StartEventBin, StopEventBin] = CheckTimeOffset(data, num_trials, ...
                                                StartCode, StopCode, ...
                                                StartOffsetTime, StopOffsetTime, ...
                                                UseSyncPulses);
data.UseSyncPulses=UseSyncPulses;

if (~isempty(data.spike_data))
    %compute the firing rate over all trials during the period between StartCode and StopCode
    data.spike_rates = ComputeSpikeRates(data, num_trials, ...
                                         StartCode, StopCode, ...
                                         StartOffsetBin, StopOffsetBin);
end

disp(size(data.spike_data));
disp(size(data.moog_params));

return;
Protocol = 100;
BegTrial = 1;
EndTrial =  num_trials;
SpikeChan = 1;
CurveFitting_3Plane_Sti_Astart(data, SpikeChan, BegTrial, EndTrial, ...
                               StartEventBin, StopEventBin, FILE, ...
                               Protocol);