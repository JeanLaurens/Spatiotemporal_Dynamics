function r = velaccjer_model(param, coord)
    u_ele = coord(1:5);
    u_azi = coord(6:14);
    time = coord(15:end);
    
    %velocity model
    gauss_time = gauss(param(3:4), time);
    v_ele_azi = cos_tuning3(param(5:7), [u_ele; u_azi]);
    v_ele_azi = reshape(v_ele_azi, length(u_azi), length(u_ele));

    %acceleration model
    d_gauss_time = d_gauss(param(3:4), time);
    a_ele_azi = cos_tuning3(param(8:10), [u_ele; u_azi]);
    a_ele_azi = reshape(a_ele_azi, length(u_azi), length(u_ele));
    
    %jerk model
    d2_gauss_time = d2_gauss(param(3:4), time);
    j_ele_azi = cos_tuning3(param(11:13), [u_ele; u_azi]);
    j_ele_azi = reshape(j_ele_azi, length(u_azi), length(u_ele));
    
    %compute results
    r = zeros(size(v_ele_azi,1), size(v_ele_azi,2), length(gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            r(i,j,:) = param(1)*( ...
                         (1-param(15))*( ...
                           param(14)*v_ele_azi(i,j)*gauss_time + ...
                           (1-param(14))*a_ele_azi(i,j)*d_gauss_time) + ...
                         param(15)*j_ele_azi(i,j)*d2_gauss_time) + ...
                       param(2);
        end
    end

    r = packPSTH(r);
end