clear;

addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\Toolbox']));
addpath(genpath('Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\selection'));
addpath(genpath('Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\psth'));
addpath(genpath('Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\misc'));
addpath(genpath('Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\htb'));
addpath(genpath('Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\ModeTest'));
% addpath(genpath('modelSC_NS'));
addpath('Z:\Users\sheng\MATLAB_R\MATLAB\vestibular_analysis\1modelSC_NS\')

brain_area = 'OA';   % i = 25;
brain_area = 'VN';  %  i =  m23c434r1c1

PATH = ['D:\work\Fitting' filesep  'NS_SC_' brain_area '_Data' filesep];

data_dir = dir([PATH '*.mat']);
stim_sig = sqrt(sqrt(2))/6;


for i = 1: 100
    disp(data_dir(i).name);
    d = load([PATH data_dir(i).name]);
    sm7 = selModel_t(d.p, d.fv, d.fa, d.fj, ...
                     d.fva, d.fvj, d.faj, d.fvaj);
    


    sm7.plotPSTH(i, data_dir(i).name, 'd:\work\'); 

end

%% VN  
brain_area = 'VN';
PATH = ['D:\work_3d\Fitting' filesep  'NS_SC_' brain_area '_Data' filesep];
% example =  'm23c434r1C1.mat'; old
example =  'm24c348r5C3.mat'; % i  36
d = load([PATH example]);
%     sm7 = selModel_t(d.p, d.fv, d.fa, d.fj, ...
%                      d.fva, d.fvj, d.faj, d.fvaj);% old way
%  sm7 = selModel2(d.p, d.fv, d.fa, d.fj, d.fva, d.fvj, d.faj, d.fvaj);
    
 sm7 = selModel_t(d.p, d.fv, d.fa, d.fj, ...
                     d.fva, d.fvj, d.faj, d.fvaj);
 % selModel_t in Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis   

 sm7.plotPSTH(i, data_dir(i).name, PATH ); 
 
 %VN
 sm7.plotPSTH4(i, example, 'd:\work\');  
 
 % afferent
 sm7.plotPSTH5(i, example, 'd:\work\'); 

%% MSTd

brain_areas = {'CN',  'VIP',  'PIVC',  'VPS',  'FEF', 'MStd', 'OA', 'VN' }
for iii = 8:8% length(brain_areas)

    brain_area = brain_areas{iii};  %  i =  m23c434r1c1

m_PATH = ['D:\work\Fitting_wrong' filesep  'NS_SC_' brain_area '_Data' filesep];
m_PATH = ['D:\work_3d\Fitting' filesep  'NS_SC_' brain_area '_Data' filesep];

data_dir = dir([m_PATH '*.mat']);
stim_sig = sqrt(sqrt(2))/6;

m_path1 =  ['D:\work_3d\Fitting\' ];
% if ~exist(m_path)
%     mkdir(m_path);
% end

for i = 1: length(data_dir)
    disp(data_dir(i).name);
%     m_PATH = ['Z:\Users\Raymond\rchan\Documents\Paper_Output\NS_SC_OA_Data\']
    d = load([m_PATH data_dir(i).name]);
    sm7 = selModel_t(d.p, d.fv, d.fa, d.fj, ...
                     d.fva, d.fvj, d.faj, d.fvaj);
    sm7.plotPSTH6(i, data_dir(i).name, m_path1, brain_area); 

end
end
% 
% new model

brain_areas = {'CN',  'VIP',  'PIVC',  'VPS',  'FEF', 'MStd', 'OA', 'VN' }
for iii = 1:8% length(brain_areas)

    brain_area = brain_areas{iii};  %  i =  m23c434r1c1

m_PATH = ['D:\work\Fitting_wrong' filesep  'NS_SC_' brain_area '_Data' filesep];
m_PATH = ['D:\work_3d\Fitting3' filesep  'NS_SC_' brain_area '_Data' filesep];

data_dir = dir([m_PATH '*.mat']);
stim_sig = sqrt(sqrt(2))/6;

m_path1 =  ['D:\work_3d\Fitting3\' ];
% if ~exist(m_path)
%     mkdir(m_path);
% end

    for i = 1: length(data_dir)
         disp(data_dir(i).name);
%     m_PATH = ['Z:\Users\Raymond\rchan\Documents\Paper_Output\NS_SC_OA_Data\']
         d = load([m_PATH data_dir(i).name]);
%     sm7 = selModel_t(d.p, d.fv,);
        plot_PSTH_new( d,  data_dir(i).name, m_path1, brain_area); 

    end
end
% end