clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));

PATH = (['..' filesep '..' filesep 'Output' filesep 'DC_Output_Sheng' filesep]);
dc_psm = poolModelClass(PATH);

PATH = (['..' filesep '..' filesep 'Output' filesep 'SC2_Output_Sheng' filesep]);
sc_psm = poolModelClass(PATH);

PATH = (['..' filesep '..' filesep 'Output' filesep 'CTDC_Output_Sheng' filesep]);
ctdc_psm = poolModelClass(PATH);

PATH = (['..' filesep '..' filesep 'Output' filesep 'ITSC_Output_Sheng' filesep]);
itsc_psm = poolModelClass(PATH);


dc_sc_dif = dc_psm.pool_r2 - sc_psm.pool_r2;
sc_itsc_dif = sc_psm.pool_r2 - itsc_psm.pool_r2;
ctdc_sc_dif = ctdc_psm.pool_r2 - sc_psm.pool_r2;
dc_itsc_dif = dc_psm.pool_r2 - itsc_psm.pool_r2;
dc_ctdc_dif = dc_psm.pool_r2 - ctdc_psm.pool_r2;
ctdc_itsc_dif = ctdc_psm.pool_r2 - itsc_psm.pool_r2;

bic_max = 0.5;        
bic_min = -0.5; 

lpos_text = bic_min + (bic_max-bic_min)/8;
rpos_text = bic_max - (bic_max-bic_min)/8;  

scrsz = get(0,'ScreenSize');
figure('Position', scrsz, 'Renderer', 'painters');
subplot(2,3,1);
hist(dc_sc_dif, 10);
h = findobj(gca,'Type','patch');
set(h,'FaceColor', 'y');
xlim([bic_min bic_max]);
box off;
line([0 0], ylim, 'Color', 'k');
q = quantile(dc_sc_dif, 3);
line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line(q(2)*[1 1], ylim, 'Color', 'r');
line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line((q(3) + 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
line((q(1) - 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
yl = ylim;
ypos = yl(2);
text(lpos_text, ypos, 'Choose SC');
text(rpos_text, ypos, 'Choose DC', 'HorizontalAlignment', 'right');
title('DC - SC');
xlabel('R^2 Diff.');
ylabel('Count');

subplot(2,3,2);
hist(sc_itsc_dif, 10);
h = findobj(gca,'Type','patch');
set(h,'FaceColor', 'y');
xlim([bic_min bic_max]);
box off;
line([0 0], ylim, 'Color', 'k');
q = quantile(sc_itsc_dif, 3);
line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line(q(2)*[1 1], ylim, 'Color', 'r');
line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line((q(3) + 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
line((q(1) - 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
yl = ylim;
ypos = yl(2);
text(lpos_text, ypos, 'Choose ITSC');
text(rpos_text, ypos, 'Choose SC', 'HorizontalAlignment', 'right');
title('SC - ITSC');
xlabel('R^2 Diff.');
ylabel('Count');


subplot(2,3,3);
hist(ctdc_sc_dif, 10);
h = findobj(gca,'Type','patch');
set(h,'FaceColor', 'y');
xlim([bic_min bic_max]);
box off;
line([0 0], ylim, 'Color', 'k');
q = quantile(ctdc_sc_dif, 3);
line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line(q(2)*[1 1], ylim, 'Color', 'r');
line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line((q(3) + 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
line((q(1) - 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
yl = ylim;
ypos = yl(2);
text(lpos_text, ypos, 'Choose SC');
text(rpos_text, ypos, 'Choose CTDC', 'HorizontalAlignment', 'right');
title('CTDC - SC');
xlabel('R^2 Diff.');
ylabel('Count');

subplot(2,3,4);
hist(dc_itsc_dif, 10);
h = findobj(gca,'Type','patch');
set(h,'FaceColor', 'y');
xlim([bic_min bic_max]);
box off;
line([0 0], ylim, 'Color', 'k');
q = quantile(dc_itsc_dif, 3);
line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line(q(2)*[1 1], ylim, 'Color', 'r');
line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line((q(3) + 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
line((q(1) - 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
yl = ylim;
ypos = yl(2);
text(lpos_text, ypos, 'Choose ITSC');
text(rpos_text, ypos, 'Choose DC', 'HorizontalAlignment', 'right');
title('DC - ITSC');
xlabel('R^2 Diff.');
ylabel('Count');

subplot(2,3,5);
hist(dc_ctdc_dif, 10);
h = findobj(gca,'Type','patch');
set(h,'FaceColor', 'y');
xlim([bic_min bic_max]);
box off;
line([0 0], ylim, 'Color', 'k');
q = quantile(dc_ctdc_dif, 3);
line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line(q(2)*[1 1], ylim, 'Color', 'r');
line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line((q(3) + 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
line((q(1) - 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
yl = ylim;
ypos = yl(2);
text(lpos_text, ypos, 'Choose CTDC');
text(rpos_text, ypos, 'Choose DC', 'HorizontalAlignment', 'right');
title('DC - CTDC');
xlabel('R^2 Diff.');
ylabel('Count');

sel = (q(3) + 1.5*(q(3)-q(1))) >  dc_ctdc_dif & ...
      (q(1) - 1.5*(q(3)-q(1))) <  dc_ctdc_dif;

subplot(2,3,6);
hist(ctdc_itsc_dif, 10);
h = findobj(gca,'Type','patch');
set(h,'FaceColor', 'y');
xlim([bic_min bic_max]);
box off;
line([0 0], ylim, 'Color', 'k');
q = quantile(ctdc_itsc_dif, 3);
line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line(q(2)*[1 1], ylim, 'Color', 'r');
line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line((q(3) + 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
line((q(1) - 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
yl = ylim;
ypos = yl(2);
text(lpos_text, ypos, 'Choose ITSC');
text(rpos_text, ypos, 'Choose CTDC', 'HorizontalAlignment', 'right');
title('CTDC - ITSC');
xlabel('R^2 Diff.');
ylabel('Count');

scrsz = get(0,'ScreenSize');
figure('Position', scrsz, 'Renderer', 'painters');
subplot(2,3,1);
plot(dc_psm.pool_r2, sc_psm.pool_r2, '*');
box off;
line([0 1], [0 1], 'color', 'k');
text(0.2, 0.8, 'Choose SC');
text(0.8, 0.2, 'Choose DC', 'HorizontalAlignment', 'right');
xlabel('DC R^2');
ylabel('SC R^2');

subplot(2,3,2);
plot(sc_psm.pool_r2, itsc_psm.pool_r2, '*');
box off;
line([0 1], [0 1], 'color', 'k');
text(0.2, 0.8, 'Choose ITSC');
text(0.8, 0.2, 'Choose SC', 'HorizontalAlignment', 'right');
xlabel('SC R^2');
ylabel('ITSC R^2');

subplot(2,3,3);
plot(ctdc_psm.pool_r2, sc_psm.pool_r2, '*');
box off;
line([0 1], [0 1], 'color', 'k');
text(0.2, 0.8, 'Choose SC');
text(0.8, 0.2, 'Choose CTDC', 'HorizontalAlignment', 'right');
xlabel('CTDC R^2');
ylabel('SC R^2');

subplot(2,3,4);
plot(dc_psm.pool_r2, itsc_psm.pool_r2, '*');
box off;
line([0 1], [0 1], 'color', 'k');
text(0.2, 0.8, 'Choose ITSC');
text(0.8, 0.2, 'Choose DC', 'HorizontalAlignment', 'right');
xlabel('DC R^2');
ylabel('ITSC R^2');

subplot(2,3,5);
plot(dc_psm.pool_r2, ctdc_psm.pool_r2, '*');
hold on;
plot(dc_psm.pool_r2(~sel), ctdc_psm.pool_r2(~sel), 'r*');
hold off;
box off;
line([0 1], [0 1], 'color', 'k');
text(0.2, 0.8, 'Choose CTDC');
text(0.8, 0.2, 'Choose DC', 'HorizontalAlignment', 'right');
xlabel('DC R^2');
ylabel('CTDC R^2');

subplot(2,3,6);
plot(ctdc_psm.pool_r2, itsc_psm.pool_r2, '*');
box off;
line([0 1], [0 1], 'color', 'k');
text(0.2, 0.8, 'Choose ITSC');
text(0.8, 0.2, 'Choose CTDC', 'HorizontalAlignment', 'right');
xlabel('CTDC R^2');
ylabel('ITSC R^2');