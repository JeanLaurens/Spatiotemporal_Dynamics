clear;

brain_area = 'OA';

INPUT_PATH = (['..' filesep '..' filesep 'Paper_Output' filesep 'psth_' brain_area '_c'  filesep]);
d_dir = dir([INPUT_PATH '*.mat']);
disp(size(d_dir));

joblist = fopen([brain_area '_joblist.txt'], 'w');

for i=1:length(d_dir),    
    data_file_name = d_dir(i).name;
    data_dir = ['psth_' brain_area '_c'];
    output_dir = ['Output_' brain_area];
    
    disp([num2str(i) ', ' data_file_name]);

    %if ~exist([PATH_OUTPUT data_file_name], 'file'),
    fprintf(joblist, ['null, ', '''%s''', ', ' ...
                      '''%s''', ', ', '''%s''', '\n'], ...
                      data_file_name, data_dir, output_dir);
    %end
end

fclose(joblist);