classdef fitJer
    properties
        reps
        psth

        u_azi
        u_ele
        time
        
        time_profile
      
        baseline
        
        R_0
        
        ele_azi_profile
        space_profile
        mu_t
        sig_t
        
        coeff
        DC

        init_param
       
        jer_param
        rand_param
        
        jer_rss
        rand_rss
        
        jer_jac
        rand_jac
    end
    
    methods
        function obj = fitJer(p, reps)
            obj.reps = reps;
            obj.psth = p.psth;

            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            obj.baseline = p.baseline;

            stim_sig = sqrt(sqrt(2))/6;
            obj.sig_t = stim_sig;

            %Compute Temporal Profiles
            d2_gauss_time = d2_gauss([1 stim_sig], obj.time)';
            [c, lags] = xcorr(d2_gauss_time, p.t_profile1, 'coeff');
            neg_lags_idx = lags < 0;
            neg_lags = lags(neg_lags_idx);
            [~,idx] = max(abs(c(neg_lags_idx)));
            delay_i = neg_lags(idx);
            peak_i = find(obj.time >= 1, 1, 'first')-1;
            
            s = 1;
            if c(idx) < 0,
                s = -1;
            end
            obj.mu_t = obj.time(peak_i - delay_i);
            t_A = (max(p.t_profile1)-min(p.t_profile1))/2;
            obj.time_profile = s*p.t_profile1/t_A;
            
            %Compute Spatial Profiles
            cur_profile = p.s_profile1;
            cur_profile(:,1) = cur_profile(1,1);
            cur_profile(:,end) = cur_profile(1,end);
            cur_profile(end,:) = cur_profile(1,:);

            obj.ele_azi_profile = s*t_A*cur_profile;
  
            %Normalise Profiles   
            obj.DC = mean(obj.ele_azi_profile(:)); 
            obj.space_profile = obj.ele_azi_profile - obj.DC;                           
                        
            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);

            %Fit spatial profile
            d_azi = 2*pi/length(obj.u_azi);
            d_ele = pi/length(obj.u_ele);
            obj.coeff = sh_coeff(obj.space_profile, 2, ...
                                 obj.u_azi, obj.u_ele+pi/2, ...
                                 d_azi, d_ele);          
            
           %Fit linear parameters
           obj.R_0 = p.baseline;
            
            %Inital fits
            param = [obj.R_0, ...    %1
                     obj.mu_t, ...   %2
                     obj.sig_t, ...  %3
                     obj.coeff', ... %4-11
                     obj.DC];        %12
                 
            obj.init_param = param;
          
            y_data = packPSTH(obj.psth);
            
            LB = [0, ...               %1    R_0
                  1, ...               %2    mu_t
                  0.5*stim_sig, ...    %3    sig_t
                  -1000*ones(1,8), ... %4-11 coeff
                  -1000]; ...          %12   DC
                  
            UB = [300, ...            %1    R_0
                  1.5, ...            %2    mu_t
                  2*stim_sig, ...     %3    sig_t
                  1000*ones(1,8), ... %4-11 coeff
                  1000];              %12   DC
            
            t_rand_rss = zeros(obj.reps+1,1);
            t_rand_param = zeros(obj.reps+1, length(param));
            t_rand_jac = zeros(obj.reps+1, length(param), length(param));
            
            [t_rand_param(1,:), t_rand_rss(1),~,~,~,~,tmp_jacobian] = ...
            lsqcurvefit('jer_model', obj.init_param, st_data, y_data, LB, UB, options);
            t_rand_jac(1,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);

            %Initial Conditions Random Range
            err_range =  0.1*(UB - LB);
            min_param = t_rand_param(1,:);
            UB_param = min_param+err_range;
            LB_param = min_param-err_range;
            
            for i=2:obj.reps+1,
                %Randomise Initial Conditions
                seed_param  = unifrnd(LB_param, UB_param);
                
                [t_rand_param(i,:), t_rand_rss(i),~,~,~,~,tmp_jacobian] = ...
                 lsqcurvefit('jer_model', seed_param, st_data, y_data, LB, UB, options);
                 t_rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
            end
            
            obj.rand_param = t_rand_param;
            obj.rand_rss = t_rand_rss;
            obj.rand_jac = t_rand_jac;
            
            [~,min_idx] = min(obj.rand_rss);
            obj.jer_param = obj.rand_param(min_idx,:);
            obj.jer_rss = obj.rand_rss(min_idx);
            obj.jer_jac = obj.rand_jac(min_idx,:,:);
        end
        
        function plotPSTH(obj, trial_name, page_num, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            init_fit = jer_model(obj.init_param(1,:), st_data); 
            jer_fit = jer_model(obj.jer_param, st_data);
            
            init_fit = unpackPSTH(init_fit, size(obj.psth));
            jer_fit = unpackPSTH(jer_fit, size(obj.psth));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(init_fit(i,j,:)), 'g');
                    plot(obj.time, squeeze(jer_fit(i,j,:)), 'k');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page_num) ': ' trial_name];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                 'FontName', 'helvetica', 'FontSize', 12);
             
            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end

        function printVal(obj)
            disp('Jerk');
            disp(['A    : ' num2str(obj.jer_param(1))]);
            disp(['R_0  : ' num2str(obj.jer_param(2))]);
            disp(['mu_t : ' num2str(obj.jer_param(3))]);
            disp(['sig_t: ' num2str(obj.jer_param(4))]);
            disp(['a_n  : ' num2str(obj.jer_param(5))]);
            disp(['a_0  : ' num2str(obj.jer_param(6))]);
            disp(['e_n  : ' num2str(obj.jer_param(7))]);
            disp(['e_0  : ' num2str(obj.jer_param(8))]);
            disp(['DC   : ' num2str(obj.jer_param(9))]);
        end
    end
end

function plot_tuning(e0, a0, n, m, DC)
    [x0, y0, z0] = sph2cart(a0, e0, 1);

    tu_azi = 0:0.05*pi:2*pi;
    tu_ele = -pi/2:0.05*pi:pi/2;

    azi = repmat(tu_azi, length(tu_ele), 1);
    ele = repmat(tu_ele', 1, length(tu_azi));

    [x, y, z] = sph2cart(azi, ele, ones(size(azi)));

    q_s = cos(e0/2);
    q_v = sin(e0/2)*[0 1 0];
    e_q = [q_v q_s];

    q_s = cos(a0/2);
    q_v = sin(a0/2)*[0 0 -1];
    a_q = [q_v q_s];

    q = qmult(e_q, a_q);

    coord = zeros(size(x,1), size(x,2), 3);
    for i=1:size(x,1),
        for j=1:size(x,2),
            v = [x(i,j) y(i,j) z(i,j)];
            coord(i,j,:) = qvqc(q, v);
        end
    end

    nx = squeeze(coord(:,:,1));
    ny = squeeze(coord(:,:,2));
    nz = squeeze(coord(:,:,3));

    [azi, ele, ~] = cart2sph(nx, ny, nz);

    v = cos_tuning([0 n], azi).*cos_tuning([0 m], ele) + DC;

    surf(x, y, z, v);
    hold on;
    plot3(x0, y0, z0, '*');
    hold off;
    xlabel('x');
    ylabel('y');
    zlabel('z');
    axis equal;
end