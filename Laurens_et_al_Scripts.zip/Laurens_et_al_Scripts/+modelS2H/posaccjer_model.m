function r = posaccjer_model(param, coord)
    u_ele = coord(1:5);
    u_azi = coord(6:14);
    time = coord(15:end);
    
    %velocity model
    i_gauss_time = i_gauss(param(2:3), time);
    p_ele_azi = sh_recon(param(4:11), 2, u_azi, u_ele+pi/2) + param(12);
    
    %acceleration model
    d_gauss_time = d_gauss(param(2:3), time);
    a_ele_azi = sh_recon(param(13:20), 2, u_azi, u_ele+pi/2) + param(21);
    
    %jerk model
    d2_gauss_time = d2_gauss(param(2:3), time);
    j_ele_azi = sh_recon(param(22:29), 2, u_azi, u_ele+pi/2) + param(30);

    %compute results
    r = zeros(size(p_ele_azi,1), size(p_ele_azi,2), length(i_gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            r(i,j,:) = p_ele_azi(i,j)*i_gauss_time + ...
                       a_ele_azi(i,j)*d_gauss_time + ...
                       j_ele_azi(i,j)*d2_gauss_time + ...
                       param(1);
        end
    end

    r = packPSTH(r);
end