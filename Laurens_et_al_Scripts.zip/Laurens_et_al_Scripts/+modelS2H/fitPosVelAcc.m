classdef fitPosVelAcc
    properties
        reps 
        psth
  
        u_azi
        u_ele
        time
        
        time_profile1
        time_profile2
        time_profile3
        
        baseline
        
        R_0
        mu_t
        sig_t
        
        p_ele_azi_profile
        p_space_profile
        p_coeff
        p_DC
        p_A
        
        v_ele_azi_profile
        v_space_profile
        v_coeff
        v_DC
        v_A
        
        a_ele_azi_profile
        a_space_profile
        a_coeff
        a_DC
        a_A

        init_param
        
        posvelacc_param
        rand_param
        
        posvelacc_rss       
        rand_rss
        
        posvelacc_jac
        rand_jac
    end
    
    methods
        function obj = fitPosVelAcc(p, reps)
            obj.reps = reps;
            obj.psth = p.psth;

            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            obj.baseline = p.baseline;
            
            stim_sig = sqrt(sqrt(2))/6;
            obj.mu_t = 1;
            obj.sig_t = stim_sig;
            
            %Compute Spatial Profiles
            i_gauss_time = i_gauss([obj.mu_t obj.sig_t], obj.time)';
            gauss_time = gauss([obj.mu_t obj.sig_t], obj.time)';
            d_gauss_time = d_gauss([obj.mu_t obj.sig_t], obj.time)';
            
            u1 = i_gauss_time;
            p1 = (u1'*gauss_time)/(u1'*u1);
            u2 = gauss_time - p1*u1;
            p21 = (u1'*d_gauss_time)/(u1'*u1);
            p22 = (u2'*d_gauss_time)/(u2'*u2);
            u3 = d_gauss_time - p21*u1 - p22*u2;
            
            t_psth = obj.psth - obj.baseline;
            obj.p_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            obj.v_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            obj.a_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);

            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi),
                    t_profile = squeeze(t_psth(i,j,:));
                    coeff = (pinv([u1 u2 u3])*squeeze(t_profile));
                    obj.p_ele_azi_profile(i,j) = coeff(1) - coeff(2)*p1 + coeff(3)*(-p21+p22*p1);
                    obj.v_ele_azi_profile(i,j) = coeff(2) - coeff(3)*p22;
                    obj.a_ele_azi_profile(i,j) = coeff(3);
                end
            end
            
            %Normalise Profiles 
            obj.p_DC = mean(obj.p_ele_azi_profile(:));
            obj.p_space_profile = obj.p_ele_azi_profile - obj.p_DC;                                                
            
            obj.v_DC = mean(obj.v_ele_azi_profile(:));
            obj.v_space_profile = obj.v_ele_azi_profile - obj.v_DC;                                         
            
            obj.a_DC = mean(obj.a_ele_azi_profile(:));
            obj.a_space_profile = obj.a_ele_azi_profile - obj.a_DC;                                         
           
            %Fit spatial profile
            d_azi = 2*pi/length(obj.u_azi);
            d_ele = pi/length(obj.u_ele);
            obj.p_coeff = sh_coeff(obj.p_space_profile, 2, ...
                                   obj.u_azi, obj.u_ele+pi/2, ...
                                   d_azi, d_ele);
                               
            obj.v_coeff = sh_coeff(obj.v_space_profile, 2, ...
                                   obj.u_azi, obj.u_ele+pi/2, ...
                                   d_azi, d_ele);          
            
            obj.a_coeff = sh_coeff(obj.a_space_profile, 2, ...
                                   obj.u_azi, obj.u_ele+pi/2, ...
                                   d_azi, d_ele);
                               
            obj.R_0 = obj.baseline;
           
            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);

            param = [obj.R_0, ...      %1
                     obj.mu_t, ...     %2
                     obj.sig_t, ...    %3
                     obj.p_coeff', ... %4-11
                     obj.p_DC, ...     %12
                     obj.v_coeff', ... %13-20
                     obj.v_DC, ...     %21
                     obj.a_coeff', ... %22-29
                     obj.a_DC];        %30
                           
            obj.init_param = param;
            
            y_data = packPSTH(obj.psth);

            LB = [0, ...               %1     R_0
                  1, ...               %2     mu_t
                  0.5*stim_sig, ...    %3     sig_t
                  -1000*ones(1,8), ... %4-11  v_coeff
                  -1000, ...           %12    v_DC
                  -1000*ones(1,8), ... %13-20 a_coeff
                  -1000, ...           %21    a_DC
                  -1000*ones(1,8), ... %22-29 j_coeff
                  -1000];              %30    j_DC
                 
              
            UB = [300, ...            %1     R_0
                  1.5, ...            %2     mu_t
                  2*stim_sig,...      %3     sig_t
                  1000*ones(1,8), ... %4-11  v_coeff
                  1000, ...           %12    v_DC
                  1000*ones(1,8), ... %13-20 a_coeff
                  1000, ...           %21    a_DC
                  1000*ones(1,8), ... %22-29 j_coeff
                  1000];              %30    j_DC
            
            t_rand_rss = zeros(obj.reps+1,1);
            t_rand_param = zeros(obj.reps+1, length(param));
            t_rand_jac = zeros(obj.reps+1, length(param), length(param));

            [t_rand_param(1,:), t_rand_rss(1),~,~,~,~,tmp_jacobian] = ...
            lsqcurvefit('posvelacc_model', obj.init_param, st_data, y_data, LB, UB, options);
            t_rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
            
            %Initial Conditions Random Range
            err_range =  0.1*(UB - LB);
            min_param = t_rand_param(1,:);
            UB_param = min_param+err_range;
            LB_param = min_param-err_range;
            
            parfor i=2:obj.reps+1,
                %Randomise Initial Conditions
                seed_param  = unifrnd(LB_param, UB_param);
                
                [t_rand_param(i,:), t_rand_rss(i),~,~,~,~,tmp_jacobian] = ...
                 lsqcurvefit('posvelacc_model', seed_param, st_data, y_data, LB, UB, options);
                 t_rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
            end
           
            obj.rand_param = t_rand_param;
            obj.rand_rss = t_rand_rss;
            obj.rand_jac = t_rand_jac;
            
            [~,min_idx] = min(obj.rand_rss);
            obj.posvelacc_param = obj.rand_param(min_idx,:);
            obj.posvelacc_rss = obj.rand_rss(min_idx);
            obj.posvelacc_jac = obj.rand_jac(min_idx,:,:);
        end
        
        function plotPSTH(obj, trial_name, page_num, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];           
            
            init_fit = posvelacc_model(obj.init_param(1,:), st_data);
            posvelacc_fit = posvelacc_model(obj.posvelacc_param, st_data);

            init_fit = unpackPSTH(init_fit, size(obj.psth));
            posvelacc_fit = unpackPSTH(posvelacc_fit, size(obj.psth));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(init_fit(i,j,:)), 'g');
                    plot(obj.time, squeeze(posvelacc_fit(i,j,:)), 'k');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page_num) ': ' trial_name];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                 'FontName', 'helvetica', 'FontSize', 12);
             
            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
        
        function printVal(obj)
            disp('Position + Velocity + Acceleration');
            disp(['A      : ' num2str(obj.posvelacc_param(1))]);
            disp(['R_0    : ' num2str(obj.posvelacc_param(2))]);
            
            disp(['v_mu_t : ' num2str(obj.posvelacc_param(3))]);
            disp(['v_sig_t: ' num2str(obj.posvelacc_param(4))]); 
            disp(['v_n    : ' num2str(obj.posvelacc_param(5))]);
            disp(['v_a_0  : ' num2str(obj.posvelacc_param(6)*180/pi)]);
            disp(['v_e_0  : ' num2str(obj.posvelacc_param(7)*180/pi)]);
            disp(['v_DC   : ' num2str(obj.posvelacc_param(8))]);
            
            disp(['a_mu_t : ' num2str(obj.posvelacc_param(9))]);
            disp(['a_sig_t: ' num2str(obj.posvelacc_param(10))]); 
            disp(['a_n    : ' num2str(obj.posvelacc_param(11))]);
            disp(['a_a_0  : ' num2str(obj.posvelacc_param(12)*180/pi)]);
            disp(['a_e_0  : ' num2str(obj.posvelacc_param(13)*180/pi)]);
            disp(['a_DC   : ' num2str(obj.posvelacc_param(14))]);
            
            disp(['j_mu_t : ' num2str(obj.posvelacc_param(15))]);
            disp(['j_sig_t: ' num2str(obj.posvelacc_param(16))]); 
            disp(['j_n    : ' num2str(obj.posvelacc_param(17))]);
            disp(['j_a_0  : ' num2str(obj.posvelacc_param(18)*180/pi)]);
            disp(['j_e_0  : ' num2str(obj.posvelacc_param(19)*180/pi)]);
            disp(['j_DC   : ' num2str(obj.posvelacc_param(20))]);
            
            disp(['w_v    : ' num2str(obj.posvelacc_param(21))]);
            disp(['w_j    : ' num2str(obj.posvelacc_param(22))]);
        end
        
    end 
end