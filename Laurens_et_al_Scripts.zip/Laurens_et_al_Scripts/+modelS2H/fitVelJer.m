classdef fitVelJer
    properties
        reps       
        psth
        
        u_azi
        u_ele
        time
 
        baseline
        
        R_0
        mu_t
        sig_t
        
        v_ele_azi_profile
        v_space_profile
        v_coeff
        v_DC
        v_A
        
        j_ele_azi_profile
        j_space_profile
        j_coeff
        j_DC
        j_A
        
        init_param
        
        veljer_param
        rand_param
        
        veljer_rss       
        rand_rss
        
        veljer_jac
        rand_jac
    end
    
    methods
        function obj = fitVelJer(p, reps)
            obj.reps = reps;
            obj.psth = p.psth;

            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;
            st_data = [obj.u_ele; obj.u_azi; obj.time'];

            obj.baseline = p.baseline;
            
            stim_sig = sqrt(sqrt(2))/6;
            peak_i = find(obj.time >= 1, 1, 'first')-1;
            obj.sig_t = stim_sig; 
            
            %Compute Temporal Profiles
            c = cell(2,1);
            lags = cell(2,1);
            idx = zeros(2,1);
            m = zeros(2,1);
            gauss_time = gauss([1 stim_sig], obj.time)';
            [cl, l] = xcorr(gauss_time, p.t_profile1, 20, 'coeff');
            neg_lags_idx = l < 0;
            lags{1} = l(neg_lags_idx);
            c{1} = cl(neg_lags_idx);
            [m(1), idx(1)] = max(abs(c{1}));
            
            d2_gauss_time = d2_gauss([1 stim_sig], obj.time)';
            [cl, l] = xcorr(d2_gauss_time, p.t_profile1, 20, 'coeff');
            lags{2} = l(neg_lags_idx);
            c{2} = cl(neg_lags_idx);
            [m(2), idx(2)] = max(abs(c{2}));
            
            profile1 = p.s_profile1;
            profile1(:,1) = profile1(1,1);
            profile1(:,end) = profile1(1,end);
            profile1(end,:) = profile1(1,:);
            
            profile2 = p.s_profile2;
            profile2(:,1) = profile2(1,1);
            profile2(:,end) = profile2(1,end);
            profile2(end,:) = profile2(1,:);

            [~,max_1] = max(m);
            switch max_1
                case 1
                    idx_i = idx(1);
                    delay_i = lags{1}(idx(1));
                    obj.mu_t = obj.time(peak_i - delay_i);
                    v_t_A = (max(p.t_profile1)-min(p.t_profile1))/2; 
                    j_t_A = (max(p.t_profile2)-min(p.t_profile2))/2;
                    
                    s = 1;
                    if c{1}(idx_i) < 0,
                        s = -1;
                    end
                    obj.v_ele_azi_profile = s*v_t_A*profile1;
                    
                    cl = xcorr(d2_gauss_time, p.t_profile2, 20, 'coeff');
                    c_t = cl(neg_lags_idx);
                    s = 1;
                    if c_t(idx_i) < 0,
                        s = -1;
                    end
                    obj.j_ele_azi_profile = s*j_t_A*profile2;
                    
                case 2
                    idx_i = idx(2);
                    delay_i = lags{2}(idx(2));
                    obj.mu_t = obj.time(peak_i - delay_i);
                    v_t_A = (max(p.t_profile2)-min(p.t_profile2))/2;
                    j_t_A = (max(p.t_profile1)-min(p.t_profile1))/2; 
                    
                    cl = xcorr(gauss_time, p.t_profile2, 20, 'coeff');
                    c_t = cl(neg_lags_idx);
                    s = 1;
                    if c_t(idx_i) < 0,
                        s = -1;
                    end
                    obj.v_ele_azi_profile = s*v_t_A*profile2;
                    
                    s = 1;
                    if c{2}(idx_i) < 0,
                        s = -1;
                    end                    
                    obj.j_ele_azi_profile = s*j_t_A*profile1;
            end

            %Normalise Profiles 
            obj.v_DC = mean(obj.v_ele_azi_profile(:));
            obj.v_space_profile = obj.v_ele_azi_profile - obj.v_DC;                                         
 
            obj.j_DC = mean(obj.j_ele_azi_profile(:));
            obj.j_space_profile = obj.j_ele_azi_profile - obj.j_DC;                                         
            
            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);
            
            %Fit spatial profile
            d_azi = 2*pi/length(obj.u_azi);
            d_ele = pi/length(obj.u_ele);
            obj.v_coeff = sh_coeff(obj.v_space_profile, 2, ...
                                   obj.u_azi, obj.u_ele+pi/2, ...
                                   d_azi, d_ele);          
            
            obj.j_coeff = sh_coeff(obj.j_space_profile, 2, ...
                                   obj.u_azi, obj.u_ele+pi/2, ...
                                   d_azi, d_ele);                  

            obj.R_0 = obj.baseline;
            
            %Initial fits
            param = [obj.R_0, ...      %1     R_0
                     obj.mu_t, ...     %2     mu_t
                     obj.sig_t, ...    %3     sig_t
                     obj.v_coeff', ... %4-11  v_coeff
                     obj.v_DC, ...     %12    v_DC
                     obj.j_coeff', ... %13-20 v_coeff
                     obj.j_DC];        %21    j_DC
            
            obj.init_param(1,:) = param;
            
            y_data = packPSTH(obj.psth);
            
            LB = [0, ...               %1     R_0
                  1, ...             %2     mu_t
                  0.5*stim_sig, ...    %3     sig_t
                  -1000*ones(1,8), ... %4-11  v_coeff
                  -1000, ...           %12    v_DC
                  -1000*ones(1,8), ... %13-20 j_coeff
                  -1000];              %21    j_DC
              
            UB = [300, ...            %1     R_0
                  1.5, ...            %2     mu_t
                  2*stim_sig, ...     %3     sig_t
                  1000*ones(1,8), ... %4-11  v_coeff
                  1000, ...           %12    v_DC
                  1000*ones(1,8), ... %13-20 j_coeff
                  1000];              %21    j_DC
                       
            t_rand_rss = zeros(obj.reps+1,1);
            t_rand_param = zeros(obj.reps+1, length(param));
            t_rand_jac = zeros(obj.reps+1, length(param), length(param));
              
            [t_rand_param(1,:), t_rand_rss(1),~,~,~,~,tmp_jacobian] = ...
             lsqcurvefit('veljer_model', obj.init_param(1,:), st_data, y_data, LB, UB, options);
            t_rand_jac(1,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);

            %Initial Conditions Random Range
            err_range =  0.1*(UB - LB);
            min_param = t_rand_param(1,:);
            UB_param = min_param+err_range;
            LB_param = min_param-err_range;
            
            parfor i=2:obj.reps+1,
                %Randomise Initial Conditions
                seed_param  = unifrnd(LB_param, UB_param);
                
                [t_rand_param(i,:), t_rand_rss(i),~,~,~,~,tmp_jacobian] = ...
                lsqcurvefit('veljer_model', seed_param, st_data, y_data, LB, UB, options);
                t_rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
            end
            
            obj.rand_param = t_rand_param;
            obj.rand_rss = t_rand_rss;
            obj.rand_jac = t_rand_jac;
            
            [~,min_idx] = min(obj.rand_rss);
            obj.veljer_param = obj.rand_param(min_idx,:);
            obj.veljer_rss = obj.rand_rss(min_idx);
            obj.veljer_jac = obj.rand_jac(min_idx,:,:);
        end
        
        function plotPSTH(obj, trial_name, page_num, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            init_fit = veljer_model(obj.init_param(1,:), st_data); 
            veljer_fit = veljer_model(obj.veljer_param, st_data);
            
            init_fit = unpackPSTH(init_fit, size(obj.psth));
            veljer_fit = unpackPSTH(veljer_fit, size(obj.psth));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(init_fit(i,j,:)), 'g');
                    plot(obj.time, squeeze(veljer_fit(i,j,:)), 'k');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page_num) ': ' trial_name];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                 'FontName', 'helvetica', 'FontSize', 12);
             
            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
        
        function plotReconPSTH(obj)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            gauss_time = gauss([obj.mu_t obj.sig_t], obj.time);
            d2_gauss_time = d2_gauss([obj.mu_t obj.sig_t], obj.time);
            
            param = [obj.v_n obj.v_a_0 obj.v_e_0 ...
                     obj.v_n2 obj.v_a2_0 obj.v_e2_0 ...
                     obj.v_s_A2 obj.v_DC+obj.v_DC2];
            v_sp = d_cos_tuning(param, st_data);
            v_sp = reshape(v_sp, length(obj.u_azi), length(obj.u_ele));

            param = [obj.j_n obj.j_a_0 obj.j_e_0 ...
                     obj.j_n2 obj.j_a2_0 obj.j_e2_0 ...
                     obj.j_s_A2 obj.j_DC+obj.j_DC2];
            j_sp = d_cos_tuning(param, st_data);
            j_sp = reshape(j_sp, length(obj.u_azi), length(obj.u_ele));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;      
                    plot(obj.time, gauss_time*obj.v_ele_azi_profile(i,j) + ...
                                   d2_gauss_time*obj.j_ele_azi_profile(i,j) + ...
                                   obj.baseline, 'b');
%                     plot(obj.time, gauss_time*obj.v_A * ...
%                                    (obj.v_space_profile(i,j)+obj.v_DC) + ...
%                                    d2_gauss_time*obj.j_A * ...
%                                    (obj.j_space_profile(i,j)+obj.j_DC ) + ...
%                                    obj.baseline, 'g');
                    plot(obj.time, gauss_time*obj.v_A*v_sp(i,j) + ...
                                   d2_gauss_time*obj.j_A*j_sp(i,j) + ...
                                   obj.baseline, 'g');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
        end
        
        function printVal(obj, trial_name)
            disp('Velocity + Jerk');
            disp(trial_name);
                             
            [x, y, z] = sph2cart(obj.veljer_param(9), ... 
                                 obj.veljer_param(10), 1);
            disp(['v_r     : ' num2str(180/pi*acos([1 0 0]*[x y z]'))]);
            disp(['A       : ' num2str(obj.veljer_param(1))]);
            disp(['R_0     : ' num2str(obj.veljer_param(2))]);
            disp(['v_mu_t  : ' num2str(obj.veljer_param(3))]);
            disp(['v_sig_t : ' num2str(obj.veljer_param(4))]);
            disp(['v_n     : ' num2str(obj.veljer_param(5))]);
            disp(['v_a_0   : ' num2str(obj.veljer_param(6)*180/pi)]);
            disp(['v_e_0   : ' num2str(obj.veljer_param(7)*180/pi)]);
            disp(['v_n2    : ' num2str(obj.veljer_param(8))]);
            disp(['v_a2_0  : ' num2str(obj.veljer_param(9)*180/pi)]);
            disp(['v_e2_0  : ' num2str(obj.veljer_param(10)*180/pi)]);
            disp(['v_DC    : ' num2str(obj.veljer_param(11))]);
            disp(['v_A2    : ' num2str(obj.veljer_param(12))]);
            [x, y, z] = sph2cart(obj.veljer_param(19), ... 
                                 obj.veljer_param(20), 1);
            disp(['j_r     : ' num2str(180/pi*acos([1 0 0]*[x y z]'))]);
            disp(['j_mu_t  : ' num2str(obj.veljer_param(13))]);
            disp(['j_sig_t : ' num2str(obj.veljer_param(14))]);
            disp(['j_n     : ' num2str(obj.veljer_param(15))]);
            disp(['j_a_0   : ' num2str(obj.veljer_param(16)*180/pi)]);
            disp(['j_e_0   : ' num2str(obj.veljer_param(17)*180/pi)]);
            disp(['j_n2    : ' num2str(obj.veljer_param(18))]);
            disp(['j_a2_0  : ' num2str(obj.veljer_param(19)*180/pi)]);
            disp(['j_e2_0  : ' num2str(obj.veljer_param(20)*180/pi)]);
            disp(['j_DC    : ' num2str(obj.veljer_param(21))]);
            disp(['j_A2    : ' num2str(obj.veljer_param(22))]);
            disp(['w       : ' num2str(obj.veljer_param(23))]);
        end
    end 
end
