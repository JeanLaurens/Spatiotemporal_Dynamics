classdef fitVelAcc
    properties
        reps       
        psth
        
        fa
        fv
        
        u_azi
        u_ele
        time
        
        baseline
                
        R_0
        mu_t
        sig_t
        
        v_ele_azi_profile
        v_space_profile
        v_A
        v_coeff
        v_DC

        a_ele_azi_profile
        a_space_profile
        a_A
        a_coeff
        a_DC
        
        init_param
        
        velacc_param
        rand_param
        
        velacc_rss       
        rand_rss
        
        velacc_jac
        rand_jac
    end
    
    methods
        function obj = fitVelAcc(p, reps)
            obj.reps = reps;
            obj.psth = p.psth;

            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
           
            obj.baseline = p.baseline;
            
            stim_sig = sqrt(sqrt(2))/6;
            obj.mu_t = 1.115;
            obj.sig_t = stim_sig;

            %Compute Spatial Profiles
            gauss_time = gauss([obj.mu_t obj.sig_t], obj.time)';
            d_gauss_time = d_gauss([obj.mu_t obj.sig_t], obj.time)';
            
            u1 = gauss_time;
            p = (u1'*d_gauss_time)/(u1'*u1);
            u2 = d_gauss_time - p*u1;
            
            t_psth = obj.psth-obj.baseline;
            obj.v_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            obj.a_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi),
                    t_profile = squeeze(t_psth(i,j,:));
                    coeff = (pinv([u1 u2])*squeeze(t_profile));
                    obj.v_ele_azi_profile(i,j) = coeff(1)-coeff(2)*p;
                    obj.a_ele_azi_profile(i,j) = coeff(2);
                end
            end

            %Normalise Profiles 
            obj.v_DC = mean(obj.v_ele_azi_profile(:));
            obj.v_space_profile = obj.v_ele_azi_profile-obj.v_DC;                                                
            
            obj.a_DC = mean(obj.a_ele_azi_profile(:));
            obj.a_space_profile = obj.a_ele_azi_profile-obj.a_DC;                                         

            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);
            
            %Fit spatial profile
            d_azi = 2*pi/length(obj.u_azi);
            d_ele = pi/length(obj.u_ele);
            obj.v_coeff = sh_coeff(obj.v_space_profile, 1, ...
                                   obj.u_azi, obj.u_ele+pi/2, ...
                                   d_azi, d_ele);          
            
            obj.a_coeff = sh_coeff(obj.a_space_profile, 1, ...
                                   obj.u_azi, obj.u_ele+pi/2, ...
                                   d_azi, d_ele);
            
            obj.R_0 = obj.baseline;
 
            %Initial fits
            param = [obj.R_0, ...      %1
                     obj.mu_t, ...     %2
                     obj.sig_t, ...    %3
                     obj.v_coeff', ... %4-6
                     obj.v_DC, ...     %7
                     obj.a_coeff', ... %8-10
                     obj.a_DC];        %11
            
            obj.init_param = zeros(obj.reps+1, length(param));
            obj.init_param(1,:) = param;
            
            y_data = packPSTH(obj.psth);
            
            LB = [0, ...               %1    R_0
                  0.5, ...             %2    mu_t
                  0.5*stim_sig, ...    %3    sig_t
                  -1000*ones(1,3), ... %4-6  v_coeff
                  -1000, ...           %7    v_DC
                  -1000*ones(1,3), ... %8-10 j_coeff
                  -1000];              %11   a_DC
              
            UB = [300, ...            %1    R_0
                  1.5, ...            %2    mu_t
                  2*stim_sig, ...     %3    sig_t
                  1000*ones(1,3), ... %4-6  v_coeff
                  1000, ...           %7    v_DC
                  1000*ones(1,3), ... %8-10 j_coeff
                  1000];              %11   a_DC
                       
            obj.rand_rss = zeros(obj.reps+1,1);
            obj.rand_param = zeros(obj.reps+1, length(param));
            obj.rand_jac = zeros(obj.reps+1, length(param), length(param));
              
            [obj.rand_param(1,:),obj.rand_rss(1),~,~,~,~,tmp_jacobian] = ...
            lsqcurvefit('velacc_model', obj.init_param(1,:), st_data, y_data, LB, UB, options);
            obj.rand_jac(1,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
            min_rss = obj.rand_rss(1);
            min_param = obj.rand_param(1,:);

            err_range =  0.1*(UB - LB);
            for i=2:obj.reps+1,
                %Randomise Initial Conditions
                obj.init_param(i,:) = min_param;
                UB_param = min_param+err_range;
                LB_param = min_param-err_range;

                UB_param(UB < UB_param) = UB(UB < UB_param);
                LB_param(LB > LB_param) = LB(LB > LB_param);
                seed_param  = unifrnd(LB_param, UB_param);
                
                [obj.rand_param(i,:), obj.rand_rss(i),~,~,~,~,tmp_jacobian] = ...
                lsqcurvefit('velacc_model', seed_param, st_data, y_data, LB, UB, options);
                obj.rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
                
                if obj.rand_rss(i) < min_rss,
                    min_rss = obj.rand_rss;
                    min_param = obj.rand_param(i,:);
                end
            end
            
            [~,min_idx] = min(obj.rand_rss);
            obj.velacc_param = obj.rand_param(min_idx,:);
            obj.velacc_rss = obj.rand_rss(min_idx);
            obj.velacc_jac = obj.rand_jac(min_idx,:,:);
        end
        
        function plotPSTH(obj, trial_name, page_num, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];           
            
            init_fit = velacc_model(obj.init_param(1,:), st_data);
            velacc_fit = velacc_model(obj.velacc_param, st_data);

            init_fit = unpackPSTH(init_fit, size(obj.psth));
            velacc_fit = unpackPSTH(velacc_fit, size(obj.psth));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(init_fit(i,j,:)), 'g');
                    plot(obj.time, squeeze(velacc_fit(i,j,:)), 'k');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page_num) ': ' trial_name];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                 'FontName', 'helvetica', 'FontSize', 12);
             
            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
        
        function plotReconPSTH(obj)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            gauss_time = gauss([obj.mu_t obj.sig_t], obj.time);
            param = [obj.n obj.a_0 obj.e_0 ...
                     obj.n2 obj.a2_0 obj.e2_0 ...
                     obj.s_A2 obj.DC+obj.DC2];
            sp = d_cos_tuning(param, st_data);
            sp = reshape(sp, length(obj.u_azi), length(obj.u_ele));

            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, obj.t_A*gauss_time *...
                                   obj.s_A*sp(i,j) + obj.baseline, 'g');       
                    plot(obj.time, obj.t_A*gauss_time * ...
                                   obj.ele_azi_profile(i,j) + ...
                                   obj.baseline, 'b');          
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
        end
        
        function printVal(obj)
            disp('Velocity + Acceleration');
            disp(['A    : ' num2str(obj.velacc_param(1))]);
            disp(['R_0  : ' num2str(obj.velacc_param(2))]);
            disp(['mu_t : ' num2str(obj.velacc_param(3))]);
            disp(['sig_t: ' num2str(obj.velacc_param(4))]);
            disp(['v_a_n: ' num2str(obj.velacc_param(5))]);
            disp(['v_a_0: ' num2str(obj.velacc_param(6))]);
            disp(['v_e_n: ' num2str(obj.velacc_param(7))]);
            disp(['v_e_0: ' num2str(obj.velacc_param(8))]);
            disp(['v_DC : ' num2str(obj.velacc_param(9))]);
            disp(['a_a_n: ' num2str(obj.velacc_param(10))]);
            disp(['a_a_0: ' num2str(obj.velacc_param(11))]);
            disp(['a_e_n: ' num2str(obj.velacc_param(12))]);
            disp(['a_e_0: ' num2str(obj.velacc_param(13))]);
            disp(['a_DC : ' num2str(obj.velacc_param(14))]);
            disp(['w    : ' num2str(obj.velacc_param(15))]);
        end
    end 
end