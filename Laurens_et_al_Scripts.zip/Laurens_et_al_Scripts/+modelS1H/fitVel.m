classdef fitVel
    properties
        reps
        psth
        
        u_azi
        u_ele
        time
        
        time_profile
        
        baseline
        
        R_0
        
        ele_azi_profile
        space_profile
        mu_t
        sig_t
        
        coeff
        DC
        
        t_A
        
        init_param
       
        vel_param
        rand_param
        
        vel_rss
        rand_rss
        
        vel_jac
        rand_jac
    end
    
    methods
        function obj = fitVel(p, mod, comp, reps)
            obj.reps = reps;
            
            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;
 
            %Initialize profiles
            switch mod
                case 1
                    obj.psth = p.psth;
                    
                    obj.time_profile = p.time_profile;
                    obj.ele_azi_profile = p.ele_profile*p.azi_profile;
                    
                case 2
                    switch comp
                        case 1
                            obj.time_profile = p.time_profile2(:,1);
                            obj.ele_azi_profile = p.ele_profile2(:,1)*...
                                                  p.azi_profile2(1,:);

                        case 2
                            obj.time_profile = p.time_profile2(:,2);
                            obj.ele_azi_profile = p.ele_profile2(:,2)*...
                                                  p.azi_profile2(2,:);
                                             
                        otherwise
                            disp(['Model 2 does not have ' num2str(comp) '.']);
                    end
                    
                    t_psth = zeros(size(p.psth));
                    for i=1:size(obj.ele_azi_profile,1),
                        for j=1:size(obj.ele_azi_profile,2),
                            t_psth(i,j,:) = obj.ele_azi_profile(i,j)*...
                                            obj.time_profile;
                        end
                    end
                    obj.psth = t_psth + p.baseline;
                    
                case 3
                    switch comp
                        case 1
                            obj.time_profile = p.time_profile3(:,1);
                            obj.ele_azi_profile = p.ele_profile3(:,1)*...
                                                  p.azi_profile3(1,:);
                            
                        case 2
                            obj.time_profile = p.time_profile3(:,2);
                            obj.ele_azi_profile = p.ele_profile3(:,2)*...
                                                  p.azi_profile3(2,:);
                             
                        case 3
                            obj.time_profile = p.time_profile3(:,3);
                            obj.ele_azi_profile = p.ele_profile3(:,3)*...
                                                  p.azi_profile3(3,:);
                        otherwise
                            disp(['Model 3 does not have ' num2str(comp) '.']);                     
                    end
                    
                    t_psth = zeros(size(p.psth));
                    for i=1:size(obj.ele_azi_profile,1),
                        for j=1:size(obj.ele_azi_profile,2),
                            t_psth(i,j,:) = obj.ele_azi_profile(i,j)*...
                                            obj.time_profile;
                        end
                    end
                    obj.psth = t_psth + p.baseline;
                    
                otherwise
                    disp(['Model ' num2str(mod) 'does not exist.']);
            end
            obj.baseline = p.baseline;
            
            %Match time profile to gaussian
            stim_sig = sqrt(sqrt(2))/6;
            stim = gauss([1.115 stim_sig], obj.time);
            corrcoeff = xcorr(stim, obj.time_profile, 'coeff');
            [~,max_val] = max(abs(corrcoeff));

            if corrcoeff(max_val) < 0,
                obj.time_profile = -obj.time_profile;
                obj.ele_azi_profile = -obj.ele_azi_profile;
            end
            
            %Normalise Profiles 
            obj.t_A = max(obj.time_profile)-min(obj.time_profile);
            obj.time_profile = obj.time_profile/obj.t_A;

            obj.space_profile = obj.t_A*obj.ele_azi_profile;      
            obj.DC = mean(obj.space_profile(:)); 
            obj.space_profile = obj.space_profile - obj.DC;

            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);
            
            %Fit time profile
            obj.mu_t = 1.115;
            obj.sig_t = stim_sig; 
            
            LB = [0.5 0.5*stim_sig];
            UB = [1.5 2*stim_sig];
            recon_t = lsqcurvefit('gauss', [obj.mu_t obj.sig_t], ...
                        obj.time, obj.time_profile', LB, UB, options);
            obj.mu_t = recon_t(1);
            obj.sig_t = recon_t(2);

            %Fit spatial profile
            d_azi = 2*pi/length(obj.u_azi);
            d_ele = pi/length(obj.u_ele);
            obj.coeff = sh_coeff(obj.space_profile, 1, ...
                                 obj.u_azi, obj.u_ele+pi/2, ...
                                 d_azi, d_ele);
            
           %Fit linear parameters
           obj.R_0 = p.baseline;

           %Inital fits
            param = [obj.R_0, ...    %1
                     obj.mu_t, ...   %2
                     obj.sig_t, ...  %3
                     obj.coeff', ... %4-6
                     obj.DC];        %7
                 
            obj.init_param = zeros(obj.reps+1, length(param));
            obj.init_param(1,:) = param;
          
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            y_data = packPSTH(obj.psth);
            
            LB = [0, ...               %1  R_0
                  0.5, ...             %2  mu_t
                  0.5*stim_sig, ...    %3  sig_t
                  -1000*ones(1,3), ... %4-6 coeff
                  -1000]; ...          %7 DC
                  
            UB = [300, ...            %1  R_0
                  1.5, ...            %2  mu_t
                  2*stim_sig, ...     %3  sig_t
                  1000*ones(1,3), ... %4-6 coeff
                  1000];              %7 DC
           
            obj.rand_rss = zeros(obj.reps+1,1);
            obj.rand_param = zeros(obj.reps+1, length(param));
            obj.rand_jac = zeros(obj.reps+1, length(param), length(param));
              
            [obj.rand_param(1,:),obj.rand_rss(1),~,~,~,~,tmp_jacobian] = ...
            lsqcurvefit('vel_model', obj.init_param(1,:), st_data, y_data, LB, UB, options);
            obj.rand_jac(1,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);  
            min_rss = obj.rand_rss(1);
            min_param = obj.rand_param(1,:);

            err_range =  0.1*(UB - LB);
           
            for i=2:obj.reps+1,
                %Randomise Initial Conditions
                obj.init_param(i,:) = min_param;
                UB_param = min_param+err_range;
                LB_param = min_param-err_range;

                UB_param(UB < UB_param) = UB(UB < UB_param);
                LB_param(LB > LB_param) = LB(LB > LB_param);
                seed_param  = unifrnd(LB_param, UB_param);
                
                [obj.rand_param(i,:),obj.rand_rss(i),~,~,~,~,tmp_jacobian] = ...
                 lsqcurvefit('vel_model', seed_param, st_data, y_data, LB, UB, options);
                 obj.rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
                 
                if obj.rand_rss(i) < min_rss,
                    min_rss = obj.rand_rss;
                    min_param = obj.rand_param(i,:);
                end
            end
            
            [~,min_idx] = min(obj.rand_rss);
            obj.vel_param = obj.rand_param(min_idx,:);
            obj.vel_rss = obj.rand_rss(min_idx);
            obj.vel_jac = obj.rand_jac(min_idx,:,:);
        end
        
        function plotPSTH(obj, trial_name, page_num, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            init_fit = vel_model(obj.init_param(1,:), st_data); 
            vel_fit = vel_model(obj.vel_param, st_data);
            
            init_fit = unpackPSTH(init_fit, size(obj.psth));
            vel_fit = unpackPSTH(vel_fit, size(obj.psth));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(init_fit(i,j,:)), 'g');
                    plot(obj.time, squeeze(vel_fit(i,j,:)), 'k');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page_num) ': ' trial_name];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                 'FontName', 'helvetica', 'FontSize', 12);
             
            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end

        function plotProfileFits(obj)
            gauss_time = gauss([obj.mu_t, obj.sig_t obj.t_A], obj.time);
            s_data = [obj.u_ele; obj.u_azi];
            param = [obj.a_n, obj.a_0, obj.e_n, obj.e_0];
            
            ele_azi = cos_tuning([param 0], s_data);
            ele_azi = reshape(ele_azi, length(obj.u_azi), length(obj.u_ele));

            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz);
            subplot(2,2,[1 2]);
            plot(obj.time, obj.time_profile, 'r');
            hold on;
            plot(obj.time, gauss_time, 'b');
            hold off;
            axis tight;
            box off;
            xlabel('Time (s)');
            
            subplot(2,2,3);
            contourf(obj.u_ele, obj.u_azi, obj.space_profile);
            box off;
            colorbar;
            xlabel('Elevation (rad)');
            ylabel('Aziumuth (rad)');
            
            subplot(2,2,4);
            contourf(obj.u_ele, obj.u_azi, ele_azi);
            box off;
            colorbar;
            xlabel('Elevation (rad)');
            ylabel('Aziumuth (rad)');
        end
        
        function plotReconPSTH(obj)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            gauss_time = gauss([obj.mu_t obj.sig_t], obj.time);
            param = [obj.n obj.a_0 obj.e_0 ...
                     obj.n2 obj.a2_0 obj.e2_0 ...
                     obj.s_A2 obj.DC+obj.DC2];
            sp = d_cos_tuning(param, st_data);
            sp = reshape(sp, length(obj.u_azi), length(obj.u_ele));

            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, obj.t_A*gauss_time *...
                                   obj.s_A*sp(i,j) + obj.baseline, 'g');       
                    plot(obj.time, obj.t_A*gauss_time * ...
                                   obj.ele_azi_profile(i,j) + ...
                                   obj.baseline, 'b');          
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
        end
    end
end