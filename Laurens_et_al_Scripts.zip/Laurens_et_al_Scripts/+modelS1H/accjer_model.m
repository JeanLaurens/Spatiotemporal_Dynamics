function r = accjer_model(param, coord)
    u_ele = coord(1:5);
    u_azi = coord(6:14);
    time = coord(15:end);
    
    %acceleration model
    d_gauss_time = d_gauss(param(2:3), time);
    a_ele_azi = sh_recon(param(4:6), 1, u_azi, u_ele+pi/2) + param(7);

    %jerk model
    d2_gauss_time = d2_gauss(param(2:3), time);
    j_ele_azi = sh_recon(param(8:10), 1, u_azi, u_ele+pi/2) + param(11);
    
    %compute results
    r = zeros(size(a_ele_azi,1), size(a_ele_azi,2), length(d_gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            r(i,j,:) = a_ele_azi(i,j)*d_gauss_time + ...
                       j_ele_azi(i,j)*d2_gauss_time + ...
                       param(1);
        end
    end

    r = packPSTH(r);
end