clear;

DATA_PATH = ['..' filesep '..' filesep '..' filesep 'Data' filesep 'Spikelets' filesep];

disp(DATA_PATH);
data_dir = dir([DATA_PATH '*.smr']);

for i=2:length(data_dir),
    disp(data_dir(i).name);
    fid = fopen([DATA_PATH data_dir(i).name],'r','ieee-le');

    SONImport(fid);
end