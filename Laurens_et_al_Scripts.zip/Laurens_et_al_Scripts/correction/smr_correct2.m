 clear;
addpath(genpath(['..' filesep '..' filesep 'Toolbox']));
addpath(genpath(['..' filesep 'misc']));

PATH = (['..' filesep '..' filesep '..' filesep ...
         'Data' filesep 'Xiongjie_Good' filesep]);
data_dir = dir([PATH 'm*']);

mu_t = 1;
sig_t = sqrt(sqrt(2))/6;

for i = [3 5 8 13 18 22], %1:length(data_dir),
    disp([num2str(i), ', ' data_dir(i).name]);
    
    spikefile = [PATH data_dir(i).name filesep 'ALLspikes.txt'];
    parafile = [PATH  data_dir(i).name filesep 'parameter.txt'];
    allspikes = dlmread(spikefile);

    try
        parameter = dlmread(parafile,'\t',1,0);
    catch
        parameter = dlmread(parafile);
    end

    start_times = parameter(:,4);
    alldata = convert(allspikes, start_times);
    
    cand_trials = parameter(:,6);
    good_trials = find(cand_trials > 0);
    
    try
        file_dir = dir([PATH data_dir(i).name filesep '*.smr']);
        disp([num2str(i), ', ' file_dir(1).name]);
        dat = load([PATH data_dir(i).name filesep file_dir(1).name(1:end-4) '.mat']);
    catch
        continue;
    end
    
%     fid = fopen([PATH data_dir(i).name filesep file_dir(1).name]);
%     SONImport(fid);
% 
%     continue; 

    azi = parameter(good_trials,3)/180*pi;
    ele = parameter(good_trials,2)/180*pi;
    spike_data = alldata(:,:,good_trials);
    
    u_azi = unique(azi);
    u_ele = unique(ele);
    u_azi = u_azi(2:end);
    u_ele = u_ele(2:end);

    pool_lag = nan(length(data_dir), 1);
    pool_filename = cell(length(data_dir), 1);

    num_samples = size(spike_data,2);

    %Spikes Init
    Step = 25;
    wind_time = ((0:Step:5000)-995)/1000;
    wind_time = wind_time(1:end-1);
    lo_b = find(wind_time > -1, 1, 'first');
    up_b = find(wind_time < 4, 1, 'last');
    spike_t = wind_time(lo_b:up_b);

    AccArray = cell(length(u_ele), length(u_azi));

    Acc_lag = nan(length(u_ele), length(u_azi));
    Acc_sig = nan(length(u_ele), length(u_azi));

    Acc_spr = nan(length(u_ele), length(u_azi));
    Acc_snr = zeros(length(u_ele), length(u_azi));

    m_Acc = nan(3001, length(u_ele), length(u_azi));
    Acc_fit = nan(3001, length(u_ele), length(u_azi));
    
    SpikeArray = cell(length(u_ele), length(u_azi));
    SpikeCount_Trial = cell(length(u_ele), length(u_azi));
    psth = zeros(length(u_azi), length(u_ele), ...
                 length(spike_t));
    raw_psth = zeros(length(u_azi), length(u_ele), ...
                     length(spike_t));
    
    %Accelerometer Init
    try
        accel = double(dat.chan3);
    catch
        continue;
    end

    start_t = dat.head3.start;
    stop_t = dat.head3.stop;
    t_samples = dat.head3.npoints;
    delta_t = (stop_t - start_t)/(t_samples);
    
    accel_t = start_t:delta_t:stop_t;

    num_trial = length(start_times);
    accel_dat = zeros(length(wind_time), num_trial);
    for j = 1:num_trial,
        lo_idx = find(accel_t >= (start_times(j) - 1), 1, 'first');
        hi_idx = find(accel_t <= (start_times(j) + 4), 1, 'last'); 
        tmp_accel = squeeze(accel(lo_idx:hi_idx));
        if ~isempty(tmp_accel),
            accel_dat(1:length(tmp_accel),j) = tmp_accel;
        end
    end

    accel_avg = zeros(size(accel_dat,1),length(u_ele),length(u_azi));
    accel_dir = cell(length(u_ele),length(u_azi));
    for j=1:length(u_ele),
        for k=1:length(u_azi),
            %Spike Mean
            curr_cond = squeeze(spike_data(:,:, ele == u_ele(j) & ...
                                                azi == u_azi(k)));
            SpikeArray{j,k} = curr_cond;
            num_wind = floor(num_samples/Step);

            SpikeCount_Trial{j,k} = zeros(num_wind, size(curr_cond,2));
            for l=1:num_wind,
                CurrentValue = curr_cond((l-1)*Step+1:l*Step,:);
                CurrentSpikeCount = sum(CurrentValue)*1000/Step;
                SpikeCount_Trial{j,k}(l,:) = CurrentSpikeCount;                
            end

           PSTH_tmp = squeeze(mean(SpikeCount_Trial{j,k},2));
           raw_psth(k,j,:) = PSTH_tmp(lo_b:up_b);
           half_wind = 4;
           g = normpdf(-half_wind:half_wind, 0, half_wind);
           fil = g/sum(g);
           data = PSTH_tmp(lo_b:up_b);
           psth(k,j,:) = filter(fil, 1, data);

            if j == 1 && k > 1,
                continue;
            end
            
            if j == length(u_ele) && k > 1,
                continue;
            end

            %Accel Mean
            curr_cond = squeeze(accel_dat(:, ele == u_ele(j) & ...
                                             azi == u_azi(k)));
            accel_dir{j, k} = curr_cond;
            accel_avg(1:size(curr_cond,1),j,k) = nanmean(curr_cond, 2);
            
            %Accel Mean
            AccArray{j,k} = curr_cond;
            m_Acc(:,j,k) = nanmean(curr_cond(1:3001,:),2);
        end
    end

    lo_b = find(spike_t > -0.2, 1, 'first');
    up_b = find(spike_t < 2.2, 1, 'last');
    spike_t = spike_t(lo_b:up_b);
    psth = psth(:, :, lo_b+half_wind:up_b+half_wind);
    raw_psth = raw_psth(:, :, lo_b:up_b);
    
    nor_psth = psth;
    nor_psth = nor_psth - nanmean(nor_psth(:));
    nor_psth = nor_psth/(max(nor_psth(:)) - min(nor_psth(:)))*2;
    
    dm_accel_avg = accel_avg(1:3001,:,:);
    %dm_accel_avg = dm_accel_avg - nanmean(dm_accel_avg(:));
    max_a = nanmax(dm_accel_avg(:));
    min_a = nanmin(dm_accel_avg(:));
    
    count = 1;
    scrsz = get(0,'ScreenSize');
    h = figure('Position', scrsz, 'Renderer', 'painters');
    for j = 1:length(u_ele),
        for k = 1:length(u_azi),
            if j == 1 && k > 1,
                continue;
            end
            
            if j == length(u_ele) && k > 1,
                continue;
            end

            curr_dir = dm_accel_avg(1:3001,j,k);
            curr_time = (0:3000)*delta_t-1;
            
            %Normalise Profiles 
            t_A = (max(curr_dir)-min(curr_dir))/2;
            t_c = mean(curr_dir);
            time_profile = (curr_dir-t_c)/t_A;

            %Match time profile to derivative of gaussian
            mu_t = 1;
            sig_t = sqrt(sqrt(2))/6;
            
            [~, max_peak] = max(time_profile);
            [~, min_peak] = min(time_profile);

            sig = 1;
            if max_peak - min_peak > 0,
                sig = -1;
            end
            
            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);
            
            %Fit time profile
            LB = [0.5 0.5*sig_t];
            UB = [1.5 2*sig_t];
            
            if ~any(isnan(time_profile)),
                recon_t = lsqcurvefit('d_gauss', [mu_t sig_t], ...
                            curr_time, sig*time_profile', LB, UB, options);
                Acc_lag(j,k) = recon_t(1);  
                Acc_sig(j,k) = recon_t(2);
                Acc_fit(:,j,k) = t_A*sig*d_gauss(recon_t, curr_time) + t_c;

                Acc_snr(j,k) = norm(m_Acc(:,j,k) - mean(m_Acc(:,j,k)))/...
                                norm(m_Acc(:,j,k) - Acc_fit(:,j,k));
                        
                curr_fit = sig*d_gauss(recon_t, curr_time);

                l2_err = norm(d_gauss(recon_t, curr_time) - sig*time_profile');

                pool_lag(count) = recon_t(1);
                pool_l2(count) = l2_err;
            end
            count = count+1;
            
            %continue;
            
            subplot(length(u_ele), length(u_azi), (length(u_ele)-j)*length(u_azi) + k);
%             plot(lags, corrcoeff, 'r');
%             hold on;
%             plot(lags(max_val), corrcoeff(max_val), 'b*');
%             hold off;
%             area(spike_t, squeeze(nor_psth(k,j,:)), 'FaceColor', 'r');
%             hold on;
            plot(curr_time, (curr_dir - t_c)/t_A, 'color', [0.8 1 0.8]);
            hold on;
            plot(curr_time, curr_fit, 'b');
            plot(spike_t, squeeze(nor_psth(k,j,:)), 'r');
            hold off;
            xlim([0 2]);
            ylim([-1 1]);
            %axis tight;
            line(xlim, [0 0], 'color', 'k');
            line(recon_t(1)*[1 1], ylim, 'color', 'k');
            %title({['lag: ' num2str(recon_t(1))],  ['l_2 Err: ' num2str(l2_err)]});
%             title(['[' num2str(u_ele(j)*180/pi) ', ' ...
%                        num2str(u_azi(k)*180/pi) ']']);
            %disp(xcov(stim, time_profile));
        end
    end


    pool_lag(i) = nanmedian(Acc_lag(Acc_snr > 1));

    for j = 1:length(u_ele),
        for k = 1:length(u_azi),
            if j == 1 && k > 1,
                continue;
            end
            
            if j == length(u_ele) && k > 1,
                continue;
            end
            
            subplot(length(u_ele), length(u_azi), (length(u_ele)-j)*length(u_azi) + k);
            hold on;
            plot(pool_lag(i)*[1 1], [1 -1], 'r');
            hold off;
        end
    end
    
    text_size = 16;
            
    subplot(length(u_ele), length(u_azi)-1, 2);
    axis off;
    tabstring1 = ['Trial :' data_dir(i).name]; 
    text(0, 1, tabstring1, 'Interpreter','latex', ...
                  'FontName', 'helvetica', 'FontSize', text_size);
    
%     set(h, 'PaperPosition', [0 0 11 8.5]);
%     set(h, 'PaperSize', [11 8.5]);
%     saveas(h, [data_dir(i).name '.pdf'], 'pdf');
%     close(h);
    
    %break;
end

return;

scrsz = get(0,'ScreenSize');
figure('Position', scrsz, 'Renderer', 'painters');
subplot(2,2,1);
plot(pool_l2, pool_lag, 'r*');
ylabel('Lags');
xlabel('RMS Error');

subplot(2,2,2)
hist(pool_lag(pool_l2 < 10), 20);
line(nanmedian((pool_lag(pool_l2 < 10)))*[1 1], ylim, 'Color', 'g');
xlabel('Lags');
ylabel('Count');
disp(nanmedian((pool_lag(pool_l2 < 10))));
