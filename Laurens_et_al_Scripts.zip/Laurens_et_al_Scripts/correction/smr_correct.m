clear;
addpath(genpath(['..' filesep '..' filesep 'Toolbox']));
addpath(genpath(['..' filesep 'misc']));

PATH = (['..' filesep '..' filesep '..' filesep ...
         'Data' filesep 'Xiongjie_Good' filesep]);
data_dir = dir([PATH 'm*']);

pool_lag = nan(length(data_dir), 1);
pool_filename = cell(length(data_dir), 1);
pool_dir = cell(length(data_dir), 1);

mu_t = 1;
sig_t = sqrt(sqrt(2))/6;

for i=1:length(data_dir),
    disp([num2str(i), ', ' data_dir(i).name]);
    pool_dir{i} = [PATH  data_dir(i).name filesep];    
    pool_filename{i} = [data_dir(i).name '.mat'];
    
    cur_file_name = data_dir(i).name;

    parafile = [PATH  data_dir(i).name filesep 'parameter.txt'];
    try
        parameter = dlmread(parafile,'\t',1,0);
    catch
        parameter = dlmread(parafile);
    end

    start_times = parameter(:,4);
    
    cand_trials = parameter(:,6);
    good_trials = find(cand_trials > 0);
    
    try
        file_dir = dir([PATH data_dir(i).name filesep '*.smr']);
        disp([num2str(i), ', ' file_dir(1).name]);
        dat = load([PATH data_dir(i).name filesep file_dir(1).name(1:end-4) '.mat']);
        accel = double(dat.chan3);
    catch
        continue;
    end

    azi = parameter(good_trials,3)/180*pi;
    ele = parameter(good_trials,2)/180*pi;
    
    u_azi = unique(azi);
    u_ele = unique(ele);
    u_azi = u_azi(2:end);
    u_ele = u_ele(2:end);

    %Accelerometer Init
    start_t = dat.head3.start;
    stop_t = dat.head3.stop;
    t_samples = dat.head3.npoints;

    delta_t = (stop_t - start_t)/(t_samples-1);
    
    accel_t = start_t:delta_t:stop_t;

    wind_time = 0:delta_t:2;
    num_trial = length(start_times);
    accel_dat = zeros(length(wind_time), num_trial);
    for j = 1:num_trial,
        lo_idx = find(accel_t >= (start_times(j)), 1, 'first');
        hi_idx = find(accel_t <= (start_times(j) + 2), 1, 'last'); 
        tmp_accel = squeeze(accel(lo_idx:hi_idx+1));
        if ~isempty(tmp_accel),
            accel_dat(:,j) = tmp_accel(1:length(wind_time));
        end
    end
    
    AccArray = cell(length(u_ele), length(u_azi));
    
    Acc_lag = nan(length(u_ele), length(u_azi));
    Acc_sig = nan(length(u_ele), length(u_azi));
    
    Acc_spr = nan(length(u_ele), length(u_azi));
    Acc_snr = zeros(length(u_ele), length(u_azi));
    
    m_Acc = nan(length(wind_time), length(u_ele), length(u_azi));
    Acc_fit = nan(length(wind_time), length(u_ele), length(u_azi));
    for j=1:length(u_ele),
        for k=1:length(u_azi),
            if j == 1 && k > 1,
                continue;
            end
            
            if j == length(u_ele) && k > 1,
                continue;
            end
            
            %Accel Mean
            curr_cond = squeeze(accel_dat(:, ele == u_ele(j) & ...
                                             azi == u_azi(k)));
            AccArray{j,k} = curr_cond;
            m_Acc(:,j,k) = nanmean(curr_cond,2);

            %Fit Acc1
            curr_dir = m_Acc(:,j,k);


            %Normalise Profiles 
            t_A = (max(curr_dir)-min(curr_dir))/2;
            t_c = mean(curr_dir);
            time_profile = (curr_dir-t_c)/t_A;

            %Match time profile to derivative of gaussian
            [~, max_peak] = max(time_profile);
            [~, min_peak] = min(time_profile);

            sig = 1;
            if max_peak - min_peak > 0,
                sig = -1;
            end
            
            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);
            
            %Fit time profile
            LB = [0.5 0.5*sig_t];
            UB = [1.5 2*sig_t];
            
            if ~any(isnan(time_profile)),
                recon_t = lsqcurvefit('d_gauss', [mu_t sig_t], ...
                            wind_time, sig*time_profile', LB, UB, options);
                Acc_lag(j,k) = recon_t(1);  
                Acc_sig(j,k) = recon_t(2);
                Acc_fit(:,j,k) = t_A*sig*d_gauss(recon_t, wind_time) + t_c;

                Acc_snr(j,k) = norm(m_Acc(:,j,k) - mean(m_Acc(:,j,k)))/...
                                norm(m_Acc(:,j,k) - Acc_fit(:,j,k));
            end 
        end
    end
    
    if nanmean(m_Acc(:)) > 10^4,
         pool_lag(i) = nanmedian(Acc_lag(Acc_snr > 1));
    end

    %continue;
    
    max_a = nanmax(m_Acc(:));
    min_a = nanmin(m_Acc(:));
    
    scrsz = get(0,'ScreenSize');
    h = figure('Position', scrsz, 'Renderer', 'painters');
    for j = 1:length(u_ele),
        for k = 1:length(u_azi),
            if j == 1 && k > 1,
                continue;
            end
            
            if j == length(u_ele) && k > 1,
                continue;
            end

            subplot(length(u_ele), length(u_azi), (length(u_ele)-j)*length(u_azi) + k);
            plot(wind_time, squeeze(m_Acc(:,j,k)), 'b');
            hold on;
            plot(wind_time, squeeze(Acc_fit(:,j,k)), 'r');
            hold off;
            line([1 1], [min_a max_a], 'color', 'k');
            ylim([min_a max_a]);
            title({['lag: ' num2str(Acc_lag(j,k))], ...
                   ['SNR : ' num2str(Acc_snr(j,k))]});

            subplot(length(u_ele), length(u_azi), 2);
            axis off;
            tabstring1 = ['Trial ' num2str(i) ': ' cur_file_name];
            text(0, 1, tabstring1, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', 10);
        end
    end
    
    set(h, 'PaperPosition', [0 0 11 8.5]);
    set(h, 'PaperSize', [11 8.5]);
    saveas(h, [cur_file_name '.pdf'], 'pdf');
    close(h);
end

% fid = fopen('OA_correct.txt', 'w');
% for i=1:length(pool_filename),
%     fprintf(fid, '%s %s %d\n', pool_dir{i}, pool_filename{i}, pool_lag(i));
% end