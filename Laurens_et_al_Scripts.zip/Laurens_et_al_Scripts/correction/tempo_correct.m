clear;

addpath(genpath(['..' filesep '..' filesep 'Toolbox']));
addpath(genpath(['..' filesep 'htb']));
addpath(genpath(['..' filesep 'misc']));

sel_brainarea = 'MSTd';

[~, txt, ~] = xlsread(['..' filesep '..' filesep '..' filesep 'Data' ...
                        filesep 'MOOG' filesep 'VN_CN.xls']);
path_name = txt(:, 1);
file_name = txt(:, 2);
chan = txt(:,3);
brainarea = txt(:,4);

pool_lag = nan(length(chan), 1);
pool_filename = cell(length(chan), 1);
pool_dir = cell(length(chan), 1);
pool_chan = nan(length(chan), 1);

mu_t = 1;
sig_t = sqrt(sqrt(2))/6;

for i = 14:length(chan),
    if ~strcmp(sel_brainarea, brainarea{i}),
        continue;
    end
    
    pool_filename{i} = ' ';
    
    cur_chan = str2num(chan{i}(2));

    cur_path_name = ['..' filesep '..' filesep '..' filesep ...
                     'Data'  filesep 'MOOG' filesep path_name{i}];
    cur_file_name = file_name{i};

    disp([num2str(i) ', ' cur_file_name(1:end-4) 'c' num2str(cur_chan) '.mat']);
    
    pool_filename{i} = [cur_file_name(1:end-4) 'c' num2str(cur_chan) '.mat'];
    pool_dir{i} = cur_path_name;
    
    ProtocolDefs;
    try
        [~, data, ~, ~] = LoadTEMPOData(cur_path_name, cur_file_name);
    
        acc_data1 = data.eye_data(5,:,:);
        acc_data2 = data.eye_data(6,:,:);
    catch
        disp('No Data!');
        continue;
    end

    azi = data.moog_params(AZIMUTH,:,MOOG)/180*pi;
    ele = data.moog_params(ELEVATION,:,MOOG)/180*pi;

    u_azi = [0 45 90 135 180 225 270 315]'/180*pi;
    u_ele = [-90 -45 0 45 90]'/180*pi; 

    AccArray1 = cell(length(u_ele), length(u_azi));
    AccArray2 = cell(length(u_ele), length(u_azi));
    
    Acc1_lag = nan(length(u_ele), length(u_azi));
    Acc2_lag = nan(length(u_ele), length(u_azi));
    Acc1_sig = nan(length(u_ele), length(u_azi));
    Acc2_sig = nan(length(u_ele), length(u_azi));
    
    Acc1_spr = nan(length(u_ele), length(u_azi));
    Acc2_spr = nan(length(u_ele), length(u_azi));
    Acc1_snr = zeros(length(u_ele), length(u_azi));
    Acc2_snr = zeros(length(u_ele), length(u_azi));
    
    m_Acc1 = nan(400, length(u_ele), length(u_azi));
    m_Acc2 = nan(400, length(u_ele), length(u_azi));
    Acc1_fit = nan(400, length(u_ele), length(u_azi));
    Acc2_fit = nan(400, length(u_ele), length(u_azi));
    
    for j=1:length(u_ele),
        for k=1:length(u_azi),
            if j == 1 && k > 1,
                continue;
            end
            
            if j == length(u_ele) && k > 1,
                continue;
            end
            
            curr_cond = squeeze(acc_data1(:,:, ele == u_ele(j) & ...
                                               azi == u_azi(k)));
            AccArray1{j,k} = curr_cond(201:600,:);
            m_Acc1(:,j,k) = mean(curr_cond(201:600,:),2);
           
            curr_cond = squeeze(acc_data2(:,:, ele == u_ele(j) & ...
                                               azi == u_azi(k)));
            AccArray2{j,k} = curr_cond(201:600,:);
            m_Acc2(:,j,k) = mean(curr_cond(201:600,:),2);
            
            %Fit Acc1
            curr_dir = m_Acc1(:,j,k);
            delta_t = 2/size(m_Acc1,1);
            curr_time = (0:delta_t:2-delta_t);

            %Normalise Profiles 
            t_A = (max(curr_dir)-min(curr_dir))/2;
            t_c = mean(curr_dir);
            time_profile = (curr_dir-t_c)/t_A;

            %Match time profile to derivative of gaussian
            [~, max_peak] = max(time_profile);
            [~, min_peak] = min(time_profile);

            sig = 1;
            if max_peak - min_peak > 0,
                sig = -1;
            end
            
            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);
            
            %Fit time profile
            LB = [0.5 0.5*sig_t];
            UB = [1.5 2*sig_t];
            recon_t = lsqcurvefit('d_gauss', [mu_t sig_t], ...
                        curr_time, sig*time_profile', LB, UB, options);
            Acc1_lag(j,k) = recon_t(1);  
            Acc1_sig(j,k) = recon_t(2);
            Acc1_fit(:,j,k) = t_A*sig*d_gauss(recon_t, curr_time) + t_c;

            Acc1_snr(j,k) = norm(m_Acc1(:,j,k) - mean(m_Acc1(:,j,k)))/...
                            norm(m_Acc1(:,j,k) - Acc1_fit(:,j,k));
            
            %Fit Acc2
            curr_dir = m_Acc2(:,j,k);
            delta_t = 2/size(m_Acc2,1);
            curr_time = (0:delta_t:2-delta_t);

            %Normalise Profiles 
            t_A = (max(curr_dir)-min(curr_dir))/2;
            t_c = mean(curr_dir);
            time_profile = (curr_dir-t_c)/t_A;

            %Match time profile to derivative of gaussian
            mu_t = 1;
            sig_t = sqrt(sqrt(2))/6;
            
            [~, max_peak] = max(time_profile);
            [~, min_peak] = min(time_profile);

            sig = 1;
            if max_peak - min_peak > 0,
                sig = -1;
            end
            
            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);
            
            %Fit time profile
            LB = [0.5 0.5*sig_t];
            UB = [1.5 2*sig_t];
            recon_t = lsqcurvefit('d_gauss', [mu_t sig_t], ...
                        curr_time, sig*time_profile', LB, UB, options);
            Acc2_lag(j,k) = recon_t(1);  
            Acc2_sig(j,k) = recon_t(2);        
            Acc2_fit(:,j,k) = t_A*sig*d_gauss(recon_t, curr_time) + t_c;

            Acc2_snr(j,k) = norm(m_Acc2(:,j,k) - mean(m_Acc2(:,j,k)))/...
                            norm(m_Acc2(:,j,k) - Acc2_fit(:,j,k));
        end
    end
    
    Acc_lag = [Acc1_lag Acc2_lag];
    Acc_snr = [Acc1_snr Acc2_snr];

    if nanmean(m_Acc1(:)) > 10 && nanmean(m_Acc2(:)) > 10,
       pool_lag(i) = nanmedian(Acc_lag(Acc_snr > 1));
    end
        
    continue;
    
    max_a = nanmax([m_Acc1(:); m_Acc2(:)]);
    min_a = nanmin([m_Acc1(:); m_Acc2(:)]);
    
    scrsz = get(0,'ScreenSize');
    h = figure('Position', scrsz, 'Renderer', 'painters');
    for j = 1:length(u_ele),
        for k = 1:length(u_azi),
            if j == 1 && k > 1,
                continue;
            end
            
            if j == length(u_ele) && k > 1,
                continue;
            end

            subplot(length(u_ele), length(u_azi), (length(u_ele)-j)*length(u_azi) + k);
            plot(curr_time, squeeze(m_Acc1(:,j,k)), 'b');
            hold on;
            plot(curr_time, squeeze(Acc1_fit(:,j,k)), 'r');
            hold off;
            xlim([0 2]);
            ylim([min_a max_a]);
            title({['lag: ' num2str(Acc1_lag(j,k))], ...
                   ['SNR : ' num2str(Acc1_snr(j,k))]});

            subplot(length(u_ele), length(u_azi), 2);
            axis off;
            tabstring1 = ['Trial ' num2str(i) ': ' cur_file_name];
            text(0, 1, tabstring1, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', 10);
        end
    end
    
    max_a = nanmax([m_Acc1(:); m_Acc2(:)]);
    min_a = nanmin([m_Acc1(:); m_Acc2(:)]);
    
    scrsz = get(0,'ScreenSize');
    h = figure('Position', scrsz, 'Renderer', 'painters');
    for j = 1:length(u_ele),
        for k = 1:length(u_azi),
            if j == 1 && k > 1,
                continue;
            end
            
            if j == length(u_ele) && k > 1,
                continue;
            end

            subplot(length(u_ele), length(u_azi), (length(u_ele)-j)*length(u_azi) + k);
            plot(curr_time, squeeze(m_Acc2(:,j,k)), 'g');
            hold on;
            plot(curr_time, squeeze(Acc2_fit(:,j,k)), 'k');
            hold off;
            xlim([0 2]);
            ylim([min_a max_a]);
            title({['lag: ' num2str(Acc2_lag(j,k))], ...
                   ['SNR : ' num2str(Acc2_snr(j,k))]});

            subplot(length(u_ele), length(u_azi), 2);
            axis off;
            tabstring1 = ['Trial ' num2str(i) ': ' cur_file_name];
            text(0, 1, tabstring1, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', 10);
        end
    end
end

fid = fopen([sel_brainarea '_correct.txt'], 'w');
for i=1:length(pool_filename),
    fprintf(fid, '%s %s %d %d\n', pool_dir{i}, pool_filename{i}, ...
                                  pool_lag(i), pool_chan(i));
end