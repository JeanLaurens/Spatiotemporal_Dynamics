clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('htb'));
addpath(genpath('modelS2H'));

BRAIN_AREA = 'OA';
PATH = (['..' filesep '..' filesep '..' filesep 'Poster_Output' filesep ...
         'S2H_Output_' BRAIN_AREA '_c' filesep]);
TIMEPATH = (['..' filesep '..' filesep '..' filesep 'Paper_Output' filesep ...
             'Time_Correction' filesep]);
data_dir = dir([PATH '*.mat']);

fid = fopen([TIMEPATH BRAIN_AREA '_correct.csv'], 'r');
t = textscan(fid, '%s %f %d\n');
fclose(fid);
pool_lag = t{2};
pool_filename = t{1};
pool_machine = t{3};

default_lag = [nanmedian(pool_lag) nanmedian(pool_lag(pool_machine == 1)) ...
               nanmedian(pool_lag(pool_machine == 2))];
disp(default_lag);           

time_correct = zeros(length(data_dir), 1);
for i=1:length(data_dir),
    disp([num2str(i), ', ' data_dir(i).name]);
    
    idx = find(ismember(pool_filename, data_dir(i).name));
    if isempty(idx),
        continue;
    else
        if isnan(pool_lag(idx)),
            time_correct(i) = default_lag(pool_machine(idx)+1) - 1;
        else
            time_correct(i) = pool_lag(idx) - 1;
        end
    end
end

save([TIMEPATH BRAIN_AREA '_correct_c.mat'], 'time_correct');