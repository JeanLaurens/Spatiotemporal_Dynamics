addpath(genpath(['..' filesep '..' filesep 'Toolbox']));

PATH = (['..' filesep '..' filesep '..' filesep ...
         'Data' filesep 'Xiongjie_Good' filesep]);
data_dir = dir([PATH 'm*']);
disp(size(data_dir));
for z=length(data_dir),
    disp([num2str(z), ', ' data_dir(z).name]);
    
    spikefile = [PATH data_dir(i).name filesep 'ALLspikes.txt'];
    parafile = [PATH data_dir(i).name filesep 'parameter.txt'];
    allspikes = dlmread(spikefile);

    try
        parameter = dlmread(parafile,'\t',1,0);
    catch
        parameter = dlmread(parafile);
    end

    trialstarttime = parameter(:,4);
    alldata = convert(allspikes, trialstarttime);

    cand_trials = parameter(:,6);
    good_trials = find(cand_trials > 0);

    azi = parameter(good_trials,3)/180*pi;
    ele = parameter(good_trials,2)/180*pi;
    spike_data = alldata(:,:,good_trials);

    u_azi = unique(azi);
    u_ele = unique(ele);
    u_azi = u_azi(2:end);
    u_ele = u_ele(2:end);
    u_azi = [u_azi; 2*pi];

    num_samples = size(spike_data,2);

    Step = 25;
    wind_time = ((0:Step:5000)-995)/1000;
    wind_time = wind_time(1:end-1);
    lo_b = find(wind_time > -1, 1, 'first');
    up_b = find(wind_time < 4, 1, 'last');
    time = wind_time(lo_b:up_b);

    SpikeArray = cell(length(u_ele), length(u_azi));
    SpikeCount_Trial = cell(length(u_ele), length(u_azi));
    psth = zeros(length(u_azi), length(u_ele), ...
                 length(time));
    raw_psth = zeros(length(u_azi), length(u_ele), ...
                         length(time));

    for j=1:length(u_ele),
        for i=1:length(u_azi),
            curr_cond = squeeze(spike_data(:,:, ele == u_ele(j) & ...
                                                azi == u_azi(i)));
            SpikeArray{j,i} = curr_cond;
            num_wind = floor(num_samples/Step);

            SpikeCount_Trial{j,i} = zeros(num_wind, size(curr_cond,2));
            for k=1:num_wind,
                CurrentValue = curr_cond((k-1)*Step+1:k*Step,:);
                CurrentSpikeCount = sum(CurrentValue)*1000/Step;
                SpikeCount_Trial{j,i}(k,:) = CurrentSpikeCount;                
            end

           PSTH_tmp = squeeze(mean(SpikeCount_Trial{j,i},2));
           raw_psth(i,j,:) = PSTH_tmp(lo_b:up_b);
           half_wind = 4;
           g = normpdf(-half_wind:half_wind, 0, half_wind);
           fil = g/sum(g);
           data = PSTH_tmp(lo_b:up_b);
           obj.psth(i,j,:) = filter(fil, 1, data);
           %obj.psth(i,j,:) = PSTH_tmp(lo_b:up_b); 
        end
    end

    lo_b = find(time > -0.2, 1, 'first');
    up_b = find(time < 2.2, 1, 'last');
    time = time(lo_b:up_b);
    psth = psth(:, :, lo_b+half_wind:up_b+half_wind);
    raw_psth = raw_psth(:, :, lo_b:up_b);

    for i=1:length(u_azi),
        psth(i,1,:) = psth(1,1,:);
        psth(i,end,:) = psth(1,end,:);

        raw_psth(i,1,:) = raw_psth(1,1,:);
        raw_psth(i,end,:) = raw_psth(1,end,:);
    end

    psth(end,:,:) = psth(1,:,:);
    raw_psth(end,:,:) = raw_psth(1,:,:);
end