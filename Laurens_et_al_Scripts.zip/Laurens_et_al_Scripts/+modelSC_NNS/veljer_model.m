function r = veljer_model(param, coord)
    u_ele = coord(1:5);
    u_azi = coord(6:14);
    time = coord(15:end);
    
    stim_sig = sqrt(sqrt(2))/6;
    
    %velocity model
    gauss_time = gauss([param(3) stim_sig], time);
    v_ele_azi = cos_tuning_o(param(4:5), [u_ele; u_azi]) + param(6);
    v_ele_azi = reshape(v_ele_azi, length(u_azi), length(u_ele));

    %jerk model
    d2_gauss_time = d2_gauss([param(3) stim_sig], time);
    j_ele_azi = cos_tuning_o(param(7:8), [u_ele; u_azi]) + param(9);
    j_ele_azi = reshape(j_ele_azi, length(u_azi), length(u_ele));
    
    %compute results
    r = zeros(size(v_ele_azi,1), size(v_ele_azi,2), length(gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            r(i,j,:) = param(1)* ...
                       (param(10)*v_ele_azi(i,j)*gauss_time + ...
                       (1-param(10))*j_ele_azi(i,j)*d2_gauss_time) + ...
                       param(2);
        end
    end

    r = packPSTH(r);
end