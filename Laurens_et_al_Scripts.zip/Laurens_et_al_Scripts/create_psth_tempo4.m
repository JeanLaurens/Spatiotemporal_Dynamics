clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('htb'));
addpath(genpath('modelS2H'));

DATA_NAME = ['..' filesep '..' filesep 'Data' filesep 'MOOG' filesep];
[chan, txt, ~] = xlsread([DATA_NAME 'spikelets.xls']);

dir_name = txt(:,1);
file_name = txt(:,2);
brain_area = txt(:,4);

pool_filename = cell(length(file_name), 1);

for i = 1:length(chan),
    pool_filename{i} = ' ';
    
    cur_chan = 5; %chan(i);    
    cur_file_name = file_name{i};
    cur_dir_name = dir_name{i};
    
    disp([num2str(i) ', ' cur_file_name(1:end-4) 'c' num2str(cur_chan) '.mat']);
    pool_filename{i} = [cur_file_name(1:end-4) 'c' num2str(cur_chan) '.mat'];
    [~, data, ~, ~] = LoadTEMPOData([DATA_NAME cur_dir_name filesep] , cur_file_name);

    p = PSTH('sheng', 1, data, cur_chan);
    %p.plotPSTH(cur_file_name, ['..' filesep '..' filesep' 'Paper_Figures' filesep]);

    if ~p.rej,
        save(['..' filesep '..' filesep 'Paper_Input' filesep 'psth_' brain_area{i} '4_c' filesep ...
            cur_file_name(1:end-4) 'c' num2str(cur_chan) '.mat'], 'p');
    end
end