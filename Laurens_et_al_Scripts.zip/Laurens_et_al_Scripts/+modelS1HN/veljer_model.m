function r = veljer_model(param, coord)
    u_ele = coord(1:5);
    u_azi = coord(6:14);
    time = coord(15:end);
    
    %velocity model
    gauss_time = gauss_n(param(2:4), time);
    v_ele_azi = sh_recon(param(5:7), 1, u_azi, u_ele+pi/2) + param(8);

    %jerk model
    d2_gauss_time = d2_gauss_n(param(2:4), time);
    j_ele_azi = sh_recon(param(9:11), 1, u_azi, u_ele+pi/2) + param(12);

    %compute results
    r = zeros(size(v_ele_azi,1), size(v_ele_azi,2), length(gauss_time));
    for i=1:size(r,1),
        for j=1:size(r,2),
            r(i,j,:) = v_ele_azi(i,j)*gauss_time + ...
                       j_ele_azi(i,j)*d2_gauss_time + ...
                       param(1);
        end
    end

    r = packPSTH(r);
end