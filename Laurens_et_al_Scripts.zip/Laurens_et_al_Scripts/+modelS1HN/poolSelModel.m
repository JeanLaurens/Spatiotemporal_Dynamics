classdef poolSelModel
    properties
        pool_bic
        pool_bic_type
        
        pool_r2
        pool_weights
        
        pool_v_tuning
        pool_a_tuning
        pool_j_tuning
        
        pool_mu_t
        pool_sig_t
        
        time
        
        pool_cv
    end
    
    methods
        function obj = poolSelModel(PATH)
            data_dir = dir([PATH '*.mat']);
            
            obj.pool_bic = zeros(length(data_dir), 1);
            obj.pool_bic_type = zeros(length(data_dir), 1);
            
            obj.pool_r2 = zeros(length(data_dir), 1);
            obj.pool_weights = zeros(length(data_dir), 3);
            
            obj.pool_mu_t = zeros(length(data_dir), 1);
            obj.pool_sig_t = zeros(length(data_dir), 1);
            
            obj.pool_v_tuning = zeros(length(data_dir), 2);
            obj.pool_a_tuning = zeros(length(data_dir), 2);
            obj.pool_j_tuning = zeros(length(data_dir), 2);

            obj.pool_cv = zeros(length(data_dir), 1);
            
            PATH_CV = (['..' filesep '..' filesep 'Data' filesep 'Xiongjie_Good' filesep]);
            data_dir_cv = dir([PATH_CV 'm*']);

            for i=1:length(data_dir),
                p = PSTH('xiongjie', [PATH_CV data_dir_cv(i).name filesep]);
                obj.pool_cv(i) = p.cv_star;
                
                dat = load([PATH filesep data_dir(i).name]);
                      
                sm = selModel(dat.p, dat.fv, dat.fa, dat.fj, ...
                              dat.fva, dat.fvj, dat.faj, dat.fvaj);
                
                if i == 1,
                    obj.time = sm.time;
                end
                          
                obj.pool_bic(i) = sm.bic;
                obj.pool_bic_type(i) = sm.bic_type;
                obj.pool_r2(i) = 1-min(sm.bic_rss)/sm.bic_tss;
                obj.pool_weights(i,:) = sm.bic_w;
                
                obj.pool_mu_t(i) = sm.bic_mu_t;
                obj.pool_sig_t(i) = sm.bic_sig_t;
                
                obj.pool_v_tuning(i,:) = [sm.bic_azi(1) sm.bic_ele(1)];
                obj.pool_a_tuning(i,:) = [sm.bic_azi(2) sm.bic_ele(2)];
                obj.pool_j_tuning(i,:) = [sm.bic_azi(3) sm.bic_ele(3)];
            end
        end
        
        function plotTypes(obj)
            types = zeros(7,1);
         
            for i=1:length(obj.pool_bic_type),
                switch obj.pool_bic_type(i),
                    case 1
                        types(1) = types(1)+1;
                        
                    case 2
                        types(2) = types(2)+1;
                        
                    case 3
                        types(3) = types(3)+1;
                        
                    case 4
                        types(4) = types(4)+1;
                        
                    case 5
                        types(5) = types(5)+1;
                        
                    case 6
                        types(6) = types(6)+1; 
                        
                    case 7
                        types(7) = types(7)+1;    
                end
            end
            
            
            bar(types);
            box off;
            axis tight;
            xlabel('Types');
            ylabel('Count');
        end
        
        function plotBIC(obj, name)
            [c, bins] = hist(obj.pool_bic, 10);
            bar(bins, c);
            xlabel('BIC');
            ylabel('Count');
            box off;
            axis tight;
            title(name);
        end
        
        function plotR2(obj)
            bins = 0:0.05:1;
            c = histc(obj.pool_r2, bins);
            bar(bins, c);
            xlabel('R2');
            ylabel('Count');
            box off;
            axis tight;
        end
        
        function plotWeightsTurnplot(obj, name)
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            [x, y] = terncoords(obj.pool_weights(:,1), ...
                                obj.pool_weights(:,2), ...
                                obj.pool_weights(:,3));
            ternaxes(5);
            [~, i] = sort(obj.pool_cv);
            scatter(x(i), y(i), 100, log(obj.pool_cv(i)), 'filled');
            
            if ~(sum(obj.pool_cv) == 0),
               cb = colorbar;
                ytick = 0.02:.02:0.2;
                set(cb, 'YTick', log(ytick));
                set(cb, 'YTickLabel', ytick);
            end
            
            axis equal;
            ternlabel('Vel', 'Acc', 'Jer');
            title(name);
            
            set(gca, 'fontSize', 12);
            set(findall(gcf,'type','text'),'fontSize',24);
        end
        
        function plotSpatialWeights(obj)
            bins = 0:0.05:1;
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            set(gca,'FontSize',20);
            subplot(2,3,1);
            c = histc(squeeze(obj.pool_weights(:,1)), bins);
            bar(bins, c);
            xlabel('Vel Weights');
            ylabel('Count');
            box off;
            axis tight;
            set(gca, 'fontSize', 12);
            
            subplot(2,3,2);
            c = histc(squeeze(obj.pool_weights(:,2)), bins);
            bar(bins, c);
            xlabel('Acc Weights');
            ylabel('Count');
            box off;
            axis tight;
            set(gca, 'fontSize', 12);
            
            subplot(2,3,3);
            c = histc(squeeze(obj.pool_weights(:,3)), bins);
            bar(bins, c);
            xlabel('Jer Weights');
            ylabel('Count');
            box off;
            axis tight;
            set(gca, 'fontSize', 12);

            set(findall(gcf,'type','text'),'fontSize',24);
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(2,1,1);
            tmp = obj.pool_weights(:,3)./obj.pool_weights(:,2);
            plot(obj.pool_cv, tmp, '*');
            [r, ~, p] = spear(obj.pool_cv, tmp);
            title(['Spearman correlation: ' num2str(r), ', P value: ' num2str(p)]);
            ylabel('Jer/Acc Weights');
            xlabel('CV*');
            box off;
            axis tight;
            set(gca, 'fontSize', 12);
            
            subplot(2,1,2);
            tmp = obj.pool_weights(:,1)./obj.pool_weights(:,2);
            plot(obj.pool_cv, tmp, '*');
            [r, ~, p] = spear(obj.pool_cv, tmp);
            title(['Spearman correlation: ' num2str(r), ', P value: ' num2str(p)]);
            ylabel('Vel/Acc Weights');
            xlabel('CV*');
            box off;
            axis tight;
            set(gca, 'fontSize', 12);

            set(findall(gcf,'type','text'),'fontSize',24);
        end
        
        function plotTimeParam(obj)
            stim_sig = sqrt(sqrt(2))/6;
            stim_mu = 1 + 0.115;
            %stim_mu = 1;
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(2,2,1);
            bins = 0.5:0.01:1.5;
            c = histc(obj.pool_mu_t, bins);
            bar(bins, c);
%             hold on;
%             plot(obj.pool_mu_t, 0, 'r*');
%             [~, i] = sort(obj.pool_cv);
%             scatter(obj.pool_mu_t(i), zeros(size(obj.pool_mu_t)), ...
%                     100, obj.pool_cv(i), 'filled');
%             hold off;
            xlabel('Time Lags(s)');
            ylabel('Count');
            box off;
            axis tight;
            q = quantile(obj.pool_mu_t, 3);
            line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
            line(q(2)*[1 1], ylim, 'Color', 'r');
            line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
            line((q(3)+1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
            line((q(1)-1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
            line(stim_mu*[1 1], ylim, 'Color', 'b');
            set(gca,'fontSize',12);
            
            subplot(2,2,2);
            bins = 0:0.01:1;
            c = histc(obj.pool_sig_t, bins);
            bar(bins, c);
%             hold on;
%             [~, i] = sort(obj.pool_cv);
%             scatter(obj.pool_sig_t(i), zeros(size(obj.pool_sig_t)), ...
%                     100, obj.pool_cv(i), 'filled');
%             hold off;
            xlabel('Time Spreads(s)');
            ylabel('Count');
            box off;
            axis tight;
            q = quantile(squeeze(obj.pool_sig_t), 3);
            line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
            line(q(2)*[1 1], ylim, 'Color', 'r');
            line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
            line(stim_sig*[1 1], ylim, 'Color', 'b');
            set(gca,'fontSize',12);
            %line(0.5*stim_sig*[1 1], ylim, 'Color', 'b');
            %line(1.5*stim_sig*[1 1], ylim, 'Color', 'b');
            
            subplot(2,2,3);
            hold on;
            for i=1:length(obj.pool_mu_t),
                plot(obj.time, gauss([obj.pool_mu_t(i) obj.pool_sig_t(i)], obj.time));
            end
            plot(obj.time, gauss([stim_mu stim_sig], obj.time), 'r', 'LineWidth', 2);
            hold off;
            box off;
            axis tight;
            xlabel('Time (s)');
            set(gca,'fontSize',12);
            
            subplot(2,2,4);
            hold on;
            for i=1:length(obj.pool_mu_t),
                plot(obj.time, gauss([stim_mu obj.pool_sig_t(i)], obj.time));
            end
            plot(obj.time, gauss([stim_mu stim_sig], obj.time), 'r', 'LineWidth', 2);
            hold off;
            box off;
            axis tight;
            xlabel('Time (s)');
            set(gca,'fontSize',12);
            
            set(findall(gcf,'type','text'),'fontSize',24);
        end
        
        function plotTuning2(obj)
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(2,3,1);
            scatter(obj.pool_v_tuning(:,1), ...
                    obj.pool_v_tuning(:,2)-90, ...
                    100, log(obj.pool_cv), 'filled');
            axis equal;
            box off;
            if ~(sum(obj.pool_cv) == 0),
                cb = colorbar;
                ytick = 0.02:.02:0.2;
                set(cb, 'YTick', log(ytick));
                set(cb, 'YTickLabel', ytick);
            end
            xlim([0 360]);
            ylim([-90 90]);
            xlabel('Azimuith');
            ylabel('Elevation');
            title('Velocity');
            set(gca, 'fontSize', 12);
            
            subplot(2,3,2);
            scatter(obj.pool_a_tuning(:,1), ...
                    obj.pool_a_tuning(:,2)-90, ...
                    100, log(obj.pool_cv), 'filled');
            axis equal;
            box off;
            if ~(sum(obj.pool_cv) == 0),
                cb = colorbar;
                ytick = 0.02:.02:0.2;
                set(cb, 'YTick', log(ytick));
                set(cb, 'YTickLabel', ytick);
            end
            xlim([0 360]);
            ylim([-90 90]);
            xlabel('Azimuith');
            ylabel('Elevation');
            title('Acceleration');
            set(gca, 'fontSize', 12);
            
            subplot(2,3,3);
            scatter(obj.pool_j_tuning(:,1), ...
                    obj.pool_j_tuning(:,2)-90, ...
                    100, log(obj.pool_cv), 'filled');
            axis equal;
            box off;
            if ~(sum(obj.pool_cv) == 0),
                cb = colorbar;
                ytick = 0.02:.02:0.2;
                set(cb, 'YTick', log(ytick));
                set(cb, 'YTickLabel', ytick);
            end
            xlim([0 360]);
            ylim([-90 90]);
            xlabel('Azimuith');
            ylabel('Elevation');
            title('Jerk');
            set(gca, 'fontSize', 12);

            set(findall(gcf,'type','text'),'fontSize',24);
        end

        function plotTuning(obj)
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(2,3,1);
            bins = 0:15:180;
            dif_ang_v = 180-abs(obj.pool_v_tuning2(:,2)/pi*180-180);
            hc = histc(dif_ang_v, bins);
            bar(bins, hc, 'histc');
            hold on;
            plot(dif_ang_v, 0, 'r*');
            hold off;
            xlim([0 180]);
            box off;
            line([30 30], ylim, 'color', 'k');
            line([45 45], ylim, 'color', 'k');
            line([60 60], ylim, 'color', 'k');
            xlabel('Elevation');
            title('Velocity');
            
            subplot(2,3,2);
            dif_ang_a = 180-abs(obj.pool_a_tuning2(:,2)/pi*180-180);
            hc = histc(dif_ang_a, bins);
            bar(bins, hc, 'histc');
            hold on;
            plot(dif_ang_a, 0, 'r*');
            hold off;
            xlim([0 180]);
            box off;
            line([30 30], ylim, 'color', 'k');
            line([45 45], ylim, 'color', 'k');
            line([60 60], ylim, 'color', 'k');
            xlabel('Elevation');
            title('Acceleration');
            
            subplot(2,3,3);
            dif_ang_j = 180-abs(obj.pool_j_tuning2(:,2)/pi*180-180);
            hc = histc(dif_ang_j, bins);
            bar(bins, hc, 'histc');
            hold on;
            plot(dif_ang_j, 0, 'r*');
            hold off;
            xlim([0 180]);
            box off;
            line([30 30], ylim, 'color', 'k');
            line([45 45], ylim, 'color', 'k');
            line([60 60], ylim, 'color', 'k');
            xlabel('Elevation');
            title('Jerk');
        end
    end
end