classdef CVStar
    properties
        cv
        spontanous
    end
    
    methods
        function obj = CVStar(PATH)
            spikefile = [PATH  'ALLspikes.txt'];
            parafile = [PATH  'parameter.txt'];
            spiketime = dlmread(spikefile);

            try
                parameter = dlmread(parafile,'\t', 1, 0);
            catch
                parameter = dlmread(parafile);
            end

            cand_trials = find(parameter(:, 6) == 1);
            sel_trials = parameter(cand_trials, :);

            trialnumber = 1:length(parameter(cand_trials, 1));
            trialstartime = parameter(cand_trials, 4);

            stim = -9999.00000000;
            trial_idx1 = sel_trials(:, 2) == stim;
            trial_idx2 = sel_trials(:, 3) == stim;
            trial_idx = trial_idx1 & trial_idx2;

            trialnumbers = trialnumber(trial_idx);

            obj.cv = 0;
            obj.spontanous = 0;

            for j=1:length(trialnumbers),
                currentonset = trialstartime(trialnumbers(j));
                currentspikeperonset = spiketime - currentonset;
                curentspk = currentspikeperonset((currentspikeperonset>=0)&(currentspikeperonset<=2));

                sortsponspk = sort(curentspk);
                curentisi = diff(sortsponspk);

                misi = mean(curentisi);
                sdisi = std(curentisi);

                isiindex = abs(curentisi - misi) < 20*sdisi;

                isi = curentisi(isiindex);
                misi = mean(isi);
                sdisi = std(isi);

                cvarvar = sdisi/misi ;
                obj.cv = obj.cv + cvtransfer(cvarvar, misi*1000) ;

                obj.spontanous = obj.spontanous + 1/misi;
            end
            
            obj.cv = obj.cv/length(trialnumbers);
            obj.spontanous = obj.spontanous/length(trialnumbers);
        end
    end
end