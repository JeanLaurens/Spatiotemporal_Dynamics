clear;

brain_area = 'MSTd';

OUTPUT_PATH = ['..' filesep '..' filesep 'Poster_Output' filesep 'S2H_Output_' brain_area '_c' filesep];

DATA_PATH = ['..' filesep '..' filesep 'Poster_Output' filesep 'S2H_Output_' brain_area filesep];
COMP_PATH = ['..' filesep '..' filesep 'Poster_Output' filesep 'SC3_Output_' brain_area filesep];
PSTH_PATH = ['..' filesep '..' filesep 'Output' filesep 'psth_' brain_area filesep];


data_dir = dir([DATA_PATH '*.mat']);

for i=1:length(data_dir),
    comp_bool = exist([COMP_PATH data_dir(i).name], 'file');
    psth_bool = exist([PSTH_PATH data_dir(i).name], 'file');
    
    if comp_bool && psth_bool, 
        copyfile([DATA_PATH data_dir(i).name], [OUTPUT_PATH data_dir(i).name], 'f');
    else
        disp([PSTH_PATH data_dir(i).name ' Failed!']);
    end
end

