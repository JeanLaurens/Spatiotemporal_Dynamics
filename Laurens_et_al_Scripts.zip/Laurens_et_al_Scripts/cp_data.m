clear;

data_name = ['..' filesep '..' filesep 'Data' filesep 'MOOG' filesep];
fileID = fopen([data_name 'batch_VIP_Translation.txt']);
textlines = textscan(fileID, '%s', 'Delimiter', '\n');

for i=1:length(textlines{1}),
    textline = textscan(textlines{1}{i}, '%s');
    path_name = textline{1}{1};
    cur_path_name = strrep(path_name, '\', filesep);
    
    cur_file_name = textline{1}{2};
    cur_file_name = cur_file_name(1:end-4);
    cur_file_name = [cur_file_name '.log'];
    
    local_path_name = ['..' filesep '..' filesep cur_path_name(4:end)];
    remote_path_name = [filesep 'mnt' filesep 'primus' filesep 'parent' ...
                        cur_path_name(3:end)];

    if ~exist(local_path_name, 'dir'),
        disp(local_path_name);
        mkdir(local_path_name);
    end
   
    if exist([remote_path_name cur_file_name],'file'),
        copyfile([remote_path_name cur_file_name], ...
                 [local_path_name cur_file_name], 'f'); 
    else
         disp([remote_path_name cur_file_name]);
    end
    %disp([num2str(i) ', ' data_file_name]);
end