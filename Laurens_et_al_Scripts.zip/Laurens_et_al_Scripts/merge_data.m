clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('htb'));
addpath(genpath('modelS2H'));

V_only_name = ['..' filesep '..' filesep 'V_Only' filesep];
V_only_dir = dir(V_only_name);

paper_output_name = ['..' filesep '..' filesep 'Paper_Output' filesep];

for i=3:length(V_only_dir),
    v_name = [V_only_name V_only_dir(i).name];
    v_dir = dir([v_name filesep '*.mat']);
    o_name = [paper_output_name V_only_dir(i).name];
    
    for j=1:length(v_dir),
        dat_v = load([v_name filesep v_dir(j).name]);
        dat_o = load([o_name filesep v_dir(j).name]);
        
        fv = dat_o.fv;
        fa = dat_v.fa;
        fj = dat_o.fj;
        fvj = dat_o.fvj;
        fva = dat_o.fva;
        faj = dat_o.faj;
        fvaj = dat_o.fvaj;
        fpaj = dat_o.fpaj;
        fpvj = dat_o.fpvj;
        fpva = dat_o.fpva;
        fpvaj = dat_o.fpvaj;
        p = dat_o.p;
        
        save(['..' filesep '..' filesep 'New_Data' ...
            filesep V_only_dir(i).name filesep v_dir(j).name], ...
             'p', 'fv', 'fa', 'fj', 'fvj', 'fva', 'faj', ...
             'fvaj', 'fpaj', 'fpvj', 'fpva', 'fpvaj');
    end
end