clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('htb'));
addpath(genpath('psth'));
addpath(genpath('misc'));

OUTPUT_PATH = ['..' filesep '..' filesep 'Figures' filesep 'fakedata_plots' filesep];

PATH_CV = (['..' filesep '..' filesep 'Data' filesep 'Xiongjie_Good' filesep]);
data_dir_cv = dir([PATH_CV 'm*']);

SC_PATH = (['..' filesep '..' filesep 'Output' filesep 'SC2_Output_Xiongjie' filesep]);
sc_data_dir = dir([SC_PATH '*.mat']);

DC_PATH = (['..' filesep '..' filesep 'Output' filesep 'DC5_Output_Xiongjie' filesep]);
dc_data_dir = dir([DC_PATH '*.mat']);

dc_sp_weights = zeros(length(dc_data_dir), 1);

for i=1:length(dc_data_dir),
    p = PSTH('xiongjie', [PATH_CV data_dir_cv(i).name filesep]);
    
    addpath(genpath('modelSC'));
    sc_cur_data = load([SC_PATH sc_data_dir(i).name]);
    rmpath(genpath('modelSC'));
    sc_sm = modelSC.selModel(p, sc_cur_data.fv, sc_cur_data.fa, ...
                             sc_cur_data.fj, sc_cur_data.fva, sc_cur_data.fvj, ...
                             sc_cur_data.faj, sc_cur_data.fvaj);

    addpath(genpath('modelDC'));
    dc_cur_data = load([DC_PATH dc_data_dir(i).name]);
    rmpath(genpath('modelDC'));
    dc_sm = modelDC.selModel(p, dc_cur_data.fv, dc_cur_data.fa, ...
                             dc_cur_data.fj, dc_cur_data.fva, dc_cur_data.fvj, ...
                             dc_cur_data.faj, dc_cur_data.fvaj);
   
    if sc_sm.bic < dc_sm.bic,
        dc_sp_weights(i) = 0; 
    else
        s_data = [dc_sm.u_ele; dc_sm.u_azi]; 
        param = dc_sm.sp_acc_param;
        dc_sp_weights(i) = param(7); 
    end
     
%     s_data = [dc_sm.u_ele; dc_sm.u_azi]; 
%     param = dc_sm.sp_acc_param;
%     dc_sp_weights(i) = param(7); 
    
    if dc_sp_weights(i) > 0.8,
%         addpath(genpath('modelDC'));
%         dc_sm.plotPSTH(i, dc_data_dir(i).name, ['..' filesep '..' filesep ...
%                        'Figures' filesep 'fakedata_plots' filesep]);
%         rmpath(genpath('modelDC'));    
%         continue;
        
        if sc_sm.bic < dc_sm.bic,
            addpath(genpath('modelSC'));
            sc_sm.plotPSTH(i, sc_data_dir(i).name, ['..' filesep '..' filesep ...
                           'Figures' filesep 'fakedata_plots' filesep]);
            rmpath(genpath('modelSC'));          
        else
            addpath(genpath('modelDC'));
            dc_sm.plotPSTH(i, dc_data_dir(i).name, ['..' filesep '..' filesep ...
                           'Figures' filesep 'fakedata_plots' filesep]);
            rmpath(genpath('modelDC'));           
        end
    end
end

return;

scrsz = get(0,'ScreenSize');
figure('Position', scrsz, 'Renderer', 'painters');
h = histc(dc_sp_weights, 0:0.1:1);
bar(0:0.1:1, h);
box off;
axis tight;
xlabel('Weights');
ylabel('Count');
title('VN');