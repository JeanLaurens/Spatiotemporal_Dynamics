clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('model_csdc'));

OUTPUT_PATH = ['..' filesep '..' filesep 'Figures' filesep 'fakedata_plots' filesep];

SC_PATH = (['..' filesep '..' filesep 'Output' filesep 'SC2_Output_Xiongjie' filesep]);
sc_data_dir = dir([SC_PATH '*.mat']);

DC_PATH = (['..' filesep '..' filesep 'Output' filesep 'DCN_Output_Xiongjie' filesep]);
dc_data_dir = dir([DC_PATH '*.mat']);

dc_angle = zeros(length(dc_data_dir), 1);
dc_sp_weights = zeros(length(dc_data_dir), 1);

for i=1:length(dc_data_dir),
%for i = [1 3 6 12 14 18 19 21 22 23 27 28],  
%for i = 1,
    sc_cur_data = load([SC_PATH sc_data_dir(i).name]);
    sc_sm = modelSC.selModel(sc_cur_data.p, sc_cur_data.fv, sc_cur_data.fa, ...
                             sc_cur_data.fj, sc_cur_data.fva, sc_cur_data.fvj, ...
                             sc_cur_data.faj, sc_cur_data.fvaj);

    dc_cur_data = load([DC_PATH dc_data_dir(i).name]);
    dc_sm = modelDC2.selModel(dc_cur_data.p, dc_cur_data.fv, dc_cur_data.fa, ...
                             dc_cur_data.fj, dc_cur_data.fva, dc_cur_data.fvj, ...
                             dc_cur_data.faj, dc_cur_data.fvaj);
    
%     disp(sc_data_dir(i).name);                     
%     disp(['SC Acc: ' num2str(sc_sm.sp_acc_param)]);
%     disp(['DC Acc: ' num2str(dc_sm.sp_acc_param)]);
   
%     s_data = [dc_sm.u_ele; dc_sm.u_azi]; 
    param = dc_sm.sp_acc_param;
%     [~, dc_angle(i)] = d_cos_tuning(param, s_data);

    dc_sp_weights(i) = param(6);
    
    continue;
    
    scrsz = get(0,'ScreenSize');
    h = figure('Position', scrsz, 'Renderer', 'painters');

    subplot(2,4,1);
    contourf(sc_sm.u_ele*180/pi, sc_sm.u_azi*180/pi, sc_sm.sp_acc);
    colorbar('EastOutside');
    box off;
    %title('SC Acc. Spatial Tuning');
    title(['SC: ' num2str(sc_sm.bic)]);
    xlabel('Azimuth (Deg.)');
    ylabel('Elevation (Deg.)');

    subplot(2,4,2);
    contourf(dc_sm.u_ele*180/pi, dc_sm.u_azi*180/pi, dc_sm.sp_acc);
    colorbar('EastOutside');
    box off;
    %title('DC Acc. Spatial Tuning');
    title(['DC: ' num2str(dc_sm.bic)]);
    xlabel('Azimuth (Deg.)');
    ylabel('Elevation (Deg.)');
    
    subplot(2,4,5);
    s_data = [dc_sm.u_ele; dc_sm.u_azi]; 
    sp = d_cos_tuning(dc_sm.sp_acc_param, s_data);
    sc_sp_acc = reshape(sp, length(sc_sm.u_azi), length(sc_sm.u_ele));
    contourf(sc_sm.u_ele*180/pi, sc_sm.u_azi*180/pi, sc_sp_acc);
    colorbar('EastOutside');
    box off;
    title('Original Double Cosine');
    xlabel('Azimuth (Deg.)');
    ylabel('Elevation (Deg.)');

    subplot(2,4,6);
    s_data = [dc_sm.u_ele; dc_sm.u_azi]; 
    param = dc_sm.sp_acc_param;
    sp = d_cos_tuning1(param, s_data);
    dc_sp_acc = reshape(sp, length(dc_sm.u_azi), length(dc_sm.u_ele));
    contourf(dc_sm.u_ele*180/pi, dc_sm.u_azi*180/pi, dc_sp_acc);
    colorbar('EastOutside');
    box off;
    title('Double Cosine First Peak');
    xlabel('Azimuth (Deg.)');
    ylabel('Elevation (Deg.)');
    
    subplot(2,4,7);
    s_data = [dc_sm.u_ele; dc_sm.u_azi]; 
    param = dc_sm.sp_acc_param;
    sp = d_cos_tuning2(param, s_data);
    dc_sp_acc = reshape(sp, length(dc_sm.u_azi), length(dc_sm.u_ele));
    contourf(dc_sm.u_ele*180/pi, dc_sm.u_azi*180/pi, dc_sp_acc);
    colorbar('EastOutside');
    box off;
    title('Double Cosine Second Peak');
    xlabel('Azimuth (Deg.)');
    ylabel('Elevation (Deg.)');
    
    subplot(2,4,8);
    s_data = [dc_sm.u_ele; dc_sm.u_azi]; 
    param = dc_sm.sp_acc_param;
    [r1, ang] = d_cos_tuning1(param, s_data);
    r2 = d_cos_tuning2(param, s_data);
    sp = r1 + r2;
    sp = sp - (max(sp) + min(sp))/2;
    sp = 2*sp/(max(sp) - min(sp));
    sp = sp + param(8);
    dc_sp_acc = reshape(sp, length(dc_sm.u_azi), length(dc_sm.u_ele));
    contourf(dc_sm.u_ele*180/pi, dc_sm.u_azi*180/pi, dc_sp_acc);
    colorbar('EastOutside');
    box off;
    title('Double Cosine Both Peaks');
    xlabel('Azimuth (Deg.)');
    ylabel('Elevation (Deg.)');

    subplot(2,4,3);
    axis off;
    tabstring = ['Trial ' num2str(i) ': ' sc_data_dir(i).name];
    text(0, 1, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', 10);
    param = dc_sm.sp_acc_param;
    param(2) = param(2)*180/pi;
    param(3) = param(3)*180/pi;
    param(5) = param(5)*180/pi;
    param(6) = param(6)*180/pi;
    tabstring2 = sprintf('n: %.4f, a: %.4f, e: %.4f, n2: %.4f, a2: %.4f e2: %.4f, s: %.4f, DC: %.4f' ...
                         , param);
    text(0, 0.5, tabstring2, 'Interpreter','latex', ...
                             'FontName', 'helvetica', 'FontSize', 6);
                         
    tabstring3 = sprintf('Angle: %.4f, Weights %.4f', ang, param(7));
    text(0, 0, tabstring3, 'Interpreter','latex', ...
                           'FontName', 'helvetica', 'FontSize', 10);                     
    
    set(h, 'PaperPosition', [0 0 11 8.5]);
    set(h, 'PaperSize', [11 8.5]);
    saveas(h, [OUTPUT_PATH sc_data_dir(i).name(1:end-4) '.pdf'], 'pdf');
    close(h);
end

%return;
scrsz = get(0,'ScreenSize');
figure('Position', scrsz, 'Renderer', 'painters');
h = histc(dc_sp_weights, 0:0.1:1);
bar(0:0.1:1, h);
xlim([0 1]);
box off;
xlabel('Second Peak Weights');
ylabel('Count');

disp(dc_sp_weights);

return;
h = histc(dc_angle, 0:10:180);
hw = histc(dc_angle(dc_sp_weights > 0.8), 0:10:180);
bar(0:10:180, h);
hold on;
bar(0:10:180, hw, 'FaceColor', 'y');
hold off;
box off;
%line(180/3*[1 1], ylim, 'color', 'k');
%line((180-180/3)*[1 1], ylim, 'color', 'k');
xlabel('Angle (deg.)');
ylabel('Count');
axis tight;