classdef fitVelAcc
    properties
        reps       
        psth
        
        fa
        fv
        
        u_azi
        u_ele
        time
        
        baseline
                
        A
        R_0
        mu_t
        
        v_ele_azi_profile
        v_space_profile
        v_A
        v_n
        v_a_0
        v_e_0

        a_ele_azi_profile
        a_space_profile
        a_A
        a_n
        a_a_0
        a_e_0

        w
        
        init_param
        
        velacc_param
        rand_param
        
        velacc_rss       
        rand_rss
        
        velacc_jac
        rand_jac
    end
    
    methods
        function obj = fitVelAcc(p, reps)
            obj.reps = reps;
            obj.psth = p.psth;
            
            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            obj.baseline = p.baseline;
            
            stim_sig = sqrt(sqrt(2))/6;
            obj.mu_t = 1;
            
            %Compute Spatial Profiles
            gauss_time = gauss([obj.mu_t stim_sig], obj.time)';
            d_gauss_time = d_gauss([obj.mu_t stim_sig], obj.time)';
            
            u1 = gauss_time;
            p = (u1'*d_gauss_time)/(u1'*u1);
            u2 = d_gauss_time - p*u1;
            
            t_psth = obj.psth-obj.baseline;
            obj.v_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            obj.a_ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi),
                    t_profile = squeeze(t_psth(i,j,:));
                    coeff = (pinv([u1 u2])*squeeze(t_profile));
                    obj.v_ele_azi_profile(i,j) = coeff(1)-coeff(2)*p;
                    obj.a_ele_azi_profile(i,j) = coeff(2);
                end
            end

            %Normalise Profiles 
            obj.v_A = (max(obj.v_ele_azi_profile(:))-min(obj.v_ele_azi_profile(:)))/2;                                   
            obj.v_space_profile = obj.v_ele_azi_profile/obj.v_A;           
            
            obj.a_A = (max(obj.a_ele_azi_profile(:))-min(obj.a_ele_azi_profile(:)))/2;                                   
            obj.a_space_profile = obj.a_ele_azi_profile/obj.a_A;

            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);
            
            %Fit spatial profile
            s_data = [obj.u_ele; obj.u_azi];

            LB = [0.001 0 -pi/2];
            UB = [10 2*pi pi/2]; 
            
            [~, max_idx] = max(obj.v_space_profile(:));
            [max_idx_a, max_idx_e] = ind2sub(size(obj.v_space_profile), max_idx);
            param = [0.01 obj.u_azi(max_idx_a) obj.u_ele(max_idx_e)];
            recon_v = lsqcurvefit('cos_tuning', param, s_data, ...
                                  obj.v_space_profile(:), LB, UB, options);
            obj.v_n = recon_v(1);
            obj.v_a_0 = recon_v(2);
            obj.v_e_0 = recon_v(3); 
         
            LB = [0.001 0 -pi/2];
            UB = [10 2*pi pi/2];
            
            [~, max_idx] = max(obj.a_space_profile(:));
            [max_idx_a, max_idx_e] = ind2sub(size(obj.a_space_profile), max_idx);
            param = [0.01 obj.u_azi(max_idx_a) obj.u_ele(max_idx_e)];
            recon_a = lsqcurvefit('cos_tuning', param, s_data, ...
                                  obj.a_space_profile(:), LB, UB, options);
            obj.a_n = recon_a(1);
            obj.a_a_0 = recon_a(2);
            obj.a_e_0 = recon_a(3);
            
            obj.A = obj.v_A+obj.a_A;
            obj.R_0 = obj.baseline;
            obj.w = obj.v_A/obj.A;
            
            %Initial fits
            param = [obj.A, ...    %1
                    obj.R_0, ...   %2
                    obj.mu_t, ...  %3
                    obj.v_n, ...   %4
                    obj.v_a_0, ... %5
                    obj.v_e_0, ... %6
                    obj.a_n, ...   %7
                    obj.a_a_0, ... %8
                    obj.a_e_0, ... %9
                    obj.w];        %10
            
            obj.init_param = zeros(obj.reps+1, length(param));
            obj.init_param = param;
            
            y_data = packPSTH(obj.psth);
            
            LB = [0.25*obj.A, ...  %1  A
                  0, ...           %2  R_0
                  1, ...           %3  mu_t
                  0.001, ...       %4  v_n
                  0, ...           %5  v_a_0
                  -pi/2, ...       %6  v_e_0 
                  0.001, ...       %7  a_n
                  0, ...           %8  a_a_0
                  -pi/2, ...       %9  a_e_0
                  0];              %10 w
            
            UB = [4*obj.A, ...     %1  A
                  300, ...         %2  R_0
                  1.5, ...         %3  mu_t
                  10, ...          %4  v_n
                  2*pi, ...        %5  v_a_0
                  pi/2, ...        %6  v_e_0
                  10, ...          %7  a_n
                  2*pi, ...        %8  a_a_0
                  pi/2, ...        %9  a_e_0
                  1];              %10 w
            
            t_rand_rss = zeros(obj.reps+1,1);
            t_rand_param = zeros(obj.reps+1, length(param));
            t_rand_jac = zeros(obj.reps+1, length(param), length(param));
              
            [t_rand_param(1,:), t_rand_rss(1),~,~,~,~,tmp_jacobian] = ...
            lsqcurvefit('velacc_model', obj.init_param, st_data, y_data, LB, UB, options);
            t_rand_jac(1,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);  

            %Initial Conditions Random Range
            err_range =  0.1*(UB - LB);
            min_param = t_rand_param(1,:);
            UB_param = min_param+err_range;
            LB_param = min_param-err_range;
           
            parfor i=2:obj.reps+1,
                %Randomise Initial Conditions
                seed_param  = unifrnd(LB_param, UB_param);
                
                [t_rand_param(i,:), t_rand_rss(i),~,~,~,~,tmp_jacobian] = ...
                 lsqcurvefit('velacc_model', seed_param, st_data, y_data, LB, UB, options);
                 t_rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
            end
            
            obj.rand_param = t_rand_param;
            obj.rand_rss = t_rand_rss;
            obj.rand_jac = t_rand_jac;
            
            [~,min_idx] = min(obj.rand_rss);
            obj.velacc_param = obj.rand_param(min_idx,:);
            obj.velacc_rss = obj.rand_rss(min_idx);
            obj.velacc_jac = obj.rand_jac(min_idx,:,:);
        end
        
        function plotPSTH(obj, trial_name, page_num, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];           
            
            init_fit = velacc_model(obj.init_param(1,:), st_data);
            velacc_fit = velacc_model(obj.velacc_param, st_data);

            init_fit = unpackPSTH(init_fit, size(obj.psth));
            velacc_fit = unpackPSTH(velacc_fit, size(obj.psth));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(init_fit(i,j,:)), 'g');
                    plot(obj.time, squeeze(velacc_fit(i,j,:)), 'k');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page_num) ': ' trial_name];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                 'FontName', 'helvetica', 'FontSize', 12);
             
            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end
        
        function plotReconPSTH(obj)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            gauss_time = gauss([obj.mu_t obj.sig_t], obj.time);
            param = [obj.n obj.a_0 obj.e_0 ...
                     obj.n2 obj.a2_0 obj.e2_0 ...
                     obj.s_A2 obj.DC+obj.DC2];
            sp = d_cos_tuning(param, st_data);
            sp = reshape(sp, length(obj.u_azi), length(obj.u_ele));

            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, obj.t_A*gauss_time *...
                                   obj.s_A*sp(i,j) + obj.baseline, 'g');       
                    plot(obj.time, obj.t_A*gauss_time * ...
                                   obj.ele_azi_profile(i,j) + ...
                                   obj.baseline, 'b');          
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
        end
        
        function printVal(obj)
            disp('Velocity + Acceleration');
            disp(['A    : ' num2str(obj.velacc_param(1))]);
            disp(['R_0  : ' num2str(obj.velacc_param(2))]);
            disp(['mu_t : ' num2str(obj.velacc_param(3))]);
            disp(['sig_t: ' num2str(obj.velacc_param(4))]);
            disp(['v_a_n: ' num2str(obj.velacc_param(5))]);
            disp(['v_a_0: ' num2str(obj.velacc_param(6))]);
            disp(['v_e_n: ' num2str(obj.velacc_param(7))]);
            disp(['v_e_0: ' num2str(obj.velacc_param(8))]);
            disp(['v_DC : ' num2str(obj.velacc_param(9))]);
            disp(['a_a_n: ' num2str(obj.velacc_param(10))]);
            disp(['a_a_0: ' num2str(obj.velacc_param(11))]);
            disp(['a_e_n: ' num2str(obj.velacc_param(12))]);
            disp(['a_e_0: ' num2str(obj.velacc_param(13))]);
            disp(['a_DC : ' num2str(obj.velacc_param(14))]);
            disp(['w    : ' num2str(obj.velacc_param(15))]);
        end
    end 
end