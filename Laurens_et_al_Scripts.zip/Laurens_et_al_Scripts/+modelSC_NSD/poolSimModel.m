classdef poolSimModel
    properties
        true_type
        pool_type
        
        true_weights
        pool_weights
        
        true_v_tuning
        true_a_tuning
        true_j_tuning
        pool_v_tuning
        pool_a_tuning
        pool_j_tuning
        
        true_n
        pool_n
        
        pool_mu_t
        
        time

        pool_A
        pool_R_0
        
        pool_match
        
        mismatches
    end
    
    methods
        function obj = poolSimModel(OUTPUT_PATH)          
            data_dir = dir([OUTPUT_PATH '*.mat']);
            
            obj.true_type = zeros(length(data_dir), 1);
            obj.pool_type = zeros(length(data_dir), 1);
            
            obj.true_weights = zeros(length(data_dir), 3);
            obj.pool_weights = zeros(length(data_dir), 3);
            
            obj.true_v_tuning = zeros(length(data_dir), 2);
            obj.true_a_tuning = zeros(length(data_dir), 2);
            obj.true_j_tuning = zeros(length(data_dir), 2);
            obj.pool_v_tuning = zeros(length(data_dir), 2);
            obj.pool_a_tuning = zeros(length(data_dir), 2);
            obj.pool_j_tuning = zeros(length(data_dir), 2);

            obj.true_n = zeros(length(data_dir), 3);
            obj.pool_n = zeros(length(data_dir), 3);
            
            obj.pool_mu_t = zeros(length(data_dir), 1);
            
            obj.pool_A = zeros(length(data_dir), 1);
            obj.pool_R_0 = zeros(length(data_dir), 1);
            
            obj.pool_match = zeros(7,7);
            
            obj.mismatches = zeros(length(data_dir), 1);
            
            for i=1:length(data_dir),
                dat = load([OUTPUT_PATH filesep data_dir(i).name]);
                
                obj.true_type(i) = dat.p.model_type;
                
                switch dat.p.model_type,
                    case 1
                        obj.true_v_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                        obj.true_a_tuning(i,:) = NaN;
                        obj.true_j_tuning(i,:) = NaN;
                        
                        obj.true_weights(i,1) = 1;
                        
                        obj.true_n(i,1) = dat.p.true_param(4);
                        obj.true_n(i,2) = NaN;
                        obj.true_n(i,3) = NaN;
                        
                        
                    case 2
                        obj.true_v_tuning(i,:) = NaN;
                        obj.true_a_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                        obj.true_j_tuning(i,:) = NaN;
                        
                        obj.true_weights(i,2) = 1;
                        
                        obj.true_n(i,1) = NaN;
                        obj.true_n(i,2) = dat.p.true_param(4);
                        obj.true_n(i,3) = NaN;
                        
                        
                    case 3
                        obj.true_v_tuning(i,:) = NaN;
                        obj.true_a_tuning(i,:) = NaN;
                        obj.true_j_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                                              
                         obj.true_weights(i,3) = 1; 
                         
                         obj.true_n(i,1) = NaN;
                         obj.true_n(i,2) = NaN;
                         obj.true_n(i,3) = dat.p.true_param(4);
                   
                    case 4
                        obj.true_v_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                        obj.true_a_tuning(i,:) = [dat.p.true_param(8) ...
                                                  dat.p.true_param(9) ...
                                                  ]*180/pi;
                        obj.true_j_tuning(i,:) = NaN;
                        
                        obj.true_weights(i,1) = dat.p.true_param(10);
                        obj.true_weights(i,2) = 1-dat.p.true_param(10);
                        
                        obj.true_n(i,1) = dat.p.true_param(4);
                        obj.true_n(i,2) = dat.p.true_param(7);
                        obj.true_n(i,3) = NaN;
                        
                    case 5
                        obj.true_v_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                        obj.true_a_tuning(i,:) = NaN;                      
                        obj.true_j_tuning(i,:) = [dat.p.true_param(8) ...
                                                  dat.p.true_param(9) ...
                                                  ]*180/pi;
                                              
                        obj.true_weights(i,1) = dat.p.true_param(10);
                        obj.true_weights(i,3) = 1-dat.p.true_param(10);                      

                        obj.true_n(i,1) = dat.p.true_param(4);
                        obj.true_n(i,2) = NaN;
                        obj.true_n(i,3) = dat.p.true_param(7);

                        
                    case 6
                        obj.true_v_tuning(i,:) = NaN;
                        obj.true_a_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                        obj.true_j_tuning(i,:) = [dat.p.true_param(8) ...
                                                  dat.p.true_param(9) ...
                                                  ]*180/pi;
                                              
                        obj.true_weights(i,2) = dat.p.true_param(10);
                        obj.true_weights(i,3) = 1-dat.p.true_param(10);  
                        
                        obj.true_n(i,1) = NaN;
                        obj.true_n(i,2) = dat.p.true_param(4);
                        obj.true_n(i,3) = dat.p.true_param(7);
                                              
                    case 7
                        obj.true_v_tuning(i,:) = [dat.p.true_param(5) ...
                                                  dat.p.true_param(6) ...
                                                  ]*180/pi;
                        obj.true_a_tuning(i,:) = [dat.p.true_param(8) ...
                                                  dat.p.true_param(9) ...
                                                  ]*180/pi;
                        obj.true_j_tuning(i,:) = [dat.p.true_param(11) ...
                                                  dat.p.true_param(12) ...
                                                  ]*180/pi;
                                              
                        w_v = dat.p.true_param(13);
                        w_j = dat.p.true_param(14);
                        obj.true_weights(i,1) = (1 - w_j)*w_v;
                        obj.true_weights(i,2) = (1 - w_j)*(1 - w_v);
                        obj.true_weights(i,3) = w_j;
                        
                        obj.true_n(i,1) = dat.p.true_param(4);
                        obj.true_n(i,2) = dat.p.true_param(7);
                        obj.true_n(i,3) = dat.p.true_param(10);

                end
  
                sm = selModel2(dat.p, dat.fv, dat.fa, dat.fj, ...
                              dat.fva, dat.fvj, dat.faj, dat.fvaj);
               
                if i == 1,
                    obj.time = sm.time;
                end

                obj.pool_type(i) = sm.bic_type;
                
                obj.pool_weights(i,:) = sm.bic_w;
                
                obj.pool_mu_t(i) = sm.bic_mu_t;

                obj.pool_v_tuning(i,:) = [sm.bic_azi(1) sm.bic_ele(1)]*180/pi;
                obj.pool_a_tuning(i,:) = [sm.bic_azi(2) sm.bic_ele(2)]*180/pi;
                obj.pool_j_tuning(i,:) = [sm.bic_azi(3) sm.bic_ele(3)]*180/pi;
                
                obj.pool_n(i,1) = sm.bic_vn;
                obj.pool_n(i,2) = sm.bic_an;
                obj.pool_n(i,3) = sm.bic_jn;

                obj.pool_A(i) = sm.bic_A;
                obj.pool_R_0(i) = sm.bic_R_0;
                
                obj.pool_match(obj.true_type(i), obj.pool_type(i)) = ...
                    obj.pool_match(obj.true_type(i), obj.pool_type(i))+1;
                
                if obj.true_type(i) ~= obj.pool_type(i),
                    obj.mismatches(i) = 1;
                end
            end
            
            obj.mismatches = obj.mismatches == 1;
        end
        
        function plotMatches(obj)
            match = obj.pool_match/max(obj.pool_match(:));
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            hold on;
            for i = 1:7,
                for j = 1:7,
                    if match(i,j) > 0,
                        plot([1 2], [i j], '-', ...
                             'linewidth', 20*match(i,j), ...
                             'color', (1-match(i,j))*[1 0 0]);
                    end
                end
            end
            hold off;
            ylim([0 8]);
            set(gca,'YTickLabel',{'', 'V', 'A', 'J', 'VA', 'VJ', 'AJ', 'VAJ', ''});
        end
        
        function plotTuningDiff(obj)
            [tvx, tvy, tvz] = sph2cart(obj.true_v_tuning(:,2)*pi/180, ...
                                       obj.true_v_tuning(:,1)*pi/180, 1);
            [tax, tay, taz] = sph2cart(obj.true_a_tuning(:,2)*pi/180, ...
                                       obj.true_a_tuning(:,1)*pi/180, 1);  
            [tjx, tjy, tjz] = sph2cart(obj.true_j_tuning(:,2)*pi/180, ...
                                       obj.true_j_tuning(:,1)*pi/180, 1);
                                   
            [pvx, pvy, pvz] = sph2cart(obj.pool_v_tuning(:,2)*pi/180, ...
                                       obj.pool_v_tuning(:,1)*pi/180, 1);
            [pax, pay, paz] = sph2cart(obj.pool_a_tuning(:,2)*pi/180, ...
                                       obj.pool_a_tuning(:,1)*pi/180, 1);  
            [pjx, pjy, pjz] = sph2cart(obj.pool_j_tuning(:,2)*pi/180, ...
                                       obj.pool_j_tuning(:,1)*pi/180, 1);
           
            v_ang = acos(diag([tvx tvy tvz]*[pvx pvy pvz]'))*180/pi;
            j_ang = acos(diag([tjx tjy tjz]*[pjx pjy pjz]'))*180/pi;
            a_ang = acos(diag([tax tay taz]*[pax pay paz]'))*180/pi;
            
%             v_ang = v_ang(obj.mismatches); 
%             j_ang = j_ang(obj.mismatches); 
%             a_ang = a_ang(obj.mismatches); 
          
            bins = 0:1:180;

            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(3,1,1);
            den = histc(v_ang, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'r');
            box off;
            ylabel('Percent');
            xlabel('Vel. Angle Error');
            
            subplot(3,1,2);
            den = histc(a_ang, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'b');
            box off;
            ylabel('Percent');
            xlabel('Acc. Angle Error');
            
            subplot(3,1,3);
            den = histc(j_ang, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'g');
            box off;
            ylabel('Percent');
            xlabel('Jer. Angle Error');
        end
        
        function plotWeightDiff(obj)
            bins = -1:0.01:1;
            dif_v_weights = obj.pool_weights(:,1) - obj.true_weights(:,1);
            dif_a_weights = obj.pool_weights(:,2) - obj.true_weights(:,2);
            dif_j_weights = obj.pool_weights(:,3) - obj.true_weights(:,3);
            
%             dif_v_weights = obj.pool_weights(obj.mismatches,1) - ...
%                             obj.true_weights(obj.mismatches,1);
%             dif_a_weights = obj.pool_weights(obj.mismatches,2) - ...
%                             obj.true_weights(obj.mismatches,2);
%             dif_j_weights = obj.pool_weights(obj.mismatches,3) - ...
%                             obj.true_weights(obj.mismatches,3);
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(3,1,1);
            den = histc(dif_v_weights, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'r');
            box off;
            ylabel('Percent');
            xlabel('Vel. Weights Error');
            subplot(3,1,2);
            den = histc(dif_a_weights, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'b');
            box off;
            ylabel('Percent');
            xlabel('Acc. Weights Error');
            subplot(3,1,3);
            den = histc(dif_j_weights, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'g');
            box off;
            ylabel('Percent');
            xlabel('Jer. Weights Error');
        end
        
        function plotNonlinearityDiff(obj)
            bins = -10:0.1:10;
            dif_v_n = obj.pool_n(:,1) - obj.true_n(:,1);
            dif_a_n = obj.pool_n(:,2) - obj.true_n(:,2);
            dif_j_n = obj.pool_n(:,3) - obj.true_n(:,3);
            
%             dif_v_n = obj.pool_n(obj.mismatches,1) - obj.true_n(obj.mismatches,1);
%             dif_a_n = obj.pool_n(obj.mismatches,2) - obj.true_n(obj.mismatches,2);
%             dif_j_n = obj.pool_n(obj.mismatches,3) - obj.true_n(obj.mismatches,3);
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(3,1,1);
            den = histc(dif_v_n, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'r');
            box off;
            ylabel('Percent');
            xlabel('Vel. Nonlinearity Error');
            subplot(3,1,2);
            den = histc(dif_a_n, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'b');
            box off;
            ylabel('Percent');
            xlabel('Acc. Nonlinearity Error');
            subplot(3,1,3);
            den = histc(dif_j_n, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'g');
            box off;
            ylabel('Percent');
            xlabel('Jer. Nonlinearity Error');
        end
        
        function plotDCDiff(obj)
            bins = -1:0.01:1;
%             dif_v_DC = obj.pool_DC(:,1) - obj.true_DC(:,1);
%             dif_a_DC = obj.pool_DC(:,2) - obj.true_DC(:,2);
%             dif_j_DC = obj.pool_DC(:,3) - obj.true_DC(:,3);
            
            dif_v_DC = obj.pool_DC(obj.mismatches,1) - ...
                       obj.true_DC(obj.mismatches,1);
            dif_a_DC = obj.pool_DC(obj.mismatches,2) - ...
                       obj.true_DC(obj.mismatches,2);
            dif_j_DC = obj.pool_DC(obj.mismatches,3) - ...
                       obj.true_DC(obj.mismatches,3);
            
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(3,1,1);
            den = histc(dif_v_DC, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'r');
            box off;
            ylabel('Percent');
            xlabel('Vel. DC Error');
            subplot(3,1,2);
            den = histc(dif_a_DC, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'b');
            box off;
            ylabel('Percent');
            xlabel('Acc. DC Error');
            subplot(3,1,3);
            den = histc(dif_j_DC, bins);
            den = 100*den/sum(den);
            area(bins, den, 'facecolor', 'g');
            box off;
            ylabel('Percent');
            xlabel('Jer. DC Error');
        end
        
        function plotWeightsvsTuning(obj)
            true_v_weights = obj.true_weights(:,1);
            true_a_weights = obj.true_weights(:,2);
            true_j_weights = obj.true_weights(:,3);
            
            [tvx, tvy, tvz] = sph2cart(obj.true_v_tuning(:,2)*pi/180, ...
                                       obj.true_v_tuning(:,1)*pi/180, 1);
            [tax, tay, taz] = sph2cart(obj.true_a_tuning(:,2)*pi/180, ...
                                       obj.true_a_tuning(:,1)*pi/180, 1);  
            [tjx, tjy, tjz] = sph2cart(obj.true_j_tuning(:,2)*pi/180, ...
                                       obj.true_j_tuning(:,1)*pi/180, 1);
                                   
            [pvx, pvy, pvz] = sph2cart(obj.pool_v_tuning(:,2)*pi/180, ...
                                       obj.pool_v_tuning(:,1)*pi/180, 1);
            [pax, pay, paz] = sph2cart(obj.pool_a_tuning(:,2)*pi/180, ...
                                       obj.pool_a_tuning(:,1)*pi/180, 1);  
            [pjx, pjy, pjz] = sph2cart(obj.pool_j_tuning(:,2)*pi/180, ...
                                       obj.pool_j_tuning(:,1)*pi/180, 1);
           
            v_ang = acos(diag([tvx tvy tvz]*[pvx pvy pvz]'))*180/pi;
            j_ang = acos(diag([tjx tjy tjz]*[pjx pjy pjz]'))*180/pi;
            a_ang = acos(diag([tax tay taz]*[pax pay paz]'))*180/pi;

            dif_v_weights = obj.pool_weights(:,1);
            dif_a_weights = obj.pool_weights(:,2);
            dif_j_weights = obj.pool_weights(:,3);
            
            dif_v_n = obj.pool_n(:,1) - obj.true_n(:,1);
            dif_a_n = obj.pool_n(:,2) - obj.true_n(:,2);
            dif_j_n = obj.pool_n(:,3) - obj.true_n(:,3);
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz, 'Renderer', 'painters');
            subplot(3,3,1);            
            plot(v_ang(obj.mismatches), ...
                 true_v_weights(obj.mismatches), '*'); 
            hold on;
            plot(v_ang(~obj.mismatches), ...
                 true_v_weights(~obj.mismatches), 'r*'); 
            hold off;
            box off;
            ylabel('True Vel. Weights');
            xlabel('Dif. in Vel. Angle');
            subplot(3,3,2);            
            plot(a_ang(obj.mismatches), ...
                 true_a_weights(obj.mismatches), '*');
            hold on;
            plot(a_ang(~obj.mismatches), ...
                 true_a_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            ylabel('True Acc. Weights');
            xlabel('Dif. in Acc. Angle');
            subplot(3,3,3);            
            plot(j_ang(obj.mismatches), ...
                 true_j_weights(obj.mismatches), '*');
            hold on;
            plot(j_ang(~obj.mismatches), ...
                 true_j_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            ylabel('True Jer. Weights');
            xlabel('Dif. in Jer. Angle');
            
            subplot(3,3,4);            
            plot(dif_v_weights(obj.mismatches), ...
                 true_v_weights(obj.mismatches), '*'); 
            hold on;
            plot(dif_v_weights(~obj.mismatches), ...
                 true_v_weights(~obj.mismatches), 'r*'); 
            hold off;
            box off;
            ylabel('True Vel. Weights');
            xlabel('Recon Vel. Weights');
            subplot(3,3,5);            
            plot(dif_a_weights(obj.mismatches), ...
                 true_a_weights(obj.mismatches), '*');
            hold on;
            plot(dif_a_weights(~obj.mismatches), ...
                 true_a_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            ylabel('True Acc. Weights');
            xlabel('Recon Acc. Weights');
            subplot(3,3,6);            
            plot(dif_j_weights(obj.mismatches), ...
                 true_j_weights(obj.mismatches), '*');
            hold on;
            plot(dif_j_weights(~obj.mismatches), ...
                 true_j_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            ylabel('True Jer. Weights');
            xlabel('Recon Jer. Weights');
            
            subplot(3,3,7);            
            plot(dif_v_n(obj.mismatches), ...
                 true_v_weights(obj.mismatches), '*'); 
            hold on;
            plot(dif_v_n(~obj.mismatches), ...
                 true_v_weights(~obj.mismatches), 'r*'); 
            hold off;
            box off;
            ylabel('True Vel. Weights');
            xlabel('Dif. in Vel. Nonlinearity');
            subplot(3,3,8);            
            plot(dif_a_n(obj.mismatches), ...
                 true_a_weights(obj.mismatches), '*');
            hold on;
            plot(dif_a_n(~obj.mismatches), ...
                 true_a_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            ylabel('True Acc. Weights');
            xlabel('Dif. in Acc. Nonlinearity');
            subplot(3,3,9);            
            plot(dif_j_n(obj.mismatches), ...
                 true_j_weights(obj.mismatches), '*');
            hold on;
            plot(dif_j_n(~obj.mismatches), ...
                 true_j_weights(~obj.mismatches), 'r*');
            hold off;
            box off;
            ylabel('True Jer. Weights');
            xlabel('Dif. in Jer. Nonlinearity');
            
        end
    end
end