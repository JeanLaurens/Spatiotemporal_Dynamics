clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('modelS1H'));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));

PATH = (['..' filesep '..' filesep 'Output' filesep 'S1HN_Output_Xiongjie' filesep]);
sc_psm = poolModelClass(PATH);

PATH = (['..' filesep '..' filesep 'Output' filesep 'S1H_Output_Xiongjie' filesep]);
scc_psm = poolModelClass(PATH);

PATH = (['..' filesep '..' filesep 'Output' filesep 'S1H2_Output_Xiongjie' filesep]);
dc_psm = poolModelClass(PATH);

PATH = (['..' filesep '..' filesep 'Output' filesep 'S2H2_Output_Xiongjie' filesep]);
dcc_psm = poolModelClass(PATH);

sc_scc_dif = sc_psm.pool_bic - scc_psm.pool_bic;
scc_dcc_dif = scc_psm.pool_bic - dcc_psm.pool_bic;
dc_dcc_dif = dc_psm.pool_bic - dcc_psm.pool_bic;
dc_sc_dif = dc_psm.pool_bic - sc_psm.pool_bic;
sc_dcc_dif = sc_psm.pool_bic - dcc_psm.pool_bic;
scc_dc_dif = scc_psm.pool_bic - dc_psm.pool_bic;

bic_max = max([sc_scc_dif; scc_dcc_dif; dc_dcc_dif; ...
               dc_sc_dif; sc_dcc_dif; scc_dc_dif]);
           
bic_min = min([sc_scc_dif; scc_dcc_dif; dc_dcc_dif; ...
               dc_sc_dif; sc_dcc_dif; scc_dc_dif]); 

bic_step = (bic_max - bic_min)/100;
           
lpos_text = bic_min + (bic_max-bic_min)/8;
rpos_text = bic_max - (bic_max-bic_min)/8;  

scrsz = get(0,'ScreenSize');
figure('Position', scrsz, 'Renderer', 'painters');
subplot(2,3,1);
hist(sc_scc_dif, bic_min:bic_step:bic_max);
h = findobj(gca,'Type','patch');
set(h,'FaceColor', 'y');
xlim([bic_min bic_max]);
box off;
line([0 0], ylim, 'Color', 'k');
q = quantile(sc_scc_dif, 3);
%line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line(q(2)*[1 1], ylim, 'Color', 'r');
%line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
%line((q(3) + 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
%line((q(1) - 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
yl = ylim;
ypos = yl(2);
text(lpos_text, ypos, 'Choose S1HN');
text(rpos_text, ypos, 'Choose S1H', 'HorizontalAlignment', 'right');
title('S1HN - S1H');
xlabel('BIC Diff.');
ylabel('Count');

subplot(2,3,2);
hist(scc_dcc_dif, bic_min:bic_step:bic_max);
h = findobj(gca,'Type','patch');
set(h,'FaceColor', 'y');
xlim([bic_min bic_max]);
box off;
line([0 0], ylim, 'Color', 'k');
q = quantile(scc_dcc_dif, 3);
%line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line(q(2)*[1 1], ylim, 'Color', 'r');
%line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
%line((q(3) + 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
%line((q(1) - 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
yl = ylim;
ypos = yl(2);
text(lpos_text, ypos, 'Choose S1H');
text(rpos_text, ypos, 'Choose S2H', 'HorizontalAlignment', 'right');
title('S1H - S2H');
xlabel('BIC Diff.');
ylabel('Count');

subplot(2,3,3);
hist(dc_dcc_dif, bic_min:bic_step:bic_max);
h = findobj(gca,'Type','patch');
set(h,'FaceColor', 'y');
xlim([bic_min bic_max]);
box off;
line([0 0], ylim, 'Color', 'k');
q = quantile(dc_dcc_dif, 3);
%line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line(q(2)*[1 1], ylim, 'Color', 'r');
%line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
%line((q(3) + 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
%line((q(1) - 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
yl = ylim;
ypos = yl(2);
text(lpos_text, ypos, 'Choose S1HC');
text(rpos_text, ypos, 'Choose S2H', 'HorizontalAlignment', 'right');
title('S1HC - S2H');
xlabel('BIC Diff.');
ylabel('Count');

subplot(2,3,4);
hist(dc_sc_dif, bic_min:bic_step:bic_max);
h = findobj(gca,'Type','patch');
set(h,'FaceColor', 'y');
xlim([bic_min bic_max]);
box off;
line([0 0], ylim, 'Color', 'k');
q = quantile(dc_sc_dif, 3);
%line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line(q(2)*[1 1], ylim, 'Color', 'r');
%line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
%line((q(3) + 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
%line((q(1) - 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
yl = ylim;
ypos = yl(2);
text(lpos_text, ypos, 'Choose S1HN');
text(rpos_text, ypos, 'Choose S1HC', 'HorizontalAlignment', 'right');
title('S1HC - S1HN');
xlabel('BIC Diff.');
ylabel('Count');

subplot(2,3,5);
hist(sc_dcc_dif, bic_min:bic_step:bic_max);
h = findobj(gca,'Type','patch');
set(h,'FaceColor', 'y');
xlim([bic_min bic_max]);
box off;
line([0 0], ylim, 'Color', 'k');
q = quantile(sc_dcc_dif, 3);
%line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line(q(2)*[1 1], ylim, 'Color', 'r');
%line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
%line((q(3) + 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
%line((q(1) - 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
yl = ylim;
ypos = yl(2);
text(lpos_text, ypos, 'Choose S1HN');
text(rpos_text, ypos, 'Choose S2H', 'HorizontalAlignment', 'right');
title('S1HN - S2H');
xlabel('BIC Diff.');
ylabel('Count');

subplot(2,3,6);
hist(scc_dc_dif, bic_min:bic_step:bic_max);
h = findobj(gca,'Type','patch');
set(h,'FaceColor', 'y');
xlim([bic_min bic_max]);
box off;
line([0 0], ylim, 'Color', 'k');
q = quantile(scc_dc_dif, 3);
%line(q(1)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
line(q(2)*[1 1], ylim, 'Color', 'r');
%line(q(3)*[1 1], ylim, 'Color', 'r', 'linestyle', '--');
%line((q(3) + 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
%line((q(1) - 1.5*(q(3)-q(1)))*[1 1], ylim, 'Color', 'r', 'linestyle', '-.');
yl = ylim;
ypos = yl(2);
text(lpos_text, ypos, 'Choose S1H');
text(rpos_text, ypos, 'Choose S1HC', 'HorizontalAlignment', 'right');
title('S1H - S1HC');
xlabel('BIC Diff.');
ylabel('Count');