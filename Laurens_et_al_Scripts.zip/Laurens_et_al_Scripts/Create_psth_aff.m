clear;
% 
% addpath(genpath(['..' filesep 'Toolbox']));
% addpath(genpath('selection'));
% addpath(genpath('psth'));
% addpath(genpath('misc'));
% addpath(genpath('htb'));
% addpath(genpath('modelS2H'));

addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\Toolbox']));
addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\htb']));
addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\misc']));
%addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\modelS2H']));
addpath('Z:\Users\sheng\MATLAB_R\MATLAB\vestibular_analysis\1modelSC_NS\')
addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\psth']));
addpath(genpath(['Z:\Users\Raymond\rchan\Documents\MATLAB\vestibular_analysis\selection']));
ProtocolDefs;
brain_area = 'OA';


TIMEPATH = (['Z:\Users\Raymond\rchan\Documents\Paper_Input\Time_Correction\']);
[temp, fileName]  = xlsread([TIMEPATH brain_area '_correct.xls'])
addpath('D:\PPN');
for i= 1 : length(fileName)  % vn 76
   tmpstr =  strtrim(char(fileName(i)));
   tmpindex =  find(isspace(tmpstr));
   matindex = strfind(tmpstr, '.mat');
   cur_path_name = strtrim(tmpstr(1:tmpindex(1)-1));
   cur_file_name = [strtrim(tmpstr(tmpindex(1)+1: matindex-1))  '.htb'];
   tempindex =  strfind(tmpstr,  '.mat');
   channel = str2num(tmpstr(tempindex-1));
   if ~exist(['D:\work_3d\PSTH' filesep 'psth_' brain_area ]) 
       mkdir(['D:\work_3d\PSTH' filesep 'psth_' brain_area ])
   end
    
   p = PSTH('xiongjie', 1.106, cur_path_name);
%     if ~p.rej,
%          save(['D:\missing\'  cur_file_name(1:end-4)  '_1' ], 'p');
          save(['D:\work_3d\PSTH' filesep 'psth_' brain_area filesep cur_file_name(1:end-4)], 'p');
%     end 
    
%    index = find(temp_stim_type == 2);
%    clear data2;
%    data2 = data;
%    data2.eye_data =  data.eye_data(:, :,  index);
%    data2.spike_data =  data.spike_data(:, :,  index);
%    data2.event_data =  data.event_data(:, :,  index);
%    data2.moog_params =  data.moog_params(:, index, :);
%     p = PSTH('sheng', 1.115, data2, 1);
%     if ~p.rej,
%          save(['D:\vestibular_3d\temp\'  cur_file_name(1:end-4)  '_2' ], 'p');
%     end

end