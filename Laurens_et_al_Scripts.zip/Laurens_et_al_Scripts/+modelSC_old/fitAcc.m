classdef fitAcc
    properties
        reps
        psth
        
        u_azi
        u_ele
        time
        
        time_profile
       
        baseline
        
        A
        R_0
        
        ele_azi_profile
        space_profile
        mu_t
        sig_t
        n
        e_0
        a_0
        DC
        
        init_param
       
        acc_param
        rand_param
        
        acc_rss
        rand_rss
        
        acc_jac
        rand_jac
    end
    
    methods
        function obj = fitAcc(p, reps)
            obj.reps = reps;
            obj.psth = p.psth;
            
            obj.u_azi = p.u_azi;
            obj.u_ele = p.u_ele;
            obj.time = p.time;

            obj.baseline = p.baseline;

            stim_sig = sqrt(sqrt(2))/6;
            obj.mu_t = 1;
            obj.sig_t = stim_sig;
            
            %Compute Spatial Profiles
            d_gauss_time = d_gauss([obj.mu_t obj.sig_t], obj.time)';
            
            u1 = d_gauss_time;
            
            t_psth = obj.psth - obj.baseline;
            obj.ele_azi_profile = zeros([length(obj.u_azi), length(obj.u_ele)]);
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi),
                    t_profile = squeeze(t_psth(i,j,:));
                    c = pinv(u1)*squeeze(t_profile);
                    obj.ele_azi_profile(i,j) = c;
                end
            end
               
            %Normalise Profiles         
            obj.DC = (min(obj.ele_azi_profile(:))+max(obj.ele_azi_profile(:)))/2;
            obj.A = (max(obj.ele_azi_profile(:))-min(obj.ele_azi_profile(:)))/2;         
            
            obj.space_profile = obj.ele_azi_profile-obj.DC;                                         
            obj.space_profile = obj.space_profile/obj.A;                               
                        
            %optimisation parameters for profile fits
            options = optimset('Display', 'off', 'MaxIter', 5000);
            
            %Fit spatial profile
            s_data = [obj.u_ele; obj.u_azi];       

            LB = [0.001 0 -pi/2];
            UB = [10 2*pi pi/2]; 
            
            [~, max_idx] = max(obj.space_profile(:));
            [max_idx_a, max_idx_e] = ind2sub(size(obj.space_profile), max_idx);
            param = [0.01 obj.u_azi(max_idx_a) obj.u_ele(max_idx_e)];
            recon_a = lsqcurvefit('cos_tuning', param, ...
                                  s_data, obj.space_profile(:), LB, UB, options);
            obj.n = recon_a(1);
            obj.a_0 = recon_a(2);
            obj.e_0 = recon_a(3);
            
           %Fit linear parameters
           obj.R_0 = p.baseline;
           obj.DC  = obj.DC/obj.A;

            %Inital fits
            param = [obj.A, ...     %1
                     obj.R_0, ...   %2
                     obj.mu_t, ...  %3
                     obj.sig_t, ... %4
                     obj.n, ...     %5
                     obj.a_0, ...   %6
                     obj.e_0, ...   %7
                     obj.DC];       %8
                 
            obj.init_param = zeros(obj.reps+1, length(param));
            obj.init_param = param;
          
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            y_data = packPSTH(obj.psth);
            
            LB = [0.25*obj.A, ...  %1 A
                  0, ...           %2 R_0
                  0.9, ...         %3 mu_t
                  0.5*stim_sig, ...%4 sig_t
                  0.001, ...       %5 n
                  0, ...           %6 a_0
                  -pi/2, ...       %7 e_0
                  0];              %8 DC
              
            UB = [4*obj.A, ...     %1 A
                  300, ...         %2 R_0
                  1.5, ...         %3 mu_t
                  1.5*stim_sig, ...%4 sig_t
                  10, ...          %5 n
                  2*pi, ...        %6 a_0
                  pi/2, ...        %7 e_0
                  1];              %8 DC
            
            t_rand_rss = zeros(obj.reps+1,1);
            t_rand_param = zeros(obj.reps+1, length(param));
            t_rand_jac = zeros(obj.reps+1, length(param), length(param));
              
            [t_rand_param(1,:), t_rand_rss(1),~,~,~,~,tmp_jacobian] = ...
            lsqcurvefit('acc_model', obj.init_param, st_data, y_data, LB, UB, options);
            t_rand_jac(1,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);  

            %Initial Conditions Random Range
            err_range =  0.1*(UB - LB);
            min_param = t_rand_param(1,:);
            UB_param = min_param+err_range;
            LB_param = min_param-err_range;
           
            parfor i=2:obj.reps+1,
                %Randomise Initial Conditions
                seed_param  = unifrnd(LB_param, UB_param);
                
                [t_rand_param(i,:), t_rand_rss(i),~,~,~,~,tmp_jacobian] = ...
                 lsqcurvefit('acc_model', seed_param, st_data, y_data, LB, UB, options);
                 t_rand_jac(i,:,:) = full(tmp_jacobian)'*full(tmp_jacobian);
            end
            
            obj.rand_param = t_rand_param;
            obj.rand_rss = t_rand_rss;
            obj.rand_jac = t_rand_jac;
            
            [~,min_idx] = min(obj.rand_rss);
            obj.acc_param = obj.rand_param(min_idx,:);
            obj.acc_rss = obj.rand_rss(min_idx);
            obj.acc_jac = obj.rand_jac(min_idx,:,:);
        end

        function plotPSTH(obj, trial_name, page_num, path)
            st_data = [obj.u_ele; obj.u_azi; obj.time'];
            
            init_fit = acc_model(obj.init_param, st_data); 
            acc_fit = acc_model(obj.acc_param, st_data);
            
            init_fit = unpackPSTH(init_fit, size(obj.psth));
            acc_fit = unpackPSTH(acc_fit, size(obj.psth));
            
            max_spikes = max(obj.psth(:));
            min_spikes = min(obj.psth(:));
            
            scrsz = get(0,'ScreenSize');
            h = figure('Position', scrsz, 'Renderer', 'painters');
            for j=1:length(obj.u_ele),
                for i=1:length(obj.u_azi)-1,
                    if j == 1 && i > 1,
                        continue;
                    end
                    if j == length(obj.u_ele) && i > 1,
                        continue;
                    end
                    subplot(length(obj.u_ele), length(obj.u_azi)-1, ...
                           (length(obj.u_ele)-j)*(length(obj.u_azi)-1) + i);
                    plot(obj.time, squeeze(obj.psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.time, squeeze(init_fit(i,j,:)), 'g');
                    plot(obj.time, squeeze(acc_fit(i,j,:)), 'k');
                    hold off;
                    axis tight;
                    box off;
                    ylim([min_spikes max_spikes]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.u_ele(j)*180/pi) ...
                           ', ' num2str(obj.u_azi(i)*180/pi) ']']);
                end
            end
            
            subplot(length(obj.u_ele), length(obj.u_azi)-1, 2);
            axis off;
            
            tabstring = ['Trial ' num2str(page_num) ': ' trial_name];
            text(0, 1, tabstring, 'Interpreter','latex', ...
                 'FontName', 'helvetica', 'FontSize', 12);
             
            if nargin == 4,
                set(h, 'PaperPosition', [0 0 11 8.5]);
                set(h, 'PaperSize', [11 8.5]);
                saveas(h, [path trial_name(1:end-4) '.pdf'], 'pdf');
                close(h);
            end
        end

        function printVal(obj)
            disp('Acceleration');
            disp(['A    : ' num2str(obj.acc_param(1))]);
            disp(['R_0  : ' num2str(obj.acc_param(2))]);
            disp(['mu_t : ' num2str(obj.acc_param(3))]);
            disp(['sig_t: ' num2str(obj.acc_param(4))]);
            disp(['a_n  : ' num2str(obj.acc_param(5))]);
            disp(['a_0  : ' num2str(obj.acc_param(6))]);
            disp(['e_n  : ' num2str(obj.acc_param(7))]);
            disp(['e_0  : ' num2str(obj.acc_param(8))]);
            disp(['DC   : ' num2str(obj.acc_param(9))]);
        end
        
        function plotProfileFits(obj)
            d_gauss_time = d_gauss([obj.mu_t, obj.sig_t obj.t_A], obj.time);
            s_data = [obj.u_ele; obj.u_azi];
            param = [obj.a_n, obj.a_0, obj.e_n, obj.e_0];
            
            ele_azi = cos_tuning([param 0], s_data);
            ele_azi = reshape(ele_azi, length(obj.u_azi), length(obj.u_ele));

            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz);
            subplot(2,2,[1 2]);
            plot(obj.time, obj.time_profile, 'r');
            hold on;
            plot(obj.time, d_gauss_time, 'b');
            hold off;
            axis tight;
            box off;
            xlabel('Time (s)');
            
            subplot(2,2,3);
            contourf(obj.u_ele, obj.u_azi, obj.space_profile);
            box off;
            colorbar;
            xlabel('Elevation (rad)');
            ylabel('Aziumuth (rad)');
            
            subplot(2,2,4);
            contourf(obj.u_ele, obj.u_azi, ele_azi);
            box off;
            colorbar;
            xlabel('Elevation (rad)');
            ylabel('Aziumuth (rad)');
        end
        
        function plotReconPSTH(obj)
            tmp_psth = obj.p.psth - obj.p.baseline;
            tmp_psth = 2*tmp_psth/(max(tmp_psth(:)) - min(tmp_psth(:)));
            
            ta_DC = (min(obj.p.azi_profile) + max(obj.p.azi_profile))/2;
            te_DC = (min(obj.p.ele_profile) + max(obj.p.ele_profile))/2;
            tt_DC = (min(obj.p.time_profile) + max(obj.p.time_profile))/2;
            
            tt_A = max(obj.p.time_profile)-min(obj.p.time_profile);
            ta_A = max(obj.p.azi_profile)-min(obj.p.azi_profile);
            te_A = max(obj.p.ele_profile)-min(obj.p.ele_profile);
            
            %Normalise Profiles 
            tmp_ele_profile = obj.p.ele_profile;                                         
            tmp_azi_profile = obj.p.azi_profile;
            tmp_time_profile = obj.p.time_profile;
            
            tmp_ele_profile = tmp_ele_profile/te_A;                                         
            tmp_azi_profile = tmp_azi_profile/ta_A;
            tmp_time_profile = tmp_time_profile/tt_A;
            
            recon_coeff = tmp_ele_profile*tmp_azi_profile;
            reconPSTH = zeros(size(tmp_psth));
            for j=1:length(obj.p.u_ele),
                for i=1:length(obj.p.u_azi),    
                    reconPSTH(i,j,:) = recon_coeff(i,j)*tmp_time_profile;
                end
            end
            reconPSTH = 2*reconPSTH/(max(reconPSTH(:)) - min(reconPSTH(:)));
            
            scrsz = get(0,'ScreenSize');
            figure('Position', scrsz);
            for j=1:length(obj.p.u_ele),
                for i=1:length(obj.p.u_azi),    
                    subplot(length(obj.p.u_ele), length(obj.p.u_azi), ...
                           (length(obj.p.u_ele)-j)*length(obj.p.u_azi) + i);
                    plot(obj.p.time, squeeze(tmp_psth(i,j,:)), 'r');
                    hold on;
                    plot(obj.p.time, squeeze(reconPSTH(i,j,:)), 'b');
                    hold off;
                    axis tight;
                    ylim([-1 1]);
                    line([0 0], ylim, 'color', 'k');
                    line(2*[1 1], ylim, 'color', 'k');
                    title(['[' num2str(obj.p.u_ele(j)) ', ' num2str(obj.p.u_azi(i)) ']']);
                end
            end
        end 
    end
end

function plot_tuning(e0, a0, n, m, DC)
    [x0, y0, z0] = sph2cart(a0, e0, 1);

    tu_azi = 0:0.05*pi:2*pi;
    tu_ele = -pi/2:0.05*pi:pi/2;

    azi = repmat(tu_azi, length(tu_ele), 1);
    ele = repmat(tu_ele', 1, length(tu_azi));

    [x, y, z] = sph2cart(azi, ele, ones(size(azi)));

    q_s = cos(e0/2);
    q_v = sin(e0/2)*[0 1 0];
    e_q = [q_v q_s];

    q_s = cos(a0/2);
    q_v = sin(a0/2)*[0 0 -1];
    a_q = [q_v q_s];

    q = qmult(e_q, a_q);

    coord = zeros(size(x,1), size(x,2), 3);
    for i=1:size(x,1),
        for j=1:size(x,2),
            v = [x(i,j) y(i,j) z(i,j)];
            coord(i,j,:) = qvqc(q, v);
        end
    end

    nx = squeeze(coord(:,:,1));
    ny = squeeze(coord(:,:,2));
    nz = squeeze(coord(:,:,3));

    [azi, ele, ~] = cart2sph(nx, ny, nz);

    v = cos_tuning([0 n], azi).*cos_tuning([0 m], ele) + DC;

    surf(x, y, z, v);
    hold on;
    plot3(x0, y0, z0, '*');
    hold off;
    xlabel('x');
    ylabel('y');
    zlabel('z');
    axis equal;
end