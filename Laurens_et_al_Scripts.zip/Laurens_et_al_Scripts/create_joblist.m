clear;

[num, txt, ~] = xlsread(['..' filesep '..' filesep 'Data' ...
                        filesep 'MOOG' filesep 'vn_3d.xls']);
chan = num;
path_name = txt(2:end, 1);
file_name = txt(2:end, 2);

joblist = fopen('joblist.txt', 'w');

for i = 1:length(file_name),
    cur_chan = chan(i);
    cur_path_name = strrep(path_name{i}, '\', filesep);
    cur_path_name = ['..' filesep '..' cur_path_name(3:end)];
    cur_file_name = file_name{i};
    cur_save_name =  ['..' filesep '..' filesep 'Data' filesep 'Output_Sheng' cur_path_name(16:end)];

    data_file_name = [cur_file_name(1:end-4) 'c' num2str(chan(i)) '.mat'];
    data_dir = 'psth_sheng';
    output_dir = 'Output_Sheng';
    
    disp([num2str(i) ', ' data_file_name]);
    
    fprintf(joblist, ['null, ', '''%s''', ', ' ...
                      '''%s''', ', ', '''%s''', '\n'], ...
                      data_file_name, data_dir, output_dir);
end

data_name = ['..' filesep '..' filesep 'Data' filesep 'MOOG' filesep];
fileID = fopen([data_name 'batch_PIVC_Translation_select.txt']);
textlines = textscan(fileID, '%s', 'Delimiter', '\n');

for i=1:length(textlines{1}),
    textline = textscan(textlines{1}{i}, '%s');
    path_name = textline{1}{1};
    cur_path_name = strrep(path_name, '\', filesep);
    
    cur_file_name = textline{1}{2};
    local_path_name = ['..' filesep '..' cur_path_name(3:end)];
    
     
    data_file_name = [cur_file_name(1:end-4) 'c' num2str(1) '.mat'];
    data_dir = 'psth_aihua';
    output_dir = 'Output_Aihua';
    
    disp([num2str(i) ', ' data_file_name]);
    
    fprintf(joblist, ['null, ', '''%s''', ', ' ...
                      '''%s''', ', ', '''%s''', '\n'], ...
                      data_file_name, data_dir, output_dir);
end

PATH = (['..' filesep '..' filesep 'Data' filesep 'Xiongjie_Good' filesep]);
data_file = dir([PATH 'm*']);

for i = 1:length(data_file),    
    cur_file_name = data_file(i).name;
    data_file_name = [cur_file_name '.mat'];
    
    data_dir = 'psth_xiongjie';
    output_dir = 'Output_Xiongjie';
    
    disp([num2str(i) ', ' data_file_name]);
    
    fprintf(joblist, ['null, ', '''%s''', ', ' ...
                      '''%s''', ', ', '''%s''', '\n'], ...
                      data_file_name, data_dir, output_dir);
end

fclose(joblist);