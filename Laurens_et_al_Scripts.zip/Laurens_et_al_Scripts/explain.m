clear;

path  = ['..' filesep '..' filesep 'Paper_Figures' filesep 'final' filesep];

addpath(genpath('misc'));

n1 = 5;
x1 = -0.5;
y1 = -0.25;
z1 = 0.25;

n2 = 0.001;
x2 = 0.5;
y2 = -0.25;
z2 = 0.25;

n3 = 10;
x3 = -0.1;
y3 = -0.6;
z3 = 0.25;

[x, y, z] = sphere(50);

F = @(x,n)((exp(n.*x)-1)./n);

r1 = F([x(:) y(:) z(:)]*[x1 y1 z1]', n1);
r1 = r1 - (max(r1) + min(r1))/2;
r1 = 2*r1/(max(r1) - min(r1));
r1 = reshape(r1, size(x));

r2 = F([x(:) y(:) z(:)]*[x2 y2 z2]', n2);
r2 = r2 - (max(r2) + min(r2))/2;
r2 = 2*r2/(max(r2) - min(r2));
r2 = reshape(r2, size(x));

r3 = F([x(:) y(:) z(:)]*[x3 y3 z3]', n3);
r3 = r3 - (max(r3) + min(r3))/2;
r3 = 2*r3/(max(r3) - min(r3));
r3 = reshape(r3, size(x));

stim_sig = sqrt(sqrt(2))/6;
time = -0.2:.01:2.2;
g0_profile = gauss([1 stim_sig], time);
g1_profile = d_gauss([1 stim_sig], time);
g2_profile = d2_gauss([1 stim_sig], time);

opengl software;
scrsz = get(0,'ScreenSize');
figure('Position', scrsz);
plotname = 'sfig1';

subplot(3,4,[1 2]);
plot3([0 -2], [0 0], [0 0], '-k', 'linewidth', 2);
hold on;
plot3([0 0], [0 -2], [0 0], '-k', 'linewidth', 2);
plot3([0 0], [0 0], [0 2], '-k', 'linewidth', 2);
surf(x,y,z, r1, 'FaceColor','interp',...
                'EdgeColor','none',...
                'FaceLighting','phong');
camlight left;
hold off;
xlabel('x');
ylabel('y');
zlabel('z');
axis vis3d;
text(-2.5, 0, 0, 'X');
text(0, -2.5, 0, 'Y');
text(0, 0, 2.5, 'Z');
set(gca, 'Visible', 'off');

set(gcf,'PaperUnits', 'Centimeters');
xSize = 17.6; ySize = 17.6;

set(gcf,'PaperSize',[20 20]);
set(gcf,'PaperPosition',[0 0 xSize ySize]);
set(gcf,'Position',[0 0 xSize*50 ySize*50]);

saveas(gcf, [path plotname '.pdf'], 'pdf');
close(gcf);

scrsz = get(0,'ScreenSize');
figure('Position', scrsz);
plotname = 'sfig2';

subplot(3,4,[5 6]);
plot3([0 -2], [0 0], [0 0], '-k', 'linewidth', 2);
hold on;
plot3([0 0], [0 -2], [0 0], '-k', 'linewidth', 2);
plot3([0 0], [0 0], [0 2], '-k', 'linewidth', 2);
surf(x,y,z, r2, 'FaceColor','interp',...
                'EdgeColor','none',...
                'FaceLighting','phong');
camlight left;
hold off;
xlabel('x');
ylabel('y');
zlabel('z');
axis vis3d;
text(-2.5, 0, 0, 'X');
text(0, -2.5, 0, 'Y');
text(0, 0, 2.5, 'Z');
set(gca, 'Visible', 'off');

set(gcf,'PaperUnits', 'Centimeters');
xSize = 17.6; ySize = 17.6;

set(gcf,'PaperSize',[20 20]);
set(gcf,'PaperPosition',[0 0 xSize ySize]);
set(gcf,'Position',[0 0 xSize*50 ySize*50]);

saveas(gcf, [path plotname '.pdf'], 'pdf');
close(gcf);

scrsz = get(0,'ScreenSize');
figure('Position', scrsz);
plotname = 'sfig3';

subplot(3,4,[9 10]);
plot3([0 -2], [0 0], [0 0], '-k', 'linewidth', 2);
hold on;
plot3([0 0], [0 -2], [0 0], '-k', 'linewidth', 2);
plot3([0 0], [0 0], [0 2], '-k', 'linewidth', 2);
surf(x,y,z, r3, 'FaceColor','interp',...
                'EdgeColor','none',...
                'FaceLighting','phong');
camlight left;
hold off;
xlabel('x');
ylabel('y');
zlabel('z');
axis vis3d;
text(-2.5, 0, 0, 'X');
text(0, -2.5, 0, 'Y');
text(0, 0, 2.5, 'Z');
set(gca, 'Visible', 'off');

set(gcf,'PaperUnits', 'Centimeters');
xSize = 17.6; ySize = 17.6;

set(gcf,'PaperSize',[20 20]);
set(gcf,'PaperPosition',[0 0 xSize ySize]);
set(gcf,'Position',[0 0 xSize*50 ySize*50]);

saveas(gcf, [path plotname '.pdf'], 'pdf');
close(gcf);

scrsz = get(0,'ScreenSize');
figure('Position', scrsz);
plotname = 'sfig4';

subplot(3,4,3);
plot(time, g0_profile, 'b', 'linewidth', 2);
xlim([-0.2 2.2]);
ylim([-1.5 1.5]);
set(gca, 'Visible', 'off');
box off;

subplot(3,4,7);
plot(time, g1_profile, 'r', 'linewidth', 2);
xlim([-0.2 2.2]);
ylim([-1.5 1.5]);
set(gca, 'Visible', 'off');
box off;

subplot(3,4,11);
plot(time, g2_profile, 'g', 'linewidth', 2);
xlim([-0.2 2.2]);
ylim([-1.5 1.5]);
set(gca, 'Visible', 'off');
box off;

set(gcf,'PaperUnits', 'Centimeters');
xSize = 17.6; ySize = 17.6;

set(gcf,'PaperSize',[20 20]);
set(gcf,'PaperPosition',[0 0 xSize ySize]);
set(gcf,'Position',[0 0 xSize*50 ySize*50]);

saveas(gcf, [path plotname '.pdf'], 'pdf');
close(gcf);