clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('modelSH'));

OUTPUT_PATH = ['..' filesep '..' filesep 'Figures' filesep 'fakedata_plots' filesep];

DC_PATH = (['..' filesep '..' filesep 'Output' filesep 'Output_Sheng' filesep]);
dc_data_dir = dir([DC_PATH '*.mat']);

dc_angle = zeros(length(dc_data_dir), 1);
dc_sp_weights = zeros(length(dc_data_dir), 1);

for i=1:length(dc_data_dir),
%for i = 1,
    dc_cur_data = load([DC_PATH dc_data_dir(i).name]);
    dc_sm = modelSH.selModel(dc_cur_data.p, dc_cur_data.fv, dc_cur_data.fa, ...
                             dc_cur_data.fj, dc_cur_data.fva, dc_cur_data.fvj, ...
                             dc_cur_data.faj, dc_cur_data.fvaj);

    scrsz = get(0,'ScreenSize');
    h = figure('Position', scrsz, 'Renderer', 'painters');
    
    if ~isnan(dc_sm.sp_vel_param),
        sp_vel = sh_recon(dc_sm.sp_vel_param(1:8), 2, dc_sm.u_azi, dc_sm.u_ele+pi/2);
        sp_vel_max = max(sp_vel(:));
        sp_vel_min = min(sp_vel(:));
        subplot(3, 4, 1);
        contourf(dc_sm.u_azi*180/pi, dc_sm.u_ele*180/pi, sp_vel');
        set(gca, 'CLim', [sp_vel_min sp_vel_max]);
        colorbar('EastOutside');
        box off;
        title('Vel Spatial Tuning');
        xlabel('Azimuth (Deg.)');
        ylabel('Elevation (Deg.)');
        
        sp_vel = sh_recon([dc_sm.sp_vel_param(1:3) 0 0 0 0 0], 2, dc_sm.u_azi, dc_sm.u_ele+pi/2);
        subplot(3, 4, 2);
        contourf(dc_sm.u_azi*180/pi, dc_sm.u_ele*180/pi, sp_vel');
        set(gca, 'CLim', [sp_vel_min sp_vel_max]);
        colorbar('EastOutside');
        box off;
        title('Vel 1st Harmonic Tuning');
        xlabel('Azimuth (Deg.)');
        ylabel('Elevation (Deg.)');
        
        sp_vel = sh_recon([0 0 0 dc_sm.sp_vel_param(4:8)], 2, dc_sm.u_azi, dc_sm.u_ele+pi/2);
        subplot(3, 4, 3);
        contourf(dc_sm.u_azi*180/pi, dc_sm.u_ele*180/pi, sp_vel');
        set(gca, 'CLim', [sp_vel_min sp_vel_max]);
        colorbar('EastOutside');
        box off;
        title('Vel 2nd Harmonic Tuning');
        xlabel('Azimuth (Deg.)');
        ylabel('Elevation (Deg.)');
        
    end

    if ~isnan(dc_sm.sp_acc_param),
        sp_acc = sh_recon(dc_sm.sp_acc_param(1:8), 2, dc_sm.u_azi, dc_sm.u_ele+pi/2);
        sp_acc_max = max(sp_acc(:));
        sp_acc_min = min(sp_acc(:));
        subplot(3, 4, 5);
        contourf(dc_sm.u_azi*180/pi, dc_sm.u_ele*180/pi, sp_acc');
        set(gca, 'CLim', [sp_acc_min sp_acc_max]);
        colorbar('EastOutside');
        box off;
        title('Acc Spatial Tuning');
        xlabel('Azimuth (Deg.)');
        ylabel('Elevation (Deg.)');
        
        sp_acc = sh_recon([dc_sm.sp_acc_param(1:3) 0 0 0 0 0], 2, dc_sm.u_azi, dc_sm.u_ele+pi/2);
        subplot(3, 4, 6);
        contourf(dc_sm.u_azi*180/pi, dc_sm.u_ele*180/pi, sp_acc');
        set(gca, 'CLim', [sp_acc_min sp_acc_max]);
        colorbar('EastOutside');
        box off;
        title('Acc 1st Harmonic Tuning');
        xlabel('Azimuth (Deg.)');
        ylabel('Elevation (Deg.)');
        
        sp_acc = sh_recon([0 0 0 dc_sm.sp_acc_param(4:8)], 2, dc_sm.u_azi, dc_sm.u_ele+pi/2);
        subplot(3, 4, 7);
        contourf(dc_sm.u_azi*180/pi, dc_sm.u_ele*180/pi, sp_acc');
        set(gca, 'CLim', [sp_acc_min sp_acc_max]);
        colorbar('EastOutside');
        box off;
        title('Acc 2nd Harmonic Tuning');
        xlabel('Azimuth (Deg.)');
        ylabel('Elevation (Deg.)');
    end

    if ~isnan(dc_sm.sp_jer_param),
        sp_jer = sh_recon(dc_sm.sp_jer_param(1:8), 2, dc_sm.u_azi, dc_sm.u_ele+pi/2);
        sp_jer_max = max(sp_jer(:));
        sp_jer_min = min(sp_jer(:));
        subplot(3, 4, 9);
        contourf(dc_sm.u_azi*180/pi, dc_sm.u_ele*180/pi, sp_jer');
        set(gca, 'CLim', [sp_jer_min sp_jer_max]);
        colorbar('EastOutside');
        box off;
        title('Jer Spatial Tuning');
        xlabel('Azimuth (Deg.)');
        ylabel('Elevation (Deg.)');
        
        sp_jer = sh_recon([dc_sm.sp_jer_param(1:3) 0 0 0 0 0], 2, dc_sm.u_azi, dc_sm.u_ele+pi/2);
        subplot(3, 4, 10);
        contourf(dc_sm.u_azi*180/pi, dc_sm.u_ele*180/pi, sp_jer');
        set(gca, 'CLim', [sp_jer_min sp_jer_max]);
        colorbar('EastOutside');
        box off;
        title('Jer 1st Harmonic Tuning');
        xlabel('Azimuth (Deg.)');
        ylabel('Elevation (Deg.)');
        
        sp_jer = sh_recon([0 0 0 dc_sm.sp_jer_param(4:8)], 2, dc_sm.u_azi, dc_sm.u_ele+pi/2);
        subplot(3, 4, 11);
        contourf(dc_sm.u_azi*180/pi, dc_sm.u_ele*180/pi, sp_jer');
        set(gca, 'CLim', [sp_jer_min sp_jer_max]);
        colorbar('EastOutside');
        box off;
        title('Jer 2nd Harmonic Tuning');
        xlabel('Azimuth (Deg.)');
        ylabel('Elevation (Deg.)');
    end
    
    subplot(3, 4, 4);
    axis off;

    tabstring = ['Trial ' num2str(i) ': ' dc_data_dir(i).name];
    text(0, 1, tabstring, 'Interpreter','latex', ...
                  'FontName', 'helvetica', 'FontSize', 8);

    if 1,
        set(h, 'PaperPosition', [0 0 11 8.5]);
        set(h, 'PaperSize', [11 8.5]);
        saveas(h, [OUTPUT_PATH dc_data_dir(i).name(1:end-4) '.pdf'], 'pdf');
        close(h);
    end
end
