clear;

OUTPUT_PATH = ['..' filesep '..' filesep 'Paper_Output' filesep 'NS2_SC_SI_Data' filesep];
data_dir = dir([OUTPUT_PATH '*.mat']);

for i=1:length(data_dir),
    dat = load([OUTPUT_PATH filesep data_dir(i).name]);
    p = dat.p;
    
    save(['..' filesep '..' filesep 'Paper_Input' filesep 'psth_SI_c' filesep ...
          'm' data_dir(i).name(5:end)], 'p');
end