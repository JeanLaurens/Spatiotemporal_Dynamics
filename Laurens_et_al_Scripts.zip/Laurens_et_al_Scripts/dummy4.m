% plot([0 0.5 1 0], [0 sqrt(0.75) 0 0], '-');
% axis equal;
% box off;
% 
% return;
clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('htb'));
addpath(genpath('modelS2H'));

PATH = (['..' filesep '..' filesep 'Poster_Output' filesep 'S2H_Output_Xiongjie' filesep]);
psm = poolSelModel(PATH);

scrsz = get(0,'ScreenSize');
figure('Position', scrsz, 'Renderer', 'painters');
subplot(2,2,1);
psm.plotBIC('S2H VN');

subplot(2,2,2);
psm.plotR2();

subplot(2,2,3);
psm.plotTypes();

psm.plotTuning2();

psm.plotTimeParam();

psm.plotWeightsTurnplot('S2H VN');

psm.plotSpatialWeights();

psm.plotSHCoeff();

return;

PATH_CV = (['..' filesep '..' filesep 'Data' filesep 'Xiongjie_Good' filesep]);
data_dir_cv = dir([PATH_CV 'm*']);

data_dir = dir([PATH '*.mat']);
for i=1:length(interesting),
    idx = interesting(i);
    disp([num2str(idx), ', ' data_dir(idx).name]);

    dat = load([PATH data_dir(idx).name]);

    p = PSTH('xiongjie', [PATH_CV data_dir_cv(i).name filesep]);

    sm = modelDC.selModel(p, dat.fv, dat.fa, dat.fj, dat.fva, dat.fvj, dat.faj, dat.fvaj);
    sm.plotPSTH(i, data_dir(idx).name, ...
      ['..' filesep '..' filesep 'Figures' filesep 'fakedata_plots' filesep]);
end