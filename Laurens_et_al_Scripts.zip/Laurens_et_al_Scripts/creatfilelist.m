clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('htb'));
addpath(genpath('modelSC_NS'));

brain_area = 'OA';

PATH = ['Z:\Users\Raymond\rchan\Documents\Paper_Output' filesep  'NS_SC_' brain_area '_Data' filesep];
data_dir = dir([PATH '*.mat']);


for i = 1:length(data_dir),
   filename{i,1} = (data_dir(i).name);
end