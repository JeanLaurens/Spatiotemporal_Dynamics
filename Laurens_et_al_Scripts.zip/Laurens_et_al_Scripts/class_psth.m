clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));

OUTPUT_PATH = ['..' filesep '..' filesep 'Figures' filesep 'fakedata_plots' filesep];

SC_PATH = (['..' filesep '..' filesep 'Output' filesep 'SC2_Output_Xiongjie' filesep]);
sc_data_dir = dir([SC_PATH '*.mat']);
DC_PATH = (['..' filesep '..' filesep 'Output' filesep 'DC5_Output_Xiongjie' filesep]);
dc_data_dir = dir([DC_PATH '*.mat']);
SCC_PATH = (['..' filesep '..' filesep 'Output' filesep 'SCC_Output_Xiongjie' filesep]);
scc_data_dir = dir([SCC_PATH '*.mat']);
DCC_PATH = (['..' filesep '..' filesep 'Output' filesep 'DCC_Output_Xiongjie' filesep]);
dcc_data_dir = dir([DCC_PATH '*.mat']);

for i=1:length(dc_data_dir),
%for i=[1 3 6 12 14 18 19 21 22 23 27 28],
    addpath(genpath('model_sc'));
    sc_cur_data = load([SC_PATH sc_data_dir(i).name]);
    sc_sm = selModel(sc_cur_data.p, sc_cur_data.fv, sc_cur_data.fa, ...
                     sc_cur_data.fj, sc_cur_data.fva, sc_cur_data.fvj, ...
                     sc_cur_data.faj, sc_cur_data.fvaj);
    
    st_data = [sc_sm.u_ele; sc_sm.u_azi; sc_sm.time'];
    dim = [length(sc_sm.u_azi),length(sc_sm.u_ele), length(sc_sm.time)];

    max_spikes = max(sc_sm.psth(:));
    min_spikes = min(sc_sm.psth(:));
    
    sc_fit = unpackPSTH(sc_sm.bic_model(sc_sm.bic_param, st_data), dim);
    
    scc_cur_data = load([SCC_PATH scc_data_dir(i).name]);
    scc_sm = selModel(scc_cur_data.p, scc_cur_data.fv, scc_cur_data.fa, ...
                      scc_cur_data.fj, scc_cur_data.fva, scc_cur_data.fvj, ...
                      scc_cur_data.faj, scc_cur_data.fvaj);
    
    scc_fit = unpackPSTH(scc_sm.bic_model(scc_sm.bic_param, st_data), dim); 
    rmpath(genpath('model_sc'));
    
    addpath(genpath('model_dc'));
    dc_cur_data = load([DC_PATH dc_data_dir(i).name]);
    dc_sm = selModel(dc_cur_data.p, dc_cur_data.fv, dc_cur_data.fa, ...
                     dc_cur_data.fj, dc_cur_data.fva, dc_cur_data.fvj, ...
                     dc_cur_data.faj, dc_cur_data.fvaj);
    
    dc_fit = unpackPSTH(dc_sm.bic_model(dc_sm.bic_param, st_data), dim);
    
    dcc_cur_data = load([DCC_PATH dcc_data_dir(i).name]);
    dcc_sm = selModel(dcc_cur_data.p, dcc_cur_data.fv, dcc_cur_data.fa, ...
                      dcc_cur_data.fj, dcc_cur_data.fva, dcc_cur_data.fvj, ...
                      dcc_cur_data.faj, dcc_cur_data.fvaj);
    
    dcc_fit = unpackPSTH(dcc_sm.bic_model(dcc_sm.bic_param, st_data), dim);
    rmpath(genpath('model_dc'));
    
    scrsz = get(0,'ScreenSize');
    h = figure('Position', scrsz, 'Renderer', 'painters');
    for j=1:length(sc_sm.u_ele),
        for k=1:length(sc_sm.u_azi)-1,
            if j == 1 && k > 1,
                continue;
            end
            if j == length(sc_sm.u_ele) && k > 1,
                continue;
            end
            subplot(length(sc_sm.u_ele), length(sc_sm.u_azi)-1, ...
                   (length(sc_sm.u_ele)-j)*(length(sc_sm.u_azi)-1) + k);
            area(sc_sm.time, squeeze(sc_sm.psth(k,j,:)), ...
                    'FaceColor', 'r', 'EdgeColor','r');
            hold on;
            plot(sc_sm.time, squeeze(sc_fit(k,j,:)), 'b','LineWidth', 2); 
            plot(dc_sm.time, squeeze(dc_fit(k,j,:)), 'g','LineWidth', 2); 
            %plot(scc_sm.time, squeeze(scc_fit(k,j,:)), 'b--','LineWidth', 2); 
            %plot(dcc_sm.time, squeeze(dcc_fit(k,j,:)), 'g--','LineWidth', 2); 
            hold off;
            axis tight;
            box off;
            ylim([min_spikes max_spikes]);
            line([1 1]+0.115, ylim, 'color', 'k', 'linestyle', '--');
            line([0 0], ylim, 'color', 'k');
            line(2*[1 1], ylim, 'color', 'k');
            title(['[' num2str(sc_sm.u_ele(j)*180/pi) ...
                   ', ' num2str(sc_sm.u_azi(k)*180/pi) ']']);
        end
    end
    
    subplot(length(sc_sm.u_ele), length(sc_sm.u_azi)-1, 2);
    axis off;
    tabstring = ['Trial ' num2str(i) ': ' sc_data_dir(i).name];
    text(0, 1, tabstring, 'Interpreter','latex', ...
                          'FontName', 'helvetica', 'FontSize', 10);
    
    set(h, 'PaperPosition', [0 0 11 8.5]);
    set(h, 'PaperSize', [11 8.5]);
    saveas(h, [OUTPUT_PATH sc_data_dir(i).name(1:end-4) '.pdf'], 'pdf');
    close(h);

end