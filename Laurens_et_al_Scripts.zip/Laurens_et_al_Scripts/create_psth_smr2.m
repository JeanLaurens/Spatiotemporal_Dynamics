clear;

addpath(genpath(['..' filesep 'Toolbox']));
addpath(genpath('selection'));
addpath(genpath('psth'));
addpath(genpath('misc'));
addpath(genpath('htb'));
addpath(genpath('modelS2H'));

brain_area = 'OA';

PATH = (['..' filesep '..' filesep 'Data' filesep 'Xiongjie_Good' filesep]);
data_dir = dir([PATH 'm*']);

% correct_time = load(['..' filesep '..' filesep 'Paper_Output' filesep ...
%                      'Time_Correction' filesep 'OA_correct.mat']);
% 
% default_lag = nanmedian(correct_time.pool_lag);
% disp(default_lag);

for i = 1:length(data_dir),
    disp([PATH data_dir(i).name filesep]);
    %if isnan(correct_time.pool_lag(i)),
        %p = PSTH('xiongjie', default_lag, [PATH data_dir(i).name filesep]);
        p = PSTH('xiongjie', 0, [PATH data_dir(i).name filesep]);
%     else     
%         %p = PSTH('xiongjie', correct_time.pool_lag(i), [PATH data_dir(i).name filesep]);
%         p = PSTH('xiongjie', 0, [PATH data_dir(i).name filesep]);
%     end

%     save(['..' filesep '..' filesep 'Paper_Output' filesep 'psth_' brain_area '_c' filesep ...
%           data_dir(i).name '.mat'], 'p');
end